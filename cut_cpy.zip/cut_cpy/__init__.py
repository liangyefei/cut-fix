"""Standalone Copybook chunking API."""

from .parser import parse_copybook

__all__ = ['parse_copybook']
