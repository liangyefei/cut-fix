# 独立 CPY 切分器

将 `cut_cpy` 目录整体放到内网的 Python 导入路径。运行环境使用 Python 3.10 或更高版本，依赖均为 Python 标准库。

## 命令行

在 `cut_cpy` 的上一级目录执行。输入可以是单个 `.cpy` 文件，也可以是含 `.cpy` 的 ZIP。ZIP 内的扩展名匹配忽略大小写，仅处理 CPY 条目。

```powershell
python -B -m cut_cpy input.cpy -o result.json
python -B -m cut_cpy input.zip -o result.json --encoding gb18030
```

默认使用 UTF-8，并自动探测固定或自由格式。可用 `--source-format fixed` 或 `--source-format free` 指定初始格式。源码内的 `>>SOURCE FORMAT` 指令可以切换后续行格式。

## Python 接入

```python
from cut_cpy import parse_copybook

result = parse_copybook(
    decoded_source,
    path=relative_path,
    available_paths=project_cpy_paths,
)
chunks = result['chunks']
```

`decoded_source` 为已解码的源码文本，`relative_path` 和 `project_cpy_paths` 使用相对于 ZIP 根目录的路径并以 `/` 分隔。解析器利用项目 CPY 路径匹配 `COPY` 目标，并在 `imports` 中区分已解析、未解析和歧义。跨工程引用、持久化和发布由宿主的接入层处理。

`source` 保留源码布局和注释，移除开头的 BOM 并将换行统一为 LF。切片的 `start_line` 和 `end_line` 从 1 起且包含两端，`statement_line` 指向实际结构语句。`start_offset` 和 `end_offset` 从 0 起且右端开放，按 `source[start_offset:end_offset]` 可取回切片正文。`symbols`、`diagnostics` 和 `uncovered_code_ranges` 分别提供符号层级、解析异常和切片外的代码范围。
