'use strict';
// No agent installation, watcher, model, or execution of uploaded source code.
const { CodeGraph } = require('@colbymchenry/codegraph');
const fs = require('node:fs');
const path = require('node:path');

async function reportCobolParseGaps(graph, root) {
  // The pinned SDK reports syntax errors only when it extracts zero symbols.
  const files = graph.getFiles().filter(file => file.language === 'cobol');
  if (!files.length) return;
  const sdk = require.cache[require.resolve('@colbymchenry/codegraph')];
  const entry = sdk.children.find(module => module.exports.CodeGraph === CodeGraph);
  const extraction = path.join(path.dirname(entry.filename), 'extraction');
  const { loadGrammarsForLanguages, getParser } = require(path.join(extraction, 'grammars'));
  const { cobolExtractor } = require(path.join(extraction, 'languages', 'cobol'));
  const { parseWithinBudget } = require(path.join(extraction, 'parse-budget'));
  await loadGrammarsForLanguages(['cobol']);
  const parser = getParser('cobol');
  for (const file of files) {
    const source = fs.readFileSync(path.resolve(root, file.path), 'utf8');
    const tree = parser && parseWithinBudget(parser, cobolExtractor.preParse(source));
    const hasErrors = tree?.rootNode.hasError;
    const gaps = [];
    if (hasErrors) {
      const pending = [tree.rootNode];
      while (pending.length && gaps.length < 8) {
        const node = pending.pop();
        if (!node?.hasError && !node?.isMissing) continue;
        if (node.isError || node.isMissing) {
          gaps.push([node.startPosition.row + 1, node.endPosition.row + 1]);
        } else {
          for (let i = node.childCount - 1; i >= 0; i--) pending.push(node.child(i));
        }
      }
    }
    tree?.delete();
    if (!tree) parser?.reset();
    if (!tree || hasErrors) {
      process.stdout.write(JSON.stringify({ cobol_diagnostic: { path: file.path, gaps, timed_out: !tree } }) + '\n');
    }
  }
}

(async () => {
  const root = path.resolve(process.argv[2]);
  const graph = await CodeGraph.init(root, { index: false });
  try {
    const result = await graph.indexAll({
      onProgress: (progress) => process.stdout.write(`${JSON.stringify(progress)}\n`),
    });
    await reportCobolParseGaps(graph, root);
    process.stdout.write(`${JSON.stringify({ result, stats: graph.getStats() })}\n`);
  } finally {
    graph.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
