"""Adjust comment ownership at CodeGraph chunk boundaries."""

from collections import defaultdict
from itertools import accumulate
from pathlib import Path, PurePosixPath
import re

COBOL_EXTENSIONS = {'.cbl', '.cob', '.cobol', '.cpy'}
LICENSE = re.compile(r'\bcopyright\b|\blicen[cs]e\b|all rights reserved', re.I)
COMMENTED_CODE = re.compile(
    r'^(?:\d{2}\s+\S+|(?:MOVE|PERFORM|CALL|SET|DISPLAY|COPY|IF|END-IF|GO TO|EXEC|GOBACK|EXIT)(?:\s|\.|$))')
ENTRY_POINT = re.compile(r'\bENTRY\s+POINT\b\s*[:-]?\s*([A-Z0-9@$#_-]+)', re.I)


def _comment(line: str) -> str | None:
    sequence = line[:6].strip()
    if line[6:7] == '*' and (not sequence or sequence.isascii() and sequence.isdigit()):
        return line[7:72].removeprefix('>').strip()
    text = line.lstrip()
    return text[2:].strip() if text.startswith('*>') else None


def has_cobol_code(text: str) -> bool:
    for line in text.splitlines():
        sequence = line[:6].strip()
        if not sequence or sequence.isascii() and sequence.isdigit():
            if line[6:7] == '/' or not line[6:72].strip():
                continue
        if line.strip() and _comment(line) is None:
            return True
    return False


def _banner_border(comment: str) -> bool:
    return len(comment) >= 3 and not comment.strip(' *-=_')


def _caption_start(lines: list[str], statement: int, title: str) -> int:
    index = statement - 1
    comments = []
    while index and (comment := _comment(lines[index - 1])) is not None:
        comments.append((index, comment))
        index -= 1
    name = title.upper()
    for i, (line, text) in enumerate(comments):
        if entry := ENTRY_POINT.search(text):
            if entry[1].upper() != name:
                return statement
        if text.strip(' *.').upper() in {name, f'{name} SECTION'}:
            if i + 1 < len(comments) and _banner_border(comments[i + 1][1]):
                return line - 1
            return line

    # An explicitly framed caption can describe a unit without repeating its name.
    if comments and _banner_border(comments[0][1]):
        prose = []
        for line, text in comments[1:]:
            if _banner_border(text):
                entries = {m[1].upper() for p in prose if (m := ENTRY_POINT.search(p))}
                if prose and (not entries or entries == {name}) and not any(
                        LICENSE.search(p) or COMMENTED_CODE.match(p) for p in prose):
                    return line
                break
            if text:
                prose.append(text.strip(' *'))
    return statement


def attach_cobol_captions(result: dict, source_root: Path) -> None:
    """Keep the parser's units and executable lines, moving only adjacent captions."""
    nodes = {n['id']: n['props'] for n in result['nodes']}
    files = defaultdict(list)
    for chunk in result['chunks']:
        if PurePosixPath(chunk['path']).suffix.lower() in COBOL_EXTENSIONS and chunk['node_id'] in nodes:
            files[chunk['path']].append(chunk)
    for path, chunks in files.items():
        source = (source_root / path).read_text('utf-8')
        lines = source.splitlines(keepends=True)
        offsets = list(accumulate(map(len, lines), initial=0))
        captions = {}
        for chunk in chunks:
            if nodes[chunk['node_id']]['kind'] in {'function', 'variable'}:
                statement = chunk.get('statement_line', chunk['start_line'])
                first = _caption_start(lines, statement, chunk['title'])
                if first < statement:
                    captions[statement] = first

        for chunk in chunks:
            statement = chunk.get('statement_line', chunk['start_line'])
            start, end = chunk['start_line'], chunk['end_line']
            first = captions.get(statement, start)
            last = end
            if (following := captions.get(end + 1)) is not None and following > statement:
                last = following - 1
            if (first, last) == (start, end):
                continue
            begin, stop = offsets[first - 1], offsets[last]
            props = nodes[chunk['node_id']]
            props.update(start_line=first, end_line=last, loc=f'L{first}-L{last}')
            chunk.update(start_line=first, end_line=last, start_offset=begin, end_offset=stop, text=source[begin:stop])
            if first != statement:
                props['statement_line'] = chunk['statement_line'] = statement
