# ZIP 工程源码切分与内网接入

这份目录从当前 `knowledge-base` 工作区抽取了 ZIP 校验、源码规范化、结构解析、切片与源码定位逻辑。可以独立试跑，也可以接到内网知识库现有的上传和后台任务。独立入口返回规范化源码、工程页面展示的结构切片、图谱关系和处理报告。现有项目在发布阶段还会从结构切片生成用于向量检索的子切片，由宿主的 `publish` 和 `representations.encode_many` 继续处理。

## 支持的文件

| ZIP 内的扩展名 | 解析方式 | 主要切分单位 |
| --- | --- | --- |
| `.cbl`、`.cob`、`.cobol` | CodeGraph 1.6.2 | CodeGraph 识别的过程、变量和常量 |
| `.cpy` | CodeGraph 1.6.2 | Copybook 中识别出的变量、常量等结构 |
| `.aps` | APS 原文解析 | 程序入口、段落、声明、记录、报表等结构 |
| `.jcl` | JCL 原文解析 | JOB、PROC、EXEC 步骤、条件分支及独立片段 |

扩展名匹配忽略大小写，一个 ZIP 可以混合以上类型。ZIP 条目经过校验后才会把可用源码写入解析目录。`.git`、`.codegraph`、`node_modules`、`__macosx` 和其他后缀的文件计入跳过清单。处理原始 ZIP 的留存时，宿主保存上传字节即可保留这些条目。

## 输入边界

- 单个 ZIP 最大 50 MiB，条目声明的解压总量最大 200 MiB，最多 5000 个条目。单个支持类型的源码在解码前和转为 UTF-8 后各有 1 MiB 上限。文件路径最多 240 个字符、20 个路径分量，路径分量包含文件名。
- 绝对路径、父目录跳转、危险的 Windows 路径名、符号链接、加密条目和大小写冲突路径会使整个 ZIP 失败。损坏或使用不支持压缩方式的 ZIP 也会失败。
- 默认按 UTF-8 解码，可为整个 ZIP 指定 GB18030。删除开头的 BOM，将 CRLF 和单独的 CR 统一为 LF。源码缩进和行序保留。解码失败、空文本、非法控制字符、疑似编码损坏和未解决的合并冲突会隔离对应文件，原因在 `options.skipped`。可用源码为空时工程失败。

## 切片边界

### COBOL 与 Copybook

CodeGraph 解析前，对带下划线且可安全转换的 COBOL 标识符使用工程内统一、等长、无冲突的临时别名。转换仅作用于解析副本，固定列、注释、字符串和预处理伪文本保留。图谱恢复原始标识符，切片按同一行号从规范化原文取正文。文件报告的 `compatibility` 记录标识符数、替换次数和未转换名称，`errors` 可报告语法树里仍存在的解析缺口。

项目适配层为 `function`、`variable`、`constant` 节点生成结构切片。归属明确的相邻标题随结构正文保留，`statement_line` 记录实际声明行。文件头注释、`FILE-CONTROL`、`COPY` 等内容如果落在所有选中范围之外，就只保留在源码中。父级结构和子级结构的范围可能重叠，完整源码以 ZIP 或 `sources[path]` 为准。

模块、文件、字段、`COPY` 等其他已识别节点可作为图谱信息输出，图谱节点是否存在与是否生成检索切片是两套规则。解析器不会为已经产生结构切片的文件逐段补齐未覆盖的行。

### APS

- 每个文件从标准 APS 固定列（关键字从第 8 列起）和部分导出格式（关键字从第 4 列起）中选择识别结果较多的一种，平局优先使用标准列。变更标记和尾部序号保留在原文里。
- 按 `PROC`、`NTRY`、`PARA`、`DECL`、`DPAR`、`WS`、`LK`、`IO`、`FD`、`REC`、`RED`、`MOCK` 等已知关键字识别边界。在过程上下文中也识别部分以段名加句点表示的 COBOL/2 段落和 SECTION。完整识别表在 [aps.py](aps.py)。
- 块通常从当前边界延伸到下一边界前一行。归属明确的前置 `/*` 注释可并入下一段落、记录或文件声明。入口名不符的说明留在原处。纯注释文件头留在原文，只有标记与空行的 `WS`、`LK` 标头可随首条数据定义一起切分。
- 文件定义、记录、报表组等可携带 `aps_context`，供展示或检索时引用相关行。APS 块直接引用原文行号。宏展开和生成 COBOL 不在这条切分路径中。

### JCL

- 以 `JOB`、`PROC`、`EXEC`、`PEND`、`IF`、`ELSE`、`ENDIF` 为结构边界。文件头说明可归入首个 `JOB` 或 `PROC`。紧邻 `EXEC` 的标题型 `//*` 注释可以进入步骤切片，共用分隔线、许可证和续卡注释按其所在结构保留。`statement_line` 仍指向实际语句卡。
- `DD`、参数和注释的续行、内联数据和控制语句留在所在范围内。识别 `DD *`、`DD DATA`、默认分隔符和字面量 `DLM`，在内联数据中按对应终止规则避免把数据误作步骤。语句字段按第 1–71 列匹配，第 72 列可标记注释续行，序号等列仍保留在切片中。
- `jcl_context` 记录 EXEC 所属的 JOB、PROC 或 IF/ELSE 分支。只有 DD、SET、INCLUDE 等受支持操作的独立片段整文件输出。外部 PROC 和 INCLUDE 不展开，JCL 作业不执行。完整识别表在 [jcl.py](jcl.py)。

### 回退与坐标

- 某文件完全没有结构切片时，按每 100 行回退，末段可少于 100 行。纯注释和空白的行窗留在原文。回退切片的 `node_id` 为空，文件报告标记 `structural_chunks: false`。整个工程都没有识别到有效结构节点时，任务返回解析错误。有效结构指 CodeGraph 的模块、过程、变量或字段节点，或 APS/JCL 的有效结构块。
- `start_line`、`end_line` 从 1 开始，包含首尾两行。`start_offset`、`end_offset` 是规范化文本的字符偏移，从 0 开始，右侧不包含。每个切片都满足 `chunk["text"] == sources[path][start_offset:end_offset]`。结构块保持完整，未按字符数或模型 token 数再次切分。
- `statement_line` 在存在时指向结构语句所在行，可用于查看代码时跳转。上下文元数据保留引用范围，不会拼接进切片的 `text`。

## 独立运行

使用 Python 3.11 或更高版本。APS/JCL 工程仅用 Python 标准库。ZIP 内含 COBOL 或 Copybook 时需要 CodeGraph 1.6.2 及配套 Node.js，原项目部署使用 Node.js 25.8.2。以下命令在 `cut` 的上一级目录运行。

```sh
# 含 COBOL / Copybook 时安装，锁文件会固定版本
npm ci --prefix cut/tools/codegraph

python -B -m cut test-jcl.zip -o jcl-result.json
python -B -m cut test-cobol.zip -o cobol-result.json --encoding utf-8
```

如果服务的 PATH 无法找到 Node，设置 `KB_CODEGRAPH_NODE` 为可执行文件的绝对路径。隔离内网使用内网 npm 镜像、预置 npm 缓存，或将按部署系统和架构安装的依赖随部署包放入 `tools/codegraph/node_modules`。依赖包含平台包，保留 npm optional dependencies。CodeGraph 会在可写的解析目录下生成 SQLite 索引，单次运行超时为 600 秒。独立入口使用系统临时目录，运行结束会清理工作文件。如果默认临时目录不可写，启动前将 `TEMP` 和 `TMP`（Linux 可用 `TMPDIR`）指向可写目录。

也可以从 Python 调用。

```python
from pathlib import Path

from cut import cut_zip

payload = cut_zip(Path("test-jcl.zip").read_bytes(), project="test-jcl", version="v1.0")
chunks = payload["result"]["chunks"]
sources = payload["sources"]
```

输出的 `job_id` 标识本次运行。`options` 包含文件清单、解析引擎、跳过原因、源码质量报告和工程范围。`result` 包含 `chunks`、`nodes`、`edges`、`unresolved`、`files`、`summary`、`engine_version`。查看某个文件是否成功产生结构切片时，以 `result.files` 中的 `structural_chunks` 和 `errors` 为准。独立模式下可按切片的 `path` 从 `sources` 读取全文。图谱里的 `source_path` 沿用宿主的存储键格式，供集成时定位快照。JSON 含工程源码，供内网验收。

## 合并到内网仓库

先在内网仓库找到工程 ZIP 的上传入口、后台解析、切片和发布代码。四类源码按下表接入同一套预检、解析和切分逻辑。宿主继续负责鉴权、状态和存储。启用后用同一份 ZIP 对比切片坐标及正文。

1. 将本目录的 Python 文件及 `tools/codegraph` 放到内网仓库的 `backend/app/ingest/cut/`。需要 COBOL 时，在仓库根目录运行 `npm ci --prefix backend/app/ingest/cut/tools/codegraph`，或在部署构建时准备相同依赖。
2. 在 `backend/app/ingest/code_project.py` 中从相对模块 `.cut.zip_cutter` 导入所需符号，按下表接入。保留宿主的上传鉴权、后台队列、状态流转、对象存储和发布事务。宿主仍负责保存 `upload.zip` 和按相对路径写入 `root/source/`。传给切分函数的 `root` 是工程快照的绝对路径，`job_id` 使用本次上传的现有任务 ID。
3. 对照宿主的发布逻辑检查切片字段是否一路传到数据库、图谱、检索和源码跳转。若测试通过旧模块替换 `run_codegraph` 或 `MAX_SOURCE`，接入后把测试替换的目标移到实际引用这些符号的模块，保留原有测试断言。

| 阶段 | 默认接法 | 调用方需要保留的行为 |
| --- | --- | --- |
| 上传与预检 | `create_project` 调用 `inspect_archive(content, encoding)` | 使用返回的 `sources` 和 `skipped` 建立清单。上传接口的读取上限与预检一致。本地路由读取 `projects.MAX_UPLOAD`，替换时继续导出该常量或同步修改引用。 |
| 解析 | `raw = build_source_graph(root, options["files"])` | 输入清单来自 ZIP 预检，保留解析阶段的状态和失败信息。 |
| 切片 | `result = adapt_graph(raw, root, options, job_id)` | `options` 至少有 `files`、`project`、`version`、`scope`、`engine`、`skipped`，沿用已有的 `library` 和 `tags`。宿主的 `result.json` 写入这里的 `result`。独立命令输出的外层还含 `sources` 等验收数据。 |
| 发布 | 继续走宿主的 `publish(job_id, result, options)` | 保留项目和版本身份、存储键、索引与回滚。文件类型显示、`lang` 及上下文处理与实际路由使用同一套 `source_engine`、`SOURCE_SPLITTERS`、`ENGINE_NAMES`。保存可选字段 `statement_line`、`aps_context`、`jcl_context`。 |

本目录的 `prepare_text` 用于源码校验。宿主的 `quality.py` 还提供文档质量检查和向量校验，继续保留该模块。已有工程可用保存的原始 ZIP 或源码快照执行宿主的重建流程。

### 合并后的验收

1. 用测试工程名或隔离知识库分别上传 APS、JCL、COBOL/Copybook 和混合 ZIP，确认上传、解析、切片、发布均完成。出现失败时，用任务阶段区分解析错误和发布或向量错误。
2. APS 检查段落注释、文件与记录归属，JCL 检查 `EXEC` 与其 DD、续行和内联数据的范围。两者都按 `statement_line` 和上下文引用回到正确原文。COBOL 检查段落、数据项、COPY/CALL 关系及全文预览。
3. 抽查 `source[start_offset:end_offset] == chunk["text"]`，并用 `"".join(source.splitlines(keepends=True)[start_line - 1:end_line])` 再核对行范围。确认回退标记、跳过原因和未解析引用仍能看到。样本切片数变化时记录对应文件及边界原因。
4. 验证解析或发布失败时，上一版仍可查看和检索，重试产生独立任务。同工程同版本的新任务成功发布后，再验证内网现有的替换与索引行为。按测试环境通过后的版本发布，历史工程按需单独重建。

| 交付文件 | 来源与用途 |
| --- | --- |
| [zip_cutter.py](zip_cutter.py) | 从 `backend/app/ingest/code_project.py` 抽取 ZIP 校验、引擎路由、图谱适配及切片。独立入口用临时目录替代项目存储，并在读取完 CodeGraph SQLite 索引后关闭连接。 |
| [aps.py](aps.py)、[jcl.py](jcl.py)、[source_blocks.py](source_blocks.py) | 原工程的原文切分器与行范围结构。 |
| [cobol_cleaning.py](cobol_cleaning.py)、[cobol_ranges.py](cobol_ranges.py) | 解析副本的兼容清洗、标识符还原及标题注释边界。 |
| [quality.py](quality.py) | 原工程的 `prepare_text` 源码校验与规范化函数。 |
| [tools/codegraph](tools/codegraph/) | 原工程的 CodeGraph 桥接脚本和依赖锁文件。 |
| [__init__.py](__init__.py)、[__main__.py](__main__.py) | 独立试跑的 Python 和命令行入口。 |

## 本地验收基线

以下结果与当前工作区的原项目切分逻辑对照验证。每个切片的行号和字符范围均可定位到对应的规范化原文。

| 样本 | 可用文件 | 切片 |
| --- | ---: | ---: |
| 已上传的 APS 工程 ZIP | 3 | 77 |
| `test-jcl.zip` | 38 | 139 |
| `test-cobol.zip` | 78 | 1524 |
| 已上传的 `ATMXGHS(1).cbl` 工程 ZIP | 1 | 9 |

`ATMXGHS(1).cbl` 的验收范围依次为 `PARAMETERS-DATA` 103–120、`EBCDIC-CCSID` 122–125、`ASCII-CCSID` 126、`MISC-AREA` 128–135、`DFHCOMMAREA` 145–147、`A000-INIT-RTN` 160–197、`B000-MAIN-RTN` 198–262、`C000-FINAL-RTN` 263–278、`V000-VLID-REQ-MSG-RTN` 279–295。报告应显示 13 个兼容标识符和 35 次替换，切片正文仍能找到 `RETURN_CODE`。使用内网的同一份样本验收。交付压缩包只含代码、锁文件和说明。
