"""Length-preserving compatibility input for CodeGraph's COBOL grammar."""

from collections import Counter
from itertools import product
from pathlib import Path
import re
from string import ascii_uppercase, digits

from .cobol_ranges import COBOL_EXTENSIONS

FORMAT = re.compile(r'^([ \t]*)(?:IDENTIFICATION\s+DIVISION|ID\s+DIVISION|PROGRAM-ID\b|\d{2}[ \t]+[A-Z])', re.I)
TOKENS = re.compile(r"""['"]|\*>|==|[A-Z0-9_-]+""", re.I | re.ASCII)
LITERALS = {q: re.compile(r'(?:' + q * 2 + r'|[^' + q + r'])*' + q) for q in ("'", '"')}
SYMBOL = re.compile(r'[A-Z0-9_]+(?:-[A-Z0-9_]+)*', re.ASCII)
TARGET = re.compile(
    r"""\b(?:PROGRAM-ID\.|CALL|COPY|ENTRY|END\s+PROGRAM)\s+(['"])([A-Z0-9_-]+)\1"""
    r"""|\b(?:PROGRAM-ID\.|COPY|END\s+PROGRAM)\s+([A-Z0-9_-]+)""", re.I)


def _words(source: str):
    """Yield code-word spans, excluding literals, comments, directives and pseudotext."""
    lines = source.splitlines(keepends=True)
    marker = next((match for line in lines if (match := FORMAT.match(line))), None)
    free = marker is not None and len(marker[1]) < 7
    offset = 0
    quote = None
    pseudotext = False
    for line in lines:
        start, stop = (0, len(line)) if free else (7, 72)
        area = line[start:stop].rstrip('\r\n')
        indicator = line[6:7]
        if (free or indicator in {' ', '-', 'D', 'd'}) and not area.lstrip().startswith(('>>', '$')):
            first = 0
            if quote:
                # A fixed-format continued literal starts with a new delimiter.
                first = len(area) - len(area.lstrip())
                if indicator == '-' and area[first:first + 1] == quote:
                    first += 1
                elif not free:
                    quote = None
            while first < len(area):
                if quote:
                    match = LITERALS[quote].match(area, first)
                    if match is None:
                        break
                    first, quote = match.end(), None
                match = TOKENS.search(area, first)
                if match is None:
                    break
                token = match[0]
                first = match.end()
                if token == '*>':
                    break
                if token == '==':
                    pseudotext = not pseudotext
                elif token in LITERALS:
                    quote = token
                elif not pseudotext:
                    yield offset + start + match.start(), offset + start + first, token.upper()
        offset += len(line)


def identifier_aliases(sources: dict[str, str]) -> tuple[dict[str, str], dict[str, dict]]:
    """Use a single collision-free mapping for definitions and references in an archive."""
    protected = set()
    reserved = {Path(path).stem.upper() for path in sources}
    per_file = {}
    for path, source in sources.items():
        words = {word for _, _, word in _words(source)}
        reserved.update(words)
        # Reserve names that can be used as quoted program, call or copybook targets.
        reserved.update(m[1].upper() for m in re.finditer(r"""['"]([A-Z0-9_-]+)['"]""", source, re.I))
        protected.update((m[2] or m[3]).upper() for m in TARGET.finditer(source))
        per_file[path] = {word for word in words if '_' in word and any(c in ascii_uppercase for c in word)}
    aliases = {}
    candidates = {}
    reserved.update(protected)
    for name in sorted({name for names in per_file.values() for name in names}):
        width = len(name)
        if width < 2 or name in protected or not SYMBOL.fullmatch(name):
            continue
        if width not in candidates:
            # A Z followed by a digit avoids COBOL keywords. Keep source columns fixed.
            candidates[width] = ('Z' + ''.join(tail) for tail in product(digits, *([digits + ascii_uppercase] * (width - 2))))
        alias = next((word for word in candidates[width] if word not in reserved), None)
        if alias:
            aliases[name] = alias
            reserved.add(alias)
    reports = {}
    for path, names in per_file.items():
        if names:
            reports[path] = {'identifiers': len(names & aliases.keys()), 'skipped_identifiers': sorted(names - aliases.keys())}
    return aliases, reports


def normalize_identifiers(source: str, aliases: dict[str, str]) -> tuple[str, int]:
    parts = []
    last = 0
    count = 0
    for first, end, word in _words(source):
        if alias := aliases.get(word):
            parts.extend((source[last:first], alias))
            last = end
            count += 1
    parts.append(source[last:])
    return ''.join(parts), count


def restore_identifiers(raw: dict, aliases: dict[str, str]) -> None:
    originals = {alias: name for name, alias in aliases.items()}

    def restore(text):
        return re.sub(r'[A-Za-z0-9_-]+', lambda m: originals.get(m[0].upper(), m[0]), text) if text else text

    for node in raw['nodes']:
        if Path(node['file_path']).suffix.lower() in COBOL_EXTENSIONS and node['kind'] != 'file':
            for key in ('name', 'qualified_name', 'signature'):
                if key in node:
                    node[key] = restore(node[key])
    for ref in raw['unresolved_refs']:
        ref['reference_name'] = restore(ref['reference_name'])
    for edge in raw['edges']:
        if edge.get('metadata'):
            edge['metadata'] = restore(edge['metadata'])
