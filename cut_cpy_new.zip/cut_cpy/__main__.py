"""Run the independent Copybook cutter on a CPY file or a ZIP archive."""

from __future__ import annotations

import argparse
import json
import stat
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZipFile

from .chunk_splitter import DEFAULT_LEAF_OVERLAP_LINES, DEFAULT_MAX_TOKENS, DEFAULT_TOKEN_ENCODING
from .parser import parse_copybook


MAX_FILE_BYTES = 1 << 20
MAX_ZIP_FILES = 5000
MAX_ZIP_CPY_BYTES = 200 << 20


def read_copybooks(path: Path, encoding: str) -> dict[str, str]:
    if path.suffix.casefold() == '.cpy':
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ValueError(f'{path.name}: file exceeds 1 MiB')
        return {path.name: path.read_text(encoding=encoding)}
    if path.suffix.casefold() != '.zip':
        raise ValueError('expected a .cpy or .zip file')

    with ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) > MAX_ZIP_FILES:
            raise ValueError(f'archive exceeds {MAX_ZIP_FILES} entries')
        members = {}
        names = set()
        total = 0
        for entry in entries:
            source = PurePosixPath(entry.filename.replace('\\', '/'))
            if entry.is_dir() or source.suffix.casefold() != '.cpy':
                continue
            if (source.is_absolute() or '..' in source.parts or ':' in source.parts[0]
                    or stat.S_ISLNK(entry.external_attr >> 16) or entry.flag_bits & 1):
                raise ValueError(f'unsupported Copybook ZIP entry: {entry.filename}')
            name = source.as_posix()
            if name.casefold() in names:
                raise ValueError(f'duplicate Copybook path: {name}')
            names.add(name.casefold())
            if entry.file_size > MAX_FILE_BYTES:
                raise ValueError(f'{name}: file exceeds 1 MiB')
            total += entry.file_size
            if total > MAX_ZIP_CPY_BYTES:
                raise ValueError('Copybook entries exceed 200 MiB')
            members[name] = entry
        if not members:
            raise ValueError('no .cpy entries in archive')
        return {name: archive.read(members[name]).decode(encoding) for name in sorted(members)}


def main() -> None:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('input', type=Path)
    cli.add_argument('--output', '-o', type=Path, required=True)
    cli.add_argument('--encoding', default='utf-8', choices=['utf-8', 'gb18030'])
    cli.add_argument('--source-format', default='auto', choices=['auto', 'fixed', 'free'])
    cli.add_argument('--max-tokens', type=int, default=DEFAULT_MAX_TOKENS,
                     help=f'Maximum embedding_text tokens per chunk (default: {DEFAULT_MAX_TOKENS}, hard limit: 8191)')
    cli.add_argument('--token-encoding', default=DEFAULT_TOKEN_ENCODING,
                     help=f'Tokenizer encoding name (default: {DEFAULT_TOKEN_ENCODING})')
    cli.add_argument('--overlap-lines', type=int, default=DEFAULT_LEAF_OVERLAP_LINES,
                     help=f'Overlap lines for oversized leaf/procedure splits (default: {DEFAULT_LEAF_OVERLAP_LINES})')
    args = cli.parse_args()
    try:
        if (args.input.resolve() == args.output.resolve() or
                args.output.exists() and args.input.samefile(args.output)):
            raise ValueError('output must differ from input')
        sources = read_copybooks(args.input, args.encoding)
        files = [parse_copybook(source, path=name, source_format=args.source_format,
                                available_paths=tuple(sources), max_tokens=args.max_tokens,
                                token_encoding=args.token_encoding,
                                overlap_lines=args.overlap_lines) for name, source in sources.items()]
        output = dict(engine='cpy_standalone', max_tokens=args.max_tokens, files=files)
        args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    except (OSError, ValueError, BadZipFile, NotImplementedError) as exc:
        cli.exit(1, f'{exc}\n')
    print(f'{len(files)} Copybooks, {sum(len(file["chunks"]) for file in files)} chunks')


if __name__ == '__main__':
    main()
