"""Token-budgeted cAST chunking and embedding text preparation for Copybooks."""

from __future__ import annotations

import math
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .parser import Line, Symbol

DEFAULT_MAX_TOKENS = 7500
EMBEDDING_HARD_LIMIT = 8191
DEFAULT_TOKEN_ENCODING = 'cl100k_base'
DEFAULT_LEAF_OVERLAP_LINES = 5
HEADER_TOKEN_RESERVE = 24

_TOKEN_UNIT = re.compile(
    r'[A-Za-z_]{1,8}'
    r'|\d{1,3}'
    r'| {2,8}'
    r'|[^\x00-\x7f]'
    r'|\S'
    r'|\n'
)
_BLOCK_OPEN = re.compile(r'^\s*(?:IF|EVALUATE|SEARCH)\b', re.IGNORECASE | re.ASCII)
_BLOCK_CLOSE = re.compile(r'^\s*(?:END-IF|END-EVALUATE|END-SEARCH|END-PERFORM)\b', re.IGNORECASE | re.ASCII)
_EXEC_START = re.compile(r'^\s*EXEC\s+(?:SQLIMS|SQL|CICS|DLI)\b', re.IGNORECASE | re.ASCII)
_EXEC_END = re.compile(r'(?<![A-Z0-9_@$#-])END-EXEC(?=\s|\.|$)', re.IGNORECASE | re.ASCII)
_PERIOD = re.compile(r'\.(?=\s|$)')
_DECORATIVE = re.compile(r'^[\s*\-=_/]+$')

_TIKTOKEN_CACHE: dict[str, tuple[Callable[[str], int], str]] = {}


def estimate_cl100k_tokens(text: str) -> int:
    """Conservative pure-stdlib estimator calibrated for cl100k_base on COBOL + CJK."""
    if not text:
        return 0
    total = 0
    for match in _TOKEN_UNIT.finditer(text):
        piece = match.group(0)
        total += 2 if ord(piece[0]) > 127 else 1
    return math.ceil(total * 1.1)


def get_token_counter(encoding_name: str = DEFAULT_TOKEN_ENCODING) -> tuple[Callable[[str], int], str]:
    """Return a token counting function and its backend name.

    Prefers exact ``tiktoken`` counting (works offline when ``TIKTOKEN_CACHE_DIR`` is set),
    and falls back to the conservative stdlib estimator when unavailable.
    """
    cached = _TIKTOKEN_CACHE.get(encoding_name)
    if cached is not None:
        return cached
    try:
        import tiktoken  # type: ignore[import-not-found]

        encoding = tiktoken.get_encoding(encoding_name)

        def _count(text: str) -> int:
            return len(encoding.encode(text, disallowed_special=()))

        _count('01 TEST.')
        result = (_count, f'tiktoken:{encoding_name}')
    except Exception:
        result = (estimate_cl100k_tokens, f'heuristic:{encoding_name}')
    _TIKTOKEN_CACHE[encoding_name] = result
    return result


def _collapse_inline_spaces(text: str) -> str:
    """Collapse runs of spaces/tabs to a single space outside single/double quotes."""
    out: list[str] = []
    quote = ''
    in_space = False
    index = 0
    length = len(text)
    while index < length:
        ch = text[index]
        if quote:
            out.append(ch)
            if ch == quote:
                if index + 1 < length and text[index + 1] == quote:
                    out.append(quote)
                    index += 2
                    continue
                quote = ''
            index += 1
            continue
        if ch in {'\'', '"'}:
            quote = ch
            in_space = False
            out.append(ch)
        elif ch in {' ', '\t'}:
            if not in_space:
                out.append(' ')
                in_space = True
        else:
            in_space = False
            out.append(ch)
        index += 1
    return ''.join(out)


def _compact_indent(raw_indent: int) -> str:
    """Preserve shallow visual indentation tiers (0, 2, or 4 spaces) in <= 1 token."""
    if raw_indent < 2:
        return ''
    return '  ' if raw_indent < 6 else '    '


def clean_line_for_embedding(raw_row: str, line: Line) -> str | None:
    """Strip fixed-format sequence/ID columns, decorative borders, and excess alignment spaces."""
    expanded = raw_row.expandtabs(8)
    if line.fixed:
        body = expanded[6:72].rstrip()
        if not body.strip():
            return ''
        indicator = body[0]
        if indicator in {'*', '/'}:
            inner = body[1:].strip()
            if not inner or _DECORATIVE.fullmatch(inner):
                return None
            return '* ' + _collapse_inline_spaces(inner)
        code_area = body[1:]
        content = code_area.lstrip(' ')
        if indicator == '-':
            return '- ' + content
        raw_indent = len(code_area) - len(content)
        compact_content = content if line.continuation else _collapse_inline_spaces(content)
        return _compact_indent(raw_indent) + compact_content
    body = expanded.rstrip()
    stripped = body.lstrip(' ')
    if not stripped:
        return ''
    if stripped.startswith('*>'):
        inner = stripped[2:].strip()
        if not inner or _DECORATIVE.fullmatch(inner):
            return None
        return '*> ' + _collapse_inline_spaces(inner)
    if stripped.startswith('*') and line.comment is not None:
        inner = stripped[1:].strip()
        if not inner or _DECORATIVE.fullmatch(inner):
            return None
        return '* ' + _collapse_inline_spaces(inner)
    raw_indent = len(body) - len(stripped)
    compact_content = stripped if line.continuation else _collapse_inline_spaces(stripped)
    return _compact_indent(raw_indent) + compact_content


def clean_range_for_embedding(raw_rows: list[str], lines: list[Line], start_line: int, end_line: int) -> str:
    """Produce denoised text for embedding while keeping code semantics intact."""
    cleaned: list[str] = []
    previous_blank = True
    for number in range(start_line, end_line + 1):
        piece = clean_line_for_embedding(raw_rows[number - 1], lines[number - 1])
        if piece is None:
            continue
        if not piece:
            if not previous_blank:
                cleaned.append('')
                previous_blank = True
            continue
        cleaned.append(piece)
        previous_blank = False
    while cleaned and not cleaned[-1]:
        cleaned.pop()
    if cleaned:
        return '\n'.join(cleaned)
    return '\n'.join(raw_rows[number - 1].rstrip() for number in range(start_line, end_line + 1)).strip()


def format_symbol_label(symbol: Symbol) -> str:
    if symbol.level is not None:
        return f'{symbol.level:02d} {symbol.name}'
    return symbol.name


def build_context_header(path: str, hierarchy_path: list[str], start_line: int, end_line: int,
                         part_index: int = 1, part_total: int = 1) -> str:
    location = f'L{start_line}-L{end_line}'
    part_suffix = f', part {part_index}/{part_total}' if part_total > 1 else ''
    path_text = ' > '.join(hierarchy_path) if hierarchy_path else 'root'
    return f'File: {path} | Path: {path_text} ({location}{part_suffix})'


def build_embedding_text(path: str, hierarchy_path: list[str], raw_rows: list[str], lines: list[Line],
                         start_line: int, end_line: int, part_index: int = 1, part_total: int = 1) -> str:
    header = build_context_header(path, hierarchy_path, start_line, end_line, part_index, part_total)
    body = clean_range_for_embedding(raw_rows, lines, start_line, end_line)
    return f'{header}\n{body}' if body else header


@dataclass(slots=True)
class _Span:
    start_line: int
    end_line: int
    symbol: Symbol | None
    hierarchy_path: list[str]
    strategy: str = 'cast'


def _has_code(lines: list[Line], start_line: int, end_line: int) -> bool:
    return any(lines[number - 1].code.strip() for number in range(start_line, end_line + 1))


def _first_code_line(lines: list[Line], start_line: int, end_line: int) -> int:
    for number in range(start_line, end_line + 1):
        if lines[number - 1].code.strip():
            return number
    return start_line


def _trim_blank_edges(lines: list[Line], raw_rows: list[str], start_line: int, end_line: int) -> tuple[int, int]:
    while start_line < end_line and not raw_rows[start_line - 1].strip():
        start_line += 1
    while end_line > start_line and not raw_rows[end_line - 1].strip():
        end_line -= 1
    return start_line, end_line


def _split_leaf_lines(
    raw_rows: list[str],
    lines: list[Line],
    start_line: int,
    end_line: int,
    hierarchy_path: list[str],
    symbol: Symbol | None,
    budget: int,
    token_counter: Callable[[str], int],
    *,
    is_procedure: bool,
    overlap_lines: int,
) -> list[_Span]:
    """Split an oversized leaf range at COBOL statement/block boundaries or line windows."""
    if budget < 1:
        budget = 1

    # Precompute boundary priorities for each line in [start_line, end_line].
    # Priority 2 = top-level sentence end / blank separator, Priority 1 = nested sentence end, 0 = mid-statement.
    priorities: dict[int, int] = {}
    if is_procedure:
        exec_open = False
        block_depth = 0
        for number in range(start_line, end_line + 1):
            shape = lines[number - 1].shape
            if not shape.strip():
                priorities[number] = 2 if (not exec_open and block_depth == 0) else 0
                continue
            if _EXEC_START.match(shape) and not _EXEC_END.search(shape):
                exec_open = True
            elif exec_open and _EXEC_END.search(shape):
                exec_open = False
            if not exec_open:
                if _BLOCK_OPEN.match(shape):
                    block_depth += 1
                if _BLOCK_CLOSE.match(shape):
                    block_depth = max(0, block_depth - 1)
            ends_sentence = bool(_PERIOD.search(shape))
            if not exec_open and ends_sentence:
                priorities[number] = 2 if block_depth == 0 else 1
            else:
                priorities[number] = 0

    def _range_tokens(first: int, last: int) -> int:
        return token_counter(clean_range_for_embedding(raw_rows, lines, first, last))

    spans: list[_Span] = []
    cursor = start_line
    while cursor <= end_line:
        # Find the furthest line that still fits within budget using binary search.
        low, high = cursor, end_line
        best_fit = cursor
        while low <= high:
            mid = (low + high) // 2
            if _range_tokens(cursor, mid) <= budget:
                best_fit = mid
                low = mid + 1
            else:
                high = mid - 1

        strategy = 'line_window'
        cut = best_fit
        if cut < end_line and is_procedure:
            # Prefer a clean sentence/block boundary within the latter 65% of the window.
            min_cut = cursor + max(1, (cut - cursor) // 3)
            chosen = None
            for target_priority in (2, 1):
                for candidate in range(cut, min_cut - 1, -1):
                    if priorities.get(candidate, 0) == target_priority:
                        chosen = candidate
                        break
                if chosen is not None:
                    break
            if chosen is not None:
                cut = chosen
                strategy = 'statement'
        elif cut == end_line and is_procedure and (not spans or spans[-1].strategy == 'statement'):
            strategy = 'statement'

        seg_start, seg_end = _trim_blank_edges(lines, raw_rows, cursor, cut)
        if _has_code(lines, seg_start, seg_end):
            spans.append(_Span(seg_start, seg_end, symbol, list(hierarchy_path), strategy=strategy))

        if cut >= end_line:
            break
        if overlap_lines > 0 and cut - cursor >= overlap_lines:
            next_cursor = cut - overlap_lines + 1
            if next_cursor <= cursor:
                next_cursor = cut + 1
        else:
            next_cursor = cut + 1
        cursor = next_cursor

    return spans


def _build_child_segments(
    parent: Symbol,
    range_start: int,
    range_end: int,
    children_map: dict[str, list[Symbol]],
    lines: list[Line],
    parent_path: list[str],
) -> list[_Span]:
    """Decompose a parent symbol's line range into ordered, gap-free atomic segments."""
    direct_children = [
        child for child in children_map.get(parent.id, [])
        if range_start <= child.start_line and child.end_line <= range_end
    ]
    direct_children.sort(key=lambda item: (item.start_line, item.end_line))

    raw_segments: list[_Span] = []
    cursor = range_start
    for child in direct_children:
        if child.start_line < cursor:
            # Skip nested/overlapping artifacts already covered by a prior sibling.
            continue
        if child.start_line > cursor:
            raw_segments.append(_Span(cursor, child.start_line - 1, None, list(parent_path)))
        child_path = parent_path + [format_symbol_label(child)]
        raw_segments.append(_Span(child.start_line, child.end_line, child, child_path))
        cursor = child.end_line + 1
    if cursor <= range_end:
        raw_segments.append(_Span(cursor, range_end, None, list(parent_path)))

    # Attach comment-only / blank gaps to adjacent code segments so no non-code chunk is emitted.
    merged: list[_Span] = []
    pending_prefix: _Span | None = None
    for seg in raw_segments:
        if seg.symbol is None and not _has_code(lines, seg.start_line, seg.end_line):
            if not merged:
                if pending_prefix is None:
                    pending_prefix = seg
                else:
                    pending_prefix.end_line = seg.end_line
            else:
                # Attach trailing gap to previous segment unless it looks like a header right before next child.
                merged[-1].end_line = seg.end_line
            continue
        if pending_prefix is not None:
            seg.start_line = pending_prefix.start_line
            pending_prefix = None
        merged.append(seg)
    if pending_prefix is not None:
        if merged:
            merged[-1].end_line = pending_prefix.end_line
        else:
            merged.append(pending_prefix)
    return merged


def _group_redefines(
    segments: list[_Span],
    raw_rows: list[str],
    lines: list[Line],
    budget: int,
    token_counter: Callable[[str], int],
    parent_path: list[str],
) -> list[_Span]:
    """Keep REDEFINES paired with its immediately preceding target sibling when it fits."""
    if len(segments) < 2:
        return segments
    grouped: list[_Span] = [segments[0]]
    for seg in segments[1:]:
        prev = grouped[-1]
        if (
            seg.symbol is not None
            and seg.symbol.redefines
            and prev.symbol is not None
            and prev.symbol.name.upper() == seg.symbol.redefines.upper()
            and prev.end_line + 1 == seg.start_line
        ):
            combined_tokens = token_counter(clean_range_for_embedding(raw_rows, lines, prev.start_line, seg.end_line))
            if combined_tokens <= budget:
                grouped[-1] = _Span(
                    start_line=prev.start_line,
                    end_line=seg.end_line,
                    symbol=None,
                    hierarchy_path=list(parent_path),
                    strategy='cast',
                )
                continue
        grouped.append(seg)
    return grouped


def _cast_split_node(
    symbol: Symbol,
    range_start: int,
    range_end: int,
    children_map: dict[str, list[Symbol]],
    raw_rows: list[str],
    lines: list[Line],
    path: str,
    ancestor_path: list[str],
    max_tokens: int,
    token_counter: Callable[[str], int],
    overlap_lines: int,
) -> list[_Span]:
    """cAST: top-down recursive split of oversized nodes + bottom-up greedy sibling merge."""
    header_probe = build_context_header(path, ancestor_path, range_start, range_end, 1, 99)
    effective_budget = max(64, max_tokens - token_counter(header_probe) - HEADER_TOKEN_RESERVE)

    is_procedure = symbol.kind in {'function', 'section', 'fragment'}
    direct_children = [
        child for child in children_map.get(symbol.id, [])
        if range_start <= child.start_line and child.end_line <= range_end
    ]
    if not direct_children:
        return _split_leaf_lines(
            raw_rows, lines, range_start, range_end, ancestor_path, symbol,
            effective_budget, token_counter, is_procedure=is_procedure, overlap_lines=overlap_lines,
        )

    segments = _build_child_segments(symbol, range_start, range_end, children_map, lines, ancestor_path)
    segments = _group_redefines(segments, raw_rows, lines, effective_budget, token_counter, ancestor_path)

    # Top-down recursive split for any segment that still exceeds budget.
    expanded: list[_Span] = []
    for seg in segments:
        seg_body_tokens = token_counter(clean_range_for_embedding(raw_rows, lines, seg.start_line, seg.end_line))
        if seg_body_tokens <= effective_budget:
            expanded.append(seg)
            continue
        if seg.symbol is not None and children_map.get(seg.symbol.id):
            expanded.extend(
                _cast_split_node(
                    seg.symbol, seg.start_line, seg.end_line, children_map, raw_rows, lines,
                    path, seg.hierarchy_path, max_tokens, token_counter, overlap_lines,
                )
            )
        else:
            expanded.extend(
                _split_leaf_lines(
                    raw_rows, lines, seg.start_line, seg.end_line, seg.hierarchy_path, seg.symbol,
                    effective_budget, token_counter, is_procedure=is_procedure, overlap_lines=overlap_lines,
                )
            )

    # Bottom-up greedy sibling merge of adjacent spans within effective_budget.
    packed: list[_Span] = []
    for seg in expanded:
        if not packed:
            packed.append(seg)
            continue
        prev = packed[-1]
        contiguous = seg.start_line <= prev.end_line + 1 or not _has_code(lines, prev.end_line + 1, seg.start_line - 1)
        if contiguous and seg.start_line > prev.start_line:
            merged_end = max(prev.end_line, seg.end_line)
            merged_tokens = token_counter(clean_range_for_embedding(raw_rows, lines, prev.start_line, merged_end))
            if merged_tokens <= effective_budget:
                packed[-1] = _Span(
                    start_line=prev.start_line,
                    end_line=merged_end,
                    symbol=prev.symbol if prev.symbol == seg.symbol else None,
                    hierarchy_path=list(ancestor_path),
                    strategy='cast' if prev.strategy == 'cast' and seg.strategy == 'cast' else seg.strategy,
                )
                continue
        packed.append(seg)

    return packed


def _symbol_ancestor_path(symbol: Symbol | None, symbols_by_id: dict[str, Symbol], fallback_title: str) -> list[str]:
    if symbol is None:
        return [fallback_title]
    chain: list[str] = []
    current: Symbol | None = symbol
    while current is not None:
        chain.append(format_symbol_label(current))
        current = symbols_by_id.get(current.parent_id) if current.parent_id else None
    chain.reverse()
    return chain


def apply_token_budget(
    chunks: list[dict],
    *,
    source: str,
    raw_rows: list[str],
    lines: list[Line],
    offsets: list[int],
    symbols: list[Symbol],
    children: dict[str, list[Symbol]],
    path: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    token_counter: Callable[[str], int] | None = None,
    encoding_name: str = DEFAULT_TOKEN_ENCODING,
    overlap_lines: int = DEFAULT_LEAF_OVERLAP_LINES,
) -> tuple[list[dict], str]:
    """Enforce token budget on structural chunks using cAST + Scheme B (text + embedding_text)."""
    if max_tokens < 64:
        raise ValueError('max_tokens must be at least 64')
    if max_tokens > EMBEDDING_HARD_LIMIT:
        raise ValueError(f'max_tokens ({max_tokens}) exceeds model hard limit ({EMBEDDING_HARD_LIMIT})')

    if token_counter is None:
        counter, tokenizer_name = get_token_counter(encoding_name)
    else:
        counter, tokenizer_name = token_counter, 'custom'

    symbols_by_id = {sym.id: sym for sym in symbols}
    result: list[dict] = []

    for chunk in chunks:
        root_symbol = symbols_by_id.get(chunk['symbol_id']) if chunk.get('symbol_id') else None
        base_path = _symbol_ancestor_path(root_symbol, symbols_by_id, chunk['title'])
        emb_text = build_embedding_text(
            path, base_path, raw_rows, lines, chunk['start_line'], chunk['end_line'], 1, 1,
        )
        tokens = counter(emb_text)

        if tokens <= max_tokens:
            enriched = dict(chunk)
            enriched.update(
                embedding_text=emb_text,
                token_count=tokens,
                hierarchy_path=base_path,
                parent_symbol_id=root_symbol.parent_id if root_symbol else None,
                part_index=1,
                part_total=1,
                split_strategy='none',
            )
            result.append(enriched)
            continue

        # Chunk exceeds max_tokens: apply cAST split-then-merge.
        if root_symbol is not None:
            spans = _cast_split_node(
                root_symbol, chunk['start_line'], chunk['end_line'], children, raw_rows, lines,
                path, base_path, max_tokens, counter, overlap_lines,
            )
        else:
            header_probe = build_context_header(path, base_path, chunk['start_line'], chunk['end_line'], 1, 99)
            effective_budget = max(64, max_tokens - counter(header_probe) - HEADER_TOKEN_RESERVE)
            spans = _split_leaf_lines(
                raw_rows, lines, chunk['start_line'], chunk['end_line'], base_path, None,
                effective_budget, counter, is_procedure=chunk['kind'] in {'function', 'section', 'fragment'},
                overlap_lines=overlap_lines,
            )

        # Final verification pass: ensure every span strictly satisfies <= max_tokens with final header.
        verified_spans: list[_Span] = []
        for span in spans:
            if not _has_code(lines, span.start_line, span.end_line):
                continue
            probe_emb = build_embedding_text(
                path, span.hierarchy_path, raw_rows, lines, span.start_line, span.end_line, 1, max(len(spans), 99),
            )
            if counter(probe_emb) <= max_tokens:
                verified_spans.append(span)
            else:
                header_len = counter(build_context_header(path, span.hierarchy_path, span.start_line, span.end_line, 1, 999))
                tight_budget = max(32, max_tokens - header_len - 8)
                verified_spans.extend(
                    _split_leaf_lines(
                        raw_rows, lines, span.start_line, span.end_line, span.hierarchy_path, span.symbol,
                        tight_budget, counter, is_procedure=chunk['kind'] in {'function', 'section', 'fragment'},
                        overlap_lines=0,
                    )
                )

        total_parts = len(verified_spans)
        for index, span in enumerate(verified_spans, 1):
            first, last = span.start_line, span.end_line
            begin, stop = offsets[first - 1], offsets[last]
            stmt_line = (
                span.symbol.statement_line
                if span.symbol is not None and first <= span.symbol.statement_line <= last
                else _first_code_line(lines, first, last)
            )
            part_emb = build_embedding_text(path, span.hierarchy_path, raw_rows, lines, first, last, index, total_parts)
            part_tokens = counter(part_emb)
            part_title = f"{chunk['title']} (part {index}/{total_parts})" if total_parts > 1 else chunk['title']
            result.append(dict(
                title=part_title,
                kind=chunk['kind'],
                symbol_id=span.symbol.id if span.symbol is not None else chunk['symbol_id'],
                parent_symbol_id=chunk['symbol_id'],
                start_line=first,
                end_line=last,
                statement_line=stmt_line,
                start_offset=begin,
                end_offset=stop,
                text=source[begin:stop],
                embedding_text=part_emb,
                token_count=part_tokens,
                hierarchy_path=span.hierarchy_path,
                part_index=index,
                part_total=total_parts,
                split_strategy=span.strategy if total_parts > 1 else 'none',
            ))

    result.sort(key=lambda item: (item['start_line'], -item['end_line'], item['part_index'], item['title']))
    return result, tokenizer_name
