"""Line-oriented Copybook structure extraction using only the standard library."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import asdict, dataclass
from itertools import accumulate
from pathlib import PurePosixPath

from .chunk_splitter import (
    DEFAULT_LEAF_OVERLAP_LINES,
    DEFAULT_MAX_TOKENS,
    DEFAULT_TOKEN_ENCODING,
    apply_token_budget,
)


WORD = r'[A-Z0-9_@$#]+(?:-[A-Z0-9_@$#]+)*'
FLAGS = re.IGNORECASE | re.ASCII
ENTRY = re.compile(rf'^\s*(\d{{1,2}})\s+(?P<name>{WORD})(?=\s|\.|$)', FLAGS)
PARAGRAPH = re.compile(rf'^\s*({WORD})\s*\.(?=\s|$)', FLAGS)
SECTION = re.compile(rf'^\s*({WORD})\s+SECTION(?:\s+\d{{1,2}})?\s*\.(?=\s|$)', FLAGS)
DIVISION = re.compile(r'^\s*(IDENTIFICATION|ID|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION\b', FLAGS)
SOURCE_FORMAT = re.compile(r'^\s*>>\s*SOURCE\s+(?:FORMAT\s+)?(?:IS\s+)?(FIXED|FREE)\b', FLAGS)
COPY_START = re.compile(r'^\s*COPY(?=\s|$)', FLAGS)
REPLACE_START = re.compile(r'^\s*REPLACE(?=\s|$)', FLAGS)
EXEC_START = re.compile(r'^\s*EXEC\s+(?:SQLIMS|SQL|CICS|DLI)\b', FLAGS)
EXEC_END = re.compile(r'(?<![A-Z0-9_@$#-])END-EXEC(?=\s|\.|$)', FLAGS)
EXEC_SQL_DATA = re.compile(r'^\s*EXEC\s+SQL\s+(?:DECLARE\b|INCLUDE\b|(?:BEGIN|END)\s+DECLARE\s+SECTION\b)', FLAGS)
PERIOD = re.compile(r'\.(?=\s|$)')
SEQUENCE = re.compile(r'[ A-Z0-9]{6}', FLAGS)
COPY_OPERAND = rf'''"(?:""|[^"\n])+"|'(?:''|[^'\n])+'|{WORD}'''
COPY_NAME = re.compile(
    rf'^\s*COPY\s+({COPY_OPERAND})(?:\s+(?:OF|IN)\s+({COPY_OPERAND}))?', FLAGS)
COPY_REPLACING = re.compile(r'\bREPLACING\b', FLAGS)
DECLARATION_TARGET = re.compile(rf'(?<!\S)(REDEFINES|RENAMES)\s+({WORD})(?:\s+(?:THRU|THROUGH)\s+({WORD}))?', FLAGS)
TEMPLATE = re.compile(r'(?<=[-])\([A-Z][A-Z0-9_-]*\)|\([A-Z][A-Z0-9_-]*\)(?=[A-Z-])', FLAGS)

VERBS = frozenset('''ACCEPT ADD ALLOCATE ALTER CALL CANCEL CLOSE COMPUTE CONTINUE DELETE DISPLAY
    DIVIDE ENTRY EVALUATE EXEC EXIT FREE GENERATE GO GOBACK IF INITIALIZE INITIATE INSPECT INVOKE
    JSON MERGE MOVE MULTIPLY OPEN PERFORM READ RELEASE RETURN REWRITE SEARCH SET SORT START STOP
    STRING SUBTRACT SUPPRESS TERMINATE UNLOCK UNSTRING WRITE XML'''.split())
PARA_RESERVED = VERBS | frozenset('''CBL COPY PROCESS REPLACE ELSE WHEN OTHER AND OR NOT END
    NEXT SENTENCE DECLARATIVES SELECT ASSIGN THEN USING THROUGH THRU BY INTO FROM TO TRUE FALSE
    PROCEDURE DATA ENVIRONMENT IDENTIFICATION SECTION DIVISION PIC PICTURE VALUE VALUES
    NULL NULLS SPACES SPACE ZERO ZEROES ZEROS'''.split())
DATA_SECTIONS = frozenset('FILE WORKING-STORAGE LOCAL-STORAGE LINKAGE REPORT SCREEN COMMUNICATION'.split())
DATA_LEVELS = frozenset(range(1, 50)) | {66, 77, 78, 88}
DATA_CLAUSES = frozenset('''PIC PICTURE USAGE VALUE VALUES OCCURS REDEFINES RENAMES SIGN
    SYNCHRONIZED SYNC JUSTIFIED JUST BLANK EXTERNAL GLOBAL TYPEDEF COMP COMP-1 COMP-2 COMP-3
    COMP-4 COMP-5 BINARY DISPLAY NATIONAL POINTER'''.split())
DATA_CONTINUATION = frozenset('''ARE IS ALL TIMES DEPENDING THRU THROUGH TO FROM BY AND OR NOT
    ASCENDING DESCENDING INDEXED WITH KEY'''.split())
COPY_DIAGNOSTIC = re.compile(r'^\s*(?:COPY|REPLACE)(?=\s|$)', FLAGS)
NON_CAPTION = re.compile(r'\b(?:copyright|licen[cs]e|all rights reserved)\b|^\s*(?:ver(?:sion)?|date)\s*:', FLAGS)
CAPTION_NAME = re.compile(rf'\b(?:ENTRY\s+POINT|SUBROUTINE|PARAGRAPH)\s*[:-]?\s+({WORD})', FLAGS)
CAPTION_STOP_WORDS = {'A', 'AN', 'FOR', 'IN', 'OF', 'ON', 'THE', 'TO'}


@dataclass(slots=True)
class Line:
    code: str
    shape: str
    comment: str | None
    fixed: bool
    continuation: bool = False
    special: bool = False


@dataclass(slots=True)
class Symbol:
    id: str
    name: str
    kind: str
    statement_line: int
    start_line: int
    end_line: int
    parent_id: str | None = None
    level: int | None = None
    declaration_end_line: int | None = None
    redefines: str | None = None
    renames: tuple[str, ...] = ()


@dataclass(slots=True)
class Copy:
    name: str
    library: str | None
    start_line: int
    end_line: int
    replacing: bool
    terminated: bool


def normalize_source(text: str) -> str:
    return text.removeprefix('\ufeff').replace('\r\n', '\n').replace('\r', '\n')


def first_word(text: str) -> str:
    match = re.match(r'[A-Z0-9_@$#-]+', text.lstrip(), FLAGS)
    return match[0].upper() if match else ''


def fixed_prefix(text: str) -> bool:
    return len(text) >= 7 and text[6] in ' */-Dd' and SEQUENCE.fullmatch(text[:6]) is not None


def detect_format(rows: list[str]) -> str:
    for raw in rows:
        row = raw.expandtabs(8)
        if not row.strip() or row.lstrip().startswith('*>'):
            continue
        if fixed_prefix(row) and row[6] in '*/':
            continue
        if SOURCE_FORMAT.match(row):
            return 'free' if not fixed_prefix(row) else 'fixed'
        if row.lstrip().startswith('*'):
            continue
        # Check for a source declaration before the fixed-format code area.
        if len(row) - len(row.lstrip()) < 7 and (ENTRY.match(row) or PARAGRAPH.match(row)
                or SECTION.match(row) or DIVISION.match(row) or first_word(row) in VERBS | {'COPY', 'REPLACE'}):
            return 'free'
        if fixed_prefix(row):
            return 'fixed'
        return 'free'
    return 'fixed'


def project_lines(rows: list[str], source_format: str, diagnostics: list[dict]) -> list[Line]:
    lines = []
    quote = ''
    pseudo = False
    for number, raw in enumerate(rows, 1):
        row = raw.expandtabs(8)
        fixed = source_format == 'fixed'
        indicator = row[6:7] if fixed else ''
        if fixed and indicator in {'*', '/'}:
            lines.append(Line('', '', row[7:72].removeprefix('>').strip(), fixed))
            continue

        code = row[7:72] if fixed else row
        directive = SOURCE_FORMAT.match(code) or SOURCE_FORMAT.match(row)
        if directive and not quote and not pseudo:
            source_format = directive[1].lower()
            lines.append(Line('', '', None, fixed, special=True))
            continue
        if fixed and row.strip() and not fixed_prefix(row):
            diagnostics.append(dict(kind='fixed_layout', start_line=number, end_line=number))
            lines.append(Line('', '', None, fixed))
            continue
        if not fixed and not quote and not pseudo and code.lstrip().startswith('*'):
            lines.append(Line('', '', code.lstrip()[1:].removeprefix('>').strip(), fixed))
            continue
        if not code.strip():
            lines.append(Line('', '', None, fixed))
            continue

        continuation = indicator == '-' or bool(quote) or pseudo
        shape = list(code)
        # A visible marker for string content prevents a line containing a literal from becoming whitespace.
        index, comment = 0, None
        if quote and fixed:
            first = len(code) - len(code.lstrip())
            if indicator == '-' and code[first:first + 1] == quote:
                shape[first] = '~'
                index = first + 1
            else:
                diagnostics.append(dict(kind='unterminated_literal', start_line=number - 1, end_line=number - 1))
                quote, continuation = '', indicator == '-' or pseudo
        while index < len(code):
            char, pair = code[index], code[index:index + 2]
            if quote:
                shape[index] = '~'
                if char == quote and pair == quote * 2:
                    shape[index + 1] = '~'
                    index += 2
                    continue
                if char == quote:
                    quote = ''
            elif pair == '*>':
                comment = code[index + 2:].strip() if not code[:index].strip() else None
                code, shape = code[:index], shape[:index]
                break
            elif pair == '==':
                pseudo = not pseudo
                shape[index:index + 2] = '~~'
                index += 2
                continue
            elif char in "'\"":
                quote, shape[index] = char, '~'
            elif pseudo:
                shape[index] = '~'
            index += 1
        lines.append(Line(code, ''.join(shape), comment, fixed, continuation))
    if quote or pseudo:
        diagnostics.append(dict(kind='unterminated_literal' if quote else 'unterminated_pseudotext',
                                start_line=len(rows), end_line=len(rows)))
    return lines


def caption_start(lines: list[Line], statement: int, name: str, *, plain: bool = False) -> int:
    name = name.upper()
    start = statement
    while start > 1 and lines[start - 2].comment is not None:
        start -= 1
    comments = [line.comment or '' for line in lines[start - 1:statement - 1]]
    if not comments:
        return statement

    def border(text: str) -> bool:
        return len(text) >= 3 and not text.strip(' *-=_')

    def prose(text: str) -> bool:
        return not NON_CAPTION.search(text) and not ENTRY.match(text) and first_word(text) not in VERBS

    def word_pairs(text: str) -> set[tuple[str, str]]:
        words = [word for word in re.findall(r'[A-Z0-9]+', text.upper()) if word not in CAPTION_STOP_WORDS]
        return set(zip(words, words[1:]))

    # Walk from the unit towards its heading. Returning at the first matched frame
    # prevents an adjoining file header or the previous unit's footer joining it.
    for index in range(len(comments) - 1, -1, -1):
        text = comments[index]
        if NON_CAPTION.search(text):
            break
        ref = CAPTION_NAME.search(text)
        if ref and ref[1].upper() != name:
            return statement
        if text.strip(' *.').upper() in {name, f'{name} SECTION'}:
            return start + index - (index > 0 and border(comments[index - 1]))
    # A framed title can use the descriptive part of the declaration name.
    # Keep any adjoining explanation with that title through the declaration.
    if not plain:
        pairs = word_pairs(name)
        for index in range(len(comments) - 2, 0, -1):
            text = comments[index]
            if (border(comments[index - 1]) and border(comments[index + 1])
                    and pairs & word_pairs(text) and all(prose(part.strip(' *')) for part in comments[index:])):
                return start + index - 1
    if border(comments[-1]):
        for index in range(len(comments) - 2, -1, -1):
            if not border(comments[index]):
                continue
            description = [text.strip(' *') for text in comments[index + 1:-1] if text.strip(' *')]
            if description and all(prose(text) for text in description):
                return start + index
            return statement
    if plain:
        while comments and comments[-1] and not border(comments[-1]) and not NON_CAPTION.search(comments[-1]):
            statement -= 1
            comments.pop()
    return statement


def copy_statements(lines: list[Line], diagnostics: list[dict]) -> tuple[list[Copy], set[int]]:
    copies = []
    protected = set()
    start, keyword = 0, ''
    pieces = []

    def finish(end: int, terminated: bool) -> None:
        if not terminated:
            diagnostics.append(dict(kind='unterminated_' + keyword.lower(), start_line=start, end_line=end))
        if keyword != 'COPY':
            return
        statement = ' '.join(pieces)
        match = COPY_NAME.match(statement)
        if not match:
            diagnostics.append(dict(kind='copy_operand', start_line=start, end_line=end))
            return
        name = match[1].strip("'\"")
        library = match[2].strip("'\"") if match[2] else None
        copies.append(Copy(name, library, start, end, bool(COPY_REPLACING.search(statement[match.end():])), terminated))

    for number, line in enumerate(lines, 1):
        if not line.shape.strip() or line.special:
            continue
        copy_start = not line.continuation and (COPY_START.match(line.shape) or REPLACE_START.match(line.shape))
        if start and not line.continuation and (copy_start or ENTRY.match(line.shape) or DIVISION.match(line.shape)
                                                 or SECTION.match(line.shape) or first_word(line.shape) in VERBS):
            finish(previous, False)
            start = 0
        if not start and copy_start:
            start, keyword, pieces = number, first_word(line.shape), []
        if start:
            protected.add(number)
            period = PERIOD.search(line.shape)
            pieces.append(line.code[:period.start()] if period else line.code)
            previous = number
            if period:
                finish(number, True)
                start = 0
                if line.shape[period.end():].strip():
                    diagnostics.append(dict(kind='same_line_after_directive', start_line=number, end_line=number))
    if start:
        finish(previous, False)
    return copies, protected


def title_candidate(match: re.Match[str], line: Line) -> bool:
    name = match[1].upper()
    tail = line.shape[match.end():].strip()
    return (not line.fixed or match.start(1) < 4) and any(c.isalpha() for c in name) and (
        name not in PARA_RESERVED and not name.startswith('END-') and
        (not tail or first_word(tail) in VERBS or first_word(tail) == 'COPY'))


def resolve_copy(copy: Copy, path: str, available_paths: tuple[str, ...]) -> dict:
    reference = PurePosixPath(copy.name.replace('\\', '/'))
    key = reference.as_posix().casefold()
    has_extension = reference.suffix.casefold() == '.cpy'
    candidates = [candidate for candidate in available_paths
                  if PurePosixPath(candidate).suffix.casefold() == '.cpy'
                  and (candidate.casefold().endswith('/' + key) or candidate.casefold() == key
                       or not has_extension and (candidate.casefold().endswith('/' + key + '.cpy')
                                                 or candidate.casefold() == key + '.cpy'))]
    if copy.library:
        candidates = [candidate for candidate in candidates if
                      copy.library.casefold() in (part.casefold() for part in PurePosixPath(candidate).parts[:-1])]
    elif len(reference.parts) == 1:
        same_directory = [candidate for candidate in candidates if
                          PurePosixPath(candidate).parent.as_posix().casefold() == PurePosixPath(path).parent.as_posix().casefold()]
        candidates = same_directory or candidates
    candidates = sorted(set(candidates))
    return dict(**asdict(copy), status=('resolved' if len(candidates) == 1 else 'ambiguous' if candidates else 'unresolved'),
                target=candidates[0] if len(candidates) == 1 else None,
                candidates=candidates if len(candidates) > 1 else [])


def parse_copybook(text: str, *, path: str = 'input.cpy', source_format: str = 'auto',
                   available_paths: tuple[str, ...] = (),
                   max_tokens: int = DEFAULT_MAX_TOKENS,
                   token_encoding: str = DEFAULT_TOKEN_ENCODING,
                   token_counter: Callable[[str], int] | None = None,
                   overlap_lines: int = DEFAULT_LEAF_OVERLAP_LINES) -> dict:
    """Return structural chunks, named and layout symbols, and COPY references."""
    if source_format not in {'auto', 'fixed', 'free'}:
        raise ValueError('source_format must be auto, fixed or free')
    source = normalize_source(text)
    if any(ord(char) < 32 and char not in '\n\t' for char in source):
        raise ValueError('Copybook contains an unsupported control character')
    rows = source.splitlines(keepends=True)
    raw_rows = [line.rstrip('\n') for line in rows]
    detected = detect_format(raw_rows) if source_format == 'auto' else source_format
    diagnostics: list[dict] = []
    lines = project_lines(raw_rows, detected, diagnostics)
    copies, protected = copy_statements(lines, diagnostics)
    offsets = list(accumulate(map(len, rows), initial=0))
    last_code = [0]
    for number, line in enumerate(lines, 1):
        last_code.append(number if line.code.strip() else last_code[-1])

    symbols: list[Symbol] = []
    units: list[Symbol] = []
    ordinary: list[Symbol] = []
    named: Symbol | None = None
    section: Symbol | None = None
    declaration: Symbol | None = None
    active_data: Symbol | None = None
    active_fragment: Symbol | None = None
    mode = 'unknown'
    exec_open = 0

    def add(name: str, kind: str, number: int, parent: Symbol | None = None, level: int | None = None,
            with_caption: bool = False) -> Symbol:
        start = caption_start(lines, number, name, plain=kind == 'fragment') if with_caption else number
        symbol = Symbol(f'{number}:{kind}:{name}', name, kind, number, start, number,
                        parent.id if parent else None, level)
        symbols.append(symbol)
        return symbol

    def finish_declaration(limit: int) -> None:
        nonlocal declaration
        if declaration is None:
            return
        first = declaration.statement_line
        end = max(first, last_code[limit])
        for number in range(first, end + 1):
            if number in protected:
                end = number - 1
                break
            period = PERIOD.search(lines[number - 1].shape)
            if period:
                end = number
                tail = lines[number - 1].shape[period.end():]
                if ENTRY.match(tail) or COPY_DIAGNOSTIC.match(tail):
                    diagnostics.append(dict(kind='same_line_after_declaration', start_line=number, end_line=number))
                break
        declaration.declaration_end_line = declaration.end_line = max(first, end)
        signature = ' '.join(line.shape for line in lines[first - 1:end])
        if target := DECLARATION_TARGET.search(signature):
            if target[1].upper() == 'REDEFINES':
                declaration.redefines = target[2].upper()
            else:
                declaration.renames = tuple(part.upper() for part in target.groups()[1:] if part)
        declaration = None

    def finish_unit(unit: Symbol | None, limit: int) -> None:
        if unit is not None:
            unit.end_line = max(unit.statement_line, last_code[limit])

    def close_data(limit: int) -> None:
        nonlocal active_data
        finish_declaration(limit)
        finish_unit(active_data, limit)
        active_data = None
        ordinary.clear()

    def close_procedure(limit: int, *, close_section: bool = False) -> None:
        nonlocal named, section, active_fragment
        finish_unit(named, limit)
        finish_unit(active_fragment, limit)
        named = active_fragment = None
        if close_section:
            finish_unit(section, limit)
            section = None

    for number, line in enumerate(lines, 1):
        shape = line.shape
        if not shape.strip() or line.special:
            continue
        if exec_open or number in protected or line.continuation:
            if exec_open and EXEC_END.search(shape):
                exec_open = 0
            continue
        word = first_word(shape)
        if match := DIVISION.match(shape):
            close_data(number - 1)
            close_procedure(number - 1, close_section=True)
            mode = 'procedure' if match[1].upper() == 'PROCEDURE' else 'data' if match[1].upper() == 'DATA' else 'preamble'
            continue
        if match := SECTION.match(shape):
            title = match[1]
            close_data(number - 1)
            close_procedure(number - 1, close_section=True)
            if title.upper() in DATA_SECTIONS and mode != 'procedure':
                mode = 'data'
            elif mode != 'preamble' and any(c.isalpha() for c in title):
                mode = 'procedure'
                section = add(title, 'section', number, with_caption=True)
                units.append(section)
                if EXEC_START.match(shape[match.end():]) and not EXEC_END.search(shape):
                    exec_open = number
            continue
        if mode in {'unknown', 'data'} and EXEC_START.match(shape):
            # DB2 declaration copybooks can start with an SQL precompiler block.
            # Treat its body as opaque and continue looking for COBOL records.
            following = next((row.shape for row in lines[number:] if row.shape.strip()), '')
            if EXEC_SQL_DATA.match(shape + ' ' + following):
                finish_declaration(number - 1)
                exec_open = 0 if EXEC_END.search(shape) else number
                mode = 'data'
                continue
        match = ENTRY.match(shape) if mode in {'unknown', 'data'} else None
        if match and int(match[1]) in DATA_LEVELS:
            level, name = int(match[1]), match['name']
            if name.upper() in DATA_CONTINUATION or not any(c.isalpha() for c in name):
                continue
            if name.upper() in DATA_CLAUSES or name.upper() == 'FILLER':
                name = 'FILLER'
            if level in {1, 77, 78}:
                close_data(number - 1)
            elif level == 88:
                finish_declaration(number - 1)
                parent = ordinary[-1] if ordinary else None
                declaration = add(name, 'constant', number, parent, level, with_caption=False)
                if parent is None:
                    diagnostics.append(dict(kind='unattached_88', start_line=number, end_line=number))
                units.append(declaration)
                mode = 'data'
                continue
            elif level == 66:
                finish_declaration(number - 1)
                parent = active_data if active_data and active_data.level == 1 else None
                if parent is None:
                    close_data(number - 1)
                declaration = add(name, 'field' if parent else 'variable', number, parent, level,
                                  with_caption=parent is None)
                if parent is None:
                    diagnostics.append(dict(kind='unattached_66', start_line=number, end_line=number))
                    units.append(declaration)
                mode = 'data'
                continue
            else:
                finish_declaration(number - 1)
                while ordinary and (ordinary[-1].level >= level or ordinary[-1].level in {77, 78}):
                    ordinary.pop()
                if not ordinary:
                    close_data(number - 1)
            parent = ordinary[-1] if ordinary else None
            kind = 'constant' if level == 78 else 'field' if parent else 'variable'
            declaration = add(name, kind, number, parent, level, with_caption=parent is None)
            ordinary.append(declaration)
            if parent is None:
                active_data = declaration
                units.append(declaration)
            mode = 'data'
            continue

        if mode != 'preamble' and (match := PARAGRAPH.match(shape)) and title_candidate(match, line):
            # A single token ending a data declaration can also look like a paragraph.
            if declaration is None or PERIOD.search(lines[last_code[number - 1] - 1].shape):
                close_data(number - 1)
                close_procedure(number - 1)
                mode = 'procedure'
                named = add(match[1], 'function', number, section, with_caption=True)
                units.append(named)
                if EXEC_START.match(shape[match.end():]) and not EXEC_END.search(shape):
                    exec_open = number
                continue
        in_data_clause = (mode == 'data' and word in DATA_CLAUSES and declaration is not None
                          and not PERIOD.search(lines[last_code[number - 1] - 1].shape))
        if word in VERBS and not in_data_clause:
            if mode == 'preamble':
                continue
            if mode != 'procedure':
                close_data(number - 1)
                mode = 'procedure'
            if named is None and section is None and active_fragment is None:
                active_fragment = add(f'Procedure fragment ({word})', 'fragment', number, with_caption=True)
                units.append(active_fragment)
            if EXEC_START.match(shape) and not EXEC_END.search(shape):
                exec_open = number

    close_data(len(lines))
    close_procedure(len(lines), close_section=True)
    if exec_open:
        diagnostics.append(dict(kind='unterminated_exec', start_line=exec_open, end_line=last_code[-1]))

    children: dict[str, list[Symbol]] = {}
    for symbol in symbols:
        if symbol.parent_id:
            children.setdefault(symbol.parent_id, []).append(symbol)
    for symbol in reversed(symbols):
        if symbol.kind == 'field' and symbol.id in children:
            symbol.end_line = max(symbol.end_line, *(child.end_line for child in children[symbol.id]))
    # If a later unit owns a heading, trim its lines from the preceding sibling.
    for previous, following in zip(units, units[1:]):
        if previous.parent_id != following.parent_id or previous.kind in {'constant', 'section'}:
            continue
        if previous.statement_line < following.start_line <= previous.end_line < following.statement_line:
            finish_unit(previous, following.start_line - 1)

    chunks = []

    def emit(title: str, kind: str, first: int, last: int, statement: int, symbol_id: str | None) -> None:
        begin, stop = offsets[first - 1], offsets[last]
        chunks.append(dict(title=title, kind=kind, symbol_id=symbol_id, start_line=first, end_line=last,
                           statement_line=statement, start_offset=begin, end_offset=stop, text=source[begin:stop]))

    for unit in units:
        first, last = unit.start_line, unit.end_line
        if unit.kind == 'section' and (paragraphs := children.get(unit.id)):
            last = max(unit.statement_line, last_code[paragraphs[0].start_line - 1])
            header = lines[unit.statement_line - 1].shape
            header_end = SECTION.match(header).end()
            if last == unit.statement_line and not header[header_end:].strip():
                continue
        if unit.kind == 'fragment':
            if any(TEMPLATE.search(line.shape) for line in lines[first - 1:last]):
                diagnostics.append(dict(kind='template_placeholders', start_line=unit.statement_line, end_line=last))
        emit(unit.name, unit.kind, first, last, unit.statement_line, unit.id)

    for copy in copies:
        if not any(chunk['start_line'] <= copy.start_line and copy.end_line <= chunk['end_line'] for chunk in chunks):
            emit('COPY ' + copy.name, 'import', copy.start_line, copy.end_line, copy.start_line, None)
    if not chunks:
        for start in range(1, len(lines) + 1, 100):
            end = min(start + 99, len(lines))
            code = [number for number in range(start, end + 1) if lines[number - 1].code.strip()]
            if code:
                emit(PurePosixPath(path).name, 'fallback', code[0], code[-1], code[0], None)
    chunks.sort(key=lambda chunk: (chunk['start_line'], -chunk['end_line'], chunk['title']))
    chunks, tokenizer_name = apply_token_budget(
        chunks,
        source=source,
        raw_rows=raw_rows,
        lines=lines,
        offsets=offsets,
        symbols=symbols,
        children=children,
        path=path,
        max_tokens=max_tokens,
        token_counter=token_counter,
        encoding_name=token_encoding,
        overlap_lines=overlap_lines,
    )

    uncovered = []
    next_chunk, covered_through = 0, 0
    for number, line in enumerate(lines, 1):
        while next_chunk < len(chunks) and chunks[next_chunk]['start_line'] <= number:
            covered_through = max(covered_through, chunks[next_chunk]['end_line'])
            next_chunk += 1
        if number <= covered_through or not line.code.strip():
            continue
        if uncovered and uncovered[-1]['end_line'] == number - 1:
            uncovered[-1]['end_line'] = number
        else:
            uncovered.append(dict(start_line=number, end_line=number))

    return dict(path=path, source_format=detected, tokenizer=tokenizer_name, max_tokens=max_tokens,
                source=source, chunks=chunks, symbols=[asdict(node) for node in symbols],
                imports=[resolve_copy(copy, path, available_paths) for copy in copies], diagnostics=diagnostics,
                uncovered_code_ranges=uncovered)
