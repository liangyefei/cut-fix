# 独立 CPY 切分器（`cut_cpy`）

面向 COBOL Copybook（`.cpy`）的独立结构化切分包，内置 **去噪压缩 + cAST 递归拆分与兄弟合并** 能力，专门解决超大 Copybook 切片超过向量模型 **8k Token（`text-embedding-3-large` 硬上限 `8191`）** 导致无法向量化的问题。

---

## 一、环境准备与内网部署

将 `cut_cpy` 目录整体放入内网项目的 Python 导入路径即可使用。

- **Python 版本**：Python 3.10 及以上。
- **零强依赖**：仅依赖 Python 标准库即可开箱运行。
- **精确 Token 计数配置（推荐，针对 `text-embedding-3-large`）**：
  - `text-embedding-3-large` 使用 `cl100k_base` 分词器（单条输入硬上限 `8191` tokens）。
  - 如果内网环境已安装 `tiktoken`，需提前将离线词表文件 `cl100k_base.tiktoken`（文件名需保持 `tiktoken` 缓存哈希名 `9b5ad71b2ce5302211f9c61530b329a4922fc6a4`）放到内网目录，并配置环境变量：
    ```bash
    # Linux
    export TIKTOKEN_CACHE_DIR=/path/to/tiktoken_cache

    # Windows PowerShell
    $env:TIKTOKEN_CACHE_DIR="D:\path\to\tiktoken_cache"
    ```
  - 启动后切分器会自动优先加载 `tiktoken:cl100k_base`；若内网未安装 `tiktoken` 或未配置离线缓存，会自动降级为内置纯标准库保守估算器（`heuristic:cl100k_base`，带 `+10%` 安全缓冲），不会触发外网请求。

---

## 二、内网同事如何测试

在 `cut_cpy` 的**上一级目录**执行以下命令即可完成本地批量验证。输入支持单个 `.cpy` 文件或包含 `.cpy` 的 `.zip` 压缩包（ZIP 内按扩展名忽略大小写自动筛选 `.cpy`）。

### 1. 命令行运行切分

```bash
# 单个 CPY 文件（默认 UTF-8、自动探测固定/自由格式、默认上限 7500 tokens）
python -B -m cut_cpy sample.cpy -o result.json

# 批量处理内网 ZIP 包（中文环境可指定 gb18030）
python -B -m cut_cpy project.zip -o result.json --encoding gb18030

# 自定义 Token 上限或格式（max-tokens 不可超过 8191）
python -B -m cut_cpy project.zip -o result.json --max-tokens 7500 --source-format fixed --overlap-lines 5
```

CLI 参数说明：
- `--encoding`：`utf-8`（默认）或 `gb18030`。
- `--source-format`：`auto`（默认自动探测）、`fixed` 或 `free`。源码内的 `>>SOURCE FORMAT` 指令可动态切换后续行格式。
- `--max-tokens`：单切片 `embedding_text` 最大 Token 预算，默认 `7500`，硬上限 `8191`。
- `--token-encoding`：分词器编码名，默认 `cl100k_base`。
- `--overlap-lines`：过程区/超长叶子节点按行兜底拆分时的重叠行数，默认 `5`。

### 2. 快速核查切分质量与 Token 上限

生成 `result.json` 后，可直接运行下面的一行命令检查是否还有超限切片、确认实际生效的 Tokenizer、查看被 cAST 拆分的巨型结构及偏移完整性：

```bash
python -c "import json; d=json.load(open('result.json', encoding='utf-8')); fs=d['files']; cs=[c for f in fs for c in f['chunks']]; print('tokenizer:', {f['tokenizer'] for f in fs}); print('files:', len(fs), 'chunks:', len(cs), 'max_tokens:', max((c['token_count'] for c in cs), default=0), 'over_8191:', sum(c['token_count']>8191 for c in cs)); print('split_chunks:', [(c['title'], c['token_count'], c['split_strategy']) for c in cs if c['part_total']>1][:20]); assert all(f['source'][c['start_offset']:c['end_offset']]==c['text'] for f in fs for c in f['chunks']); print('offset_check: OK')"
```

验收通过标准：
1. `over_8191` 为 `0`，且 `max_tokens <= 7500`；
2. `offset_check: OK`（所有切片原文与字符偏移严格一致）；
3. `split_chunks` 中可见原超限的大结构被按 `cast` / `statement` 策略拆分；
4. 若配置了离线 `tiktoken`，`tokenizer` 应显示 `{'tiktoken:cl100k_base'}`（未配置则显示 `{'heuristic:cl100k_base'}`）。

---

## 三、内网如何接入代码

### 1. Python 调用示例（核心改动点：双文本分离）

本版本采用 **原文 `text` 与向量文本 `embedding_text` 分离** 的设计：
- **调用向量模型（`text-embedding-3-large`）时**：必须传 `chunk['embedding_text']`（已去噪、带祖先层级路径、严格 `<= 7500` tokens）；
- **前端展示、代码高亮、原文定位、LLM 溯源时**：继续使用 `chunk['text']` 及 `start_line`/`end_line`/`start_offset`/`end_offset`。

```python
from cut_cpy import parse_copybook

result = parse_copybook(
    decoded_source,
    path=relative_path,                # 相对 ZIP 根目录的路径，使用 '/' 分隔
    available_paths=project_cpy_paths, # 当前工程全部 CPY 相对路径元组，用于 COPY 解析
    max_tokens=7500,                   # 默认 7500，严格 <= 8191
)

for chunk in result['chunks']:
    # 1. 送入 text-embedding-3-large 做向量化（核心改造点）
    vector_input = chunk['embedding_text']

    # 2. 原文展示 / 行号定位 / 存储原码（保持原有逻辑不变）
    raw_code = chunk['text']
    start_line, end_line = chunk['start_line'], chunk['end_line']

    # 3. 关联元数据（可用于排查或后续做邻片回捞）
    meta = {
        'title': chunk['title'],
        'kind': chunk['kind'],
        'token_count': chunk['token_count'],
        'hierarchy_path': chunk['hierarchy_path'],
        'parent_symbol_id': chunk['parent_symbol_id'],
        'part_index': chunk['part_index'],
        'part_total': chunk['part_total'],
        'split_strategy': chunk['split_strategy'],
    }
```

> 如果宿主机已有自定义的精确 Token 计数函数，也可以直接通过 `parse_copybook(..., token_counter=my_counter)` 注入。

### 2. 返回结构与关键字段说明

顶层返回 `dict`：
- `source`：保留原始布局与注释（仅去除开头 BOM 并统一换行为 LF）。
- `source_format`：探测或指定的初始格式（`fixed` / `free`）。
- `tokenizer`：实际使用的计数后端（`tiktoken:cl100k_base`、`heuristic:cl100k_base` 或 `custom`）。
- `max_tokens`：本次生效的 Token 预算上限。
- `chunks`：切片列表（见下表）。
- `symbols`：完整符号层级树（含 `level`、`parent_id`、`FILLER`、`REDEFINES`、`RENAMES`）。
- `imports`：`COPY` 引用及其解析状态（`resolved` / `ambiguous` / `unresolved`）。
- `diagnostics` / `uncovered_code_ranges`：解析诊断告警与未覆盖代码行范围。

单个 `chunk` 字段：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `title` | `str` | 切片标题；被拆分的子片自动追加 `(part i/n)` |
| `kind` | `str` | `variable` / `constant` / `section` / `function` / `fragment` / `import` / `fallback` |
| `text` | `str` | **原始源码片段**，严格等于 `source[start_offset:end_offset]` |
| `embedding_text` | `str` | **供向量化文本**（祖先路径头 + 去噪压缩代码），严格 `<= max_tokens` |
| `token_count` | `int` | `embedding_text` 的 Token 数 |
| `start_line` / `end_line` | `int` | 1-based 闭区间行号 |
| `statement_line` | `int` | 结构声明起始行（满足 `start_line <= statement_line <= end_line`） |
| `start_offset` / `end_offset` | `int` | 0-based 左闭右开字符偏移 |
| `symbol_id` | `str \| None` | 当前切片对应的最具体符号 ID |
| `parent_symbol_id` | `str \| None` | 父级或拆前根结构符号 ID（便于后续按父 ID 做邻片扩展/父子回捞） |
| `hierarchy_path` | `list[str]` | 层级面包屑，如 `["01 CUSTOMER-REC", "05 ACCT-INFO"]` |
| `part_index` / `part_total` | `int` | 分片序号与总片数（未拆分时均为 `1`） |
| `split_strategy` | `str` | `none`（未拆分）、`cast`（符号树拆合）、`statement`（过程句点/块边界）、`line_window`（行窗口兜底） |

---

## 四、功能技术实现点

### 1. 纯标准库 COBOL Copybook 结构解析（`parser.py`）
- **格式与词法投影**：固定格式按第 7 列识别注释（`*`/`/`）、续行（`-`），仅在第 8–72 列提取结构；自动处理字符串字面量、行尾 `*>` 注释、`COPY ... REPLACING ==...==` 伪文本及 `EXEC SQL/CICS/DLI ... END-EXEC` 块，避免误切。
- **完整符号树构建**：数据区按 `01`–`49` 层级号构建父子字段树，支持起始层级高于 `01` 的片段、独立项 `77`、条件名 `88`、重命名 `66`（`RENAMES`）、方言常量 `78`、匿名 `FILLER` 布局节点与 `REDEFINES` 关系；过程区识别 `SECTION`、`PARAGRAPH` 及无名过程片段，并将归属明确的注释标题合并到对应代码单元。

### 2. 双文本分离与无损降噪压缩（第一道防线，`chunk_splitter.py`）
- **原文零污染**：`text` 字段始终原样取自 `source[start_offset:end_offset]`，不破坏行号、列对齐与原文回溯校验。
- **`embedding_text` 语义压缩**：
  - 裁除固定格式 1–6 列序号栏、73–80 列识别栏及纯装饰性边框线（如 `******` / `------`）；
  - **引号感知空白折叠**：将字段定义中用于列对齐的多余空格压成单空格，同时完整保留单/双引号字符串字面量内的原始空格与 `-` 续行内容；
  - **浅层缩进归一化**：将行首缩进（含 Tab 展开后的超长空白）规整为 `0 / 2 / 4` 空格层级，减少无效空白 Token。
- 实测在 47 个样本 CPY 上可平均减少 **24.5%** Token（典型大报文最高降幅达 **33%–45%**），让大量 8k–11k 的临界结构无需拆分即可完整向量化。

### 3. 基于 Symbol 树的 cAST 递归拆分 + 兄弟合并（第二道防线，`chunk_splitter.py`）
当单切片去噪后的 `embedding_text` 仍超过 `max_tokens`（默认 `7500`）时触发分层切分：
1. **无间隙原子段分解**：将超限父节点的行范围按直接子节点（如 `05` 级）拆为有序原子区间（父声明头 + 各子节点 + 间隙注释），并把纯注释/空行间隙归并到相邻代码段，保证不丢一行代码、不出纯注释空片。
2. **COBOL 语义边界保护**：
   - `88` 级条件名绑定在所属字段内部，不拆散；当单个字段下挂载超大 `88` 枚举表时，自动下钻按批次打包。
   - `REDEFINES` 项优先与紧邻的被重定义同级字段绑定在同一切片内（总大小不超预算时）。
3. **自顶向下递归拆分 + 自底向上贪心兄弟合并（cAST）**：对自身仍超限的子组（如超大 `05` 组）继续递归下钻至 `10`/`15` 级；对拆出的同级相邻小片段按 `effective_budget`（已提前扣除祖先路径头 Token）贪心打包，避免把大结构切得过于零碎。
4. **过程区与超长叶子兜底**：针对没有子符号树的大段落（`function` / `fragment`），优先按 COBOL 句点（`.`）及顶层控制块边界（`IF`/`EVALUATE`/`EXEC` 外部）切分；极端无句点长块走二分查找行窗口切分（支持 `overlap_lines` 重叠）。
5. **上下文头注入与终态硬校验**：为每片注入 `File: ... | Path: ... (L...-L..., part i/n)` 祖先路径头，并在输出前执行终态 Token 复核，确保每片 `embedding_text` 严格 `<= max_tokens <= 8191`。

### 4. 双模式 Token 计数（`cl100k_base`）
- 优先使用 `tiktoken.get_encoding('cl100k_base')` 与 `text-embedding-3-large` 保持 1:1 精确对齐；
- 无 `tiktoken` 或离线无词表缓存时自动回退至按 COBOL 标识符、3 位数字组、空白与非 ASCII（中文）校准的纯标准库保守估算器，确保内网无外网环境下稳定运行且不超 8k 上限。
