"""Module 2: Pluggable 4-way retrieval tool registry & evidence pool.

Decouples the Agent loop from intranet internals:
intranet teams register their existing vector / bm25 / code_exact / graph callables
(sync or async, returning LangChain Documents, dicts, or strings) without modifying
the underlying retrieval implementations.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import re
from dataclasses import dataclass, replace
from typing import Any, Callable

from .types import EvidenceItem


def _norm_content_key(text: str) -> str:
    cleaned = re.sub(r"\s+", " ", (text or "").strip()).lower()
    if not cleaned:
        return ""
    return hashlib.sha256(cleaned.encode("utf-8")).hexdigest()[:24]


def normalize_evidence(raw: Any, default_channel: str = "vector") -> EvidenceItem | None:
    """Normalize LangChain Document, HF evidence dict, or arbitrary dict/str into EvidenceItem."""
    if raw is None:
        return None
    if isinstance(raw, EvidenceItem):
        return raw if raw.raw_obj is not None else replace(raw, raw_obj=raw)

    # LangChain Document duck-typing (zero hard dependency on langchain)
    if hasattr(raw, "page_content") and hasattr(raw, "metadata"):
        content = str(getattr(raw, "page_content") or "")
        meta = dict(getattr(raw, "metadata") or {})
        if not content.strip():
            return None
        channel = str(meta.get("channel") or meta.get("doc_type") or default_channel)
        source = str(meta.get("source") or meta.get("file_path") or meta.get("source_path") or meta.get("path") or "")
        title = str(meta.get("title") or meta.get("name") or meta.get("ref") or "")
        loc = str(meta.get("loc") or "")
        if not loc and meta.get("start_line"):
            loc = f"L{meta['start_line']}"
        elif not loc and meta.get("page"):
            loc = f"P{meta['page']}"
        score = (
            meta.get("relevance_score")
            if meta.get("relevance_score") is not None
            else meta.get("cosine_similarity")
            if meta.get("cosine_similarity") is not None
            else meta.get("score")
            if meta.get("score") is not None
            else meta.get("route_score", 0.0)
        )
        return EvidenceItem(
            channel=channel,
            content=content,
            source=source,
            title=title,
            loc=loc,
            score=float(score or 0.0),
            metadata=meta,
            raw_obj=raw,
        )

    if isinstance(raw, dict):
        content = str(raw.get("content") or raw.get("text") or raw.get("page_content") or raw.get("snippet") or "")
        if not content.strip():
            return None
        meta = dict(raw.get("metadata") or {})
        channel = str(raw.get("channel") or raw.get("type") or meta.get("doc_type") or default_channel)
        source = str(
            raw.get("source")
            or raw.get("path")
            or raw.get("obj")
            or raw.get("source_path")
            or raw.get("file_path")
            or raw.get("label")
            or meta.get("source")
            or ""
        )
        title = str(raw.get("title") or raw.get("ref") or raw.get("name") or meta.get("title") or "")
        loc = str(raw.get("loc") or meta.get("loc") or "")
        score = (
            raw.get("rank_score")
            if raw.get("rank_score") is not None
            else raw.get("score")
            if raw.get("score") is not None
            else raw.get("similarity", 0.0)
        )
        merged_meta = {**meta, **{k: v for k, v in raw.items() if k not in {"content", "text", "page_content"}}}
        return EvidenceItem(
            channel=channel,
            content=content,
            source=source,
            title=title,
            loc=loc,
            score=float(score or 0.0),
            metadata=merged_meta,
            raw_obj=raw,
        )

    text = str(raw).strip()
    if not text:
        return None
    return EvidenceItem(channel=default_channel, content=text, raw_obj=raw)


class EvidencePool:
    """Deduplicating evidence store with stable 1-based source_no across rounds."""

    def __init__(self) -> None:
        self.items: list[EvidenceItem] = []
        self._by_content_hash: dict[tuple[str, str], list[int]] = {}
        self._by_provenance: dict[tuple[str, str, str], int] = {}

    def add_many(self, raw_items: list[Any], default_channel: str) -> list[EvidenceItem]:
        added: list[EvidenceItem] = []
        for raw in raw_items or []:
            item = normalize_evidence(raw, default_channel=default_channel)
            if item is None:
                continue
            existing_idx = self._find_duplicate(item)
            if existing_idx is not None:
                existing = self.items[existing_idx]
                score = max(item.score, existing.score)
                if len(item.content) > len(existing.content) or (item.loc and not existing.loc):
                    updated = replace(item, score=score, source_no=existing.source_no)
                    self.items[existing_idx] = updated
                    self._index(updated, existing_idx)
                    added.append(updated)
                elif score > existing.score:
                    self.items[existing_idx] = replace(existing, score=score)
                continue
            idx = len(self.items)
            item = replace(item, source_no=idx + 1)
            self.items.append(item)
            self._index(item, idx)
            added.append(item)
        return added

    def _index(self, item: EvidenceItem, idx: int) -> None:
        chash = _norm_content_key(item.content)
        if chash:
            indices = self._by_content_hash.setdefault((item.source, chash), [])
            if idx not in indices:
                indices.append(idx)
        if item.source and item.loc:
            self._by_provenance[(item.channel, item.source, item.loc)] = idx

    def _find_duplicate(self, item: EvidenceItem) -> int | None:
        for idx in self._by_content_hash.get((item.source, _norm_content_key(item.content)), []):
            loc = self.items[idx].loc
            if not loc or not item.loc or loc == item.loc:
                return idx
        if item.source and item.loc:
            key = (item.channel, item.source, item.loc)
            return self._by_provenance.get(key)
        return None

    def top_score(self) -> float:
        return max((item.score for item in self.items), default=0.0)

    def has_channel(self, channels: set[str]) -> bool:
        return any(item.channel in channels for item in self.items)

    def compact_summary(self, *, max_items: int = 16, max_chars_per_item: int = 420) -> list[dict[str, Any]]:
        return [item.compact_dict(max_chars=max_chars_per_item) for item in self.items[:max_items]]


@dataclass
class RegisteredTool:
    name: str
    channel: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[..., Any]
    include_in_round0: bool = True
    round0_arg_builder: Callable[[str, list[str], list[str], int], dict[str, Any]] | None = None


class ToolRegistry:
    """Registry for pluggable retrieval tools shared by Round-0 fan-out and Agent Tool Calling."""

    def __init__(self) -> None:
        self._tools: dict[str, RegisteredTool] = {}

    def register(
        self,
        name: str,
        *,
        channel: str,
        description: str,
        parameters: dict[str, Any],
        handler: Callable[..., Any],
        include_in_round0: bool = True,
        round0_arg_builder: Callable[[str, list[str], list[str], int], dict[str, Any]] | None = None,
    ) -> "ToolRegistry":
        self._tools[name] = RegisteredTool(
            name=name,
            channel=channel,
            description=description,
            parameters=parameters,
            handler=handler,
            include_in_round0=include_in_round0,
            round0_arg_builder=round0_arg_builder,
        )
        return self

    def register_standard_four_way(
        self,
        *,
        vector_fn: Callable[..., Any] | None = None,
        bm25_fn: Callable[..., Any] | None = None,
        code_exact_fn: Callable[..., Any] | None = None,
        graph_fn: Callable[..., Any] | None = None,
        read_source_fn: Callable[..., Any] | None = None,
    ) -> "ToolRegistry":
        """Convenience wiring for the 4 standard intranet retrieval channels (+ optional source reader)."""
        if vector_fn is not None:
            self.register(
                "search_vector",
                channel="vector",
                description="语义向量召回（如 text-embedding-3-large），适合业务规则、概念解释、自然语言描述检索。",
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "自包含语义检索问句"},
                        "top_k": {"type": "integer", "default": 6, "description": "返回条数"},
                    },
                    "required": ["query"],
                },
                handler=vector_fn,
                include_in_round0=True,
                round0_arg_builder=lambda q, _ents, _files, top_k: {"query": q, "top_k": top_k},
            )
        if bm25_fn is not None:
            self.register(
                "search_bm25",
                channel="bm25",
                description="BM25 关键词精确词法召回，适合错误码、寄存器、字段名、配置项、专有术语检索。",
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "关键词或短语查询"},
                        "keywords": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "可选精确关键词列表",
                        },
                        "top_k": {"type": "integer", "default": 6},
                    },
                    "required": ["query"],
                },
                handler=bm25_fn,
                include_in_round0=True,
                round0_arg_builder=lambda q, ents, _files, top_k: {"query": q, "keywords": ents[:5], "top_k": top_k},
            )
        if code_exact_fn is not None:
            self.register(
                "search_code_exact",
                channel="code_exact",
                description="精确代码召回，适合定位具体程序、函数、段落、变量定义及粘贴代码的原始出处。",
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "代码片段、符号名或行为描述"},
                        "file_hint": {"type": "string", "description": "可选目标文件名或程序名"},
                        "top_k": {"type": "integer", "default": 6},
                    },
                    "required": ["query"],
                },
                handler=code_exact_fn,
                include_in_round0=True,
                round0_arg_builder=lambda q, _ents, files, top_k: {
                    "query": q,
                    "file_hint": files[0] if files else "",
                    "top_k": top_k,
                },
            )
        if graph_fn is not None:
            self.register(
                "search_graph",
                channel="graph",
                description="知识图谱召回，适合查询调用链（上游/下游）、模块依赖、影响面及跨文件结构关系。",
                parameters={
                    "type": "object",
                    "properties": {
                        "entity": {"type": "string", "description": "实体/程序/接口/错误码名称"},
                        "mode": {
                            "type": "string",
                            "enum": ["neighbors", "impact", "three_layer"],
                            "default": "neighbors",
                            "description": "neighbors=邻域关系, impact=影响面, three_layer=三层查全",
                        },
                        "depth": {"type": "integer", "default": 2},
                    },
                    "required": ["entity"],
                },
                handler=graph_fn,
                include_in_round0=True,
                round0_arg_builder=lambda q, ents, files, _top_k: {
                    "entity": (ents[0] if ents else (files[0] if files else q)),
                    "mode": "neighbors",
                    "depth": 2,
                },
            )
        if read_source_fn is not None:
            self.register(
                "read_source_context",
                channel="source",
                description="按文件路径与行号读取完整源码/文档上下文，用于核实调用条件或循环边界。",
                parameters={
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "文件路径"},
                        "start_line": {"type": "integer", "description": "起始行号（可选）"},
                        "end_line": {"type": "integer", "description": "结束行号（可选）"},
                    },
                    "required": ["file_path"],
                },
                handler=read_source_fn,
                include_in_round0=False,
            )
        return self

    def get(self, name: str) -> RegisteredTool | None:
        return self._tools.get(name)

    def round0_tools(self) -> list[RegisteredTool]:
        return [t for t in self._tools.values() if t.include_in_round0]

    def tool_names(self) -> list[str]:
        return list(self._tools.keys())

    def openai_tools(self) -> list[dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.parameters,
                },
            }
            for t in self._tools.values()
        ]

    def json_tool_catalog(self) -> str:
        """Compact tool catalog for JSON-protocol fallback mode."""
        lines = []
        for t in self._tools.values():
            props = t.parameters.get("properties", {})
            args_desc = ", ".join(f"{k}:{v.get('type', 'any')}" for k, v in props.items())
            lines.append(f"- {t.name}({args_desc}): {t.description}")
        return "\n".join(lines)

    async def invoke(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        pool: EvidencePool,
        call_cache: dict[str, dict[str, Any]],
        timeout: float = 8.0,
        semaphore: asyncio.Semaphore | None = None,
        max_summary_chars: int = 420,
    ) -> tuple[dict[str, Any], int]:
        """Execute one registered tool safely with dedup, timeout, and fail-open error handling."""
        tool = self._tools.get(name)
        if tool is None:
            return {"ok": False, "error": f"未知工具 {name}，可用工具：{self.tool_names()}"}, 0

        cache_key = f"{name}:{json.dumps(arguments or {}, sort_keys=True, ensure_ascii=False)}"
        if cache_key in call_cache:
            return {
                "ok": True,
                "cached_duplicate": True,
                "note": "该完全相同的工具查询此前已执行过，未新增证据。请换关键词/换工具，或直接结束检索。",
                "previous_count": call_cache[cache_key].get("returned_count", 0),
            }, 0

        filtered_args = _filter_kwargs(tool.handler, arguments or {})

        async def _call() -> Any:
            if inspect.iscoroutinefunction(tool.handler):
                return await tool.handler(**filtered_args)
            return await asyncio.to_thread(tool.handler, **filtered_args)

        try:
            if semaphore is not None:
                async with semaphore:
                    raw_res = await asyncio.wait_for(_call(), timeout=timeout)
            else:
                raw_res = await asyncio.wait_for(_call(), timeout=timeout)
        except asyncio.TimeoutError:
            return {"ok": False, "tool": name, "error": f"工具执行超时（>{timeout}s），请改用其他检索路或基于已有证据作答"}, 0
        except Exception as exc:
            return {"ok": False, "tool": name, "error": f"{type(exc).__name__}: {exc}"}, 0

        raw_list = raw_res if isinstance(raw_res, list) else ([] if raw_res is None else [raw_res])
        added_items = pool.add_many(raw_list, default_channel=tool.channel)
        payload = {
            "ok": True,
            "tool": name,
            "channel": tool.channel,
            "returned_count": len(raw_list),
            "new_evidence_count": len(added_items),
            "new_evidence": [item.compact_dict(max_chars=max_summary_chars) for item in added_items[:8]],
        }
        call_cache[cache_key] = payload
        return payload, len(added_items)


def _filter_kwargs(fn: Callable[..., Any], args: dict[str, Any]) -> dict[str, Any]:
    """Pass only accepted kwargs unless handler accepts **kwargs, ensuring resilient adapter calls."""
    try:
        sig = inspect.signature(fn)
    except (ValueError, TypeError):
        return args
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
        return args
    return {k: v for k, v in args.items() if k in sig.parameters}
