"""Pluggable KB Agent Toolkit: mainstream Agent topic-boundary context + bounded 4-way multi-round retrieval."""
from .agent_runner import AgentRunner
from .context_manager import (
    ContextManager,
    compact_history,
    extract_code_blocks,
    extract_files,
    extract_symbols,
    normalize_history,
)
from .llm_client import AsyncLLMAdapter, OpenAIHTTPAdapter, OpenAISDKAdapter, adapt_llm
from .strategy_router import StrategyRouter
from .tool_registry import EvidencePool, RegisteredTool, ToolRegistry, normalize_evidence
from .types import (
    AgentConfig,
    AgentEvent,
    AgentResult,
    ChatTurn,
    ContextAnalysis,
    EvidenceItem,
    LLMResponse,
    RouteDecision,
    RunMode,
    ToolCallRequest,
    ToolProtocol,
    TopicRelation,
    TraceStep,
)

__all__ = [
    "AgentConfig",
    "AgentEvent",
    "AgentResult",
    "AgentRunner",
    "AsyncLLMAdapter",
    "ChatTurn",
    "ContextAnalysis",
    "ContextManager",
    "EvidenceItem",
    "EvidencePool",
    "LLMResponse",
    "OpenAIHTTPAdapter",
    "OpenAISDKAdapter",
    "RegisteredTool",
    "RouteDecision",
    "RunMode",
    "StrategyRouter",
    "ToolCallRequest",
    "ToolProtocol",
    "ToolRegistry",
    "TopicRelation",
    "TraceStep",
    "adapt_llm",
    "compact_history",
    "extract_code_blocks",
    "extract_files",
    "extract_symbols",
    "normalize_evidence",
    "normalize_history",
]
