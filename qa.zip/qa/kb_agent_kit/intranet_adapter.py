"""Build a retrieval runner and map progress events for an intranet QA service.

Copy `kb_agent_kit/` into the intranet Python service and bind the 4 retrieval
callbacks to the current request's authorized scope. The host keeps ownership
of the original QA route, reranker, answer generation, and source validation.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator

from .agent_runner import AgentRunner
from .tool_registry import ToolRegistry
from .types import AgentConfig, AgentResult, RunMode, ToolProtocol


def create_intranet_agent_runner(
    *,
    openai_6luna_client: Any,
    intranet_vector_search: Any,
    intranet_bm25_search: Any,
    intranet_code_exact_search: Any,
    intranet_graph_search: Any,
    intranet_read_source: Any = None,
    retrieve_semaphore: asyncio.Semaphore | None = None,
    llm_semaphore: asyncio.Semaphore | None = None,
    model_name: str = "6luna",
    tool_protocol: ToolProtocol = "tool_calls",
    use_llm_context_analysis: bool = True,
) -> AgentRunner:
    """Inject retrievers that apply the caller's permissions before returning evidence."""
    registry = ToolRegistry().register_standard_four_way(
        vector_fn=intranet_vector_search,
        bm25_fn=intranet_bm25_search,
        code_exact_fn=intranet_code_exact_search,
        graph_fn=intranet_graph_search,
        read_source_fn=intranet_read_source,
    )
    config = AgentConfig(
        model=model_name,
        tool_protocol=tool_protocol,
        max_rounds=4,
        max_empty_rounds=1,
        total_timeout_sec=35.0,
        per_tool_timeout_sec=8.0,
        min_sufficient_score=0.45,
        use_llm_context_analysis=use_llm_context_analysis,
    )
    return AgentRunner(
        registry=registry,
        llm=openai_6luna_client,
        config=config,
        retrieve_semaphore=retrieve_semaphore,
        llm_semaphore=llm_semaphore,
    )


async def intranet_rag_hs_plugin_retrieve(
    runner: AgentRunner,
    *,
    query: str,
    history: list[Any],
    message_id: str = "",
    mode: RunMode | None = None,
    initial_docs: list[Any] | None = None,
) -> AsyncIterator[tuple[str | None, AgentResult | None]]:
    """Run from the enabled branch of a rag_hs-master style QA endpoint.

    Yields:
      - (sse_json_str, None) for each mapped retrieval progress event
      - (None, AgentResult) on completion; pass `result.raw_documents` directly into existing Reranker / assemble
    """
    async for ev in runner.retrieve_stream(
        query,
        history=history,
        mode=mode,
        initial_evidence=initial_docs,
    ):
        if ev.type == "done":
            yield None, ev.data["result"]
            return
        sse_obj = ev.to_rag_hs_event(message_id=message_id)
        if sse_obj is not None:
            yield json.dumps(sse_obj, ensure_ascii=False), None
