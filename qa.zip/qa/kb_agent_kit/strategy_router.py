"""Module 3: Adaptive execution strategy router (Fast single-pass vs. Multi-round Agent loop)."""
from __future__ import annotations

import os
import re

from .types import AgentConfig, ContextAnalysis, EvidenceItem, RouteDecision, RunMode

COMPLEX_INTENT_RE = re.compile(
    r"(?:调用链|上游|下游|影响面|波及|改动|变更|跨(?:文件|程序|模块|文档|库)|多跳|"
    r"完整流程|全流程|逐步排查|排查路径|对比|比较|区别|差异|相似(?:代码|实现|逻辑)|"
    r"(?:完整|所有|全部|全量).{0,10}(?:字段|依赖|调用|流程|报错)|"
    r"\b(?:call\s+chain|multi[- ]hop|impact|compare|diff|upstream|downstream|trace)\b)",
    re.I,
)
CODE_GRAPH_NEED_RE = re.compile(
    r"(?:代码|源码|函数|程序|段落|调用|perform|call\b|copybook|copy\b|寄存器|文件|\.cbl|\.cpy|\.c\b|\.py\b)",
    re.I,
)


class StrategyRouter:
    """Decide whether Round-0 retrieval is enough or should escalate to multi-round Agent loop."""

    def __init__(self, config: AgentConfig | None = None) -> None:
        self.config = config or AgentConfig()

    def is_enabled(self) -> bool:
        env_enabled = os.environ.get("HAISI_AGENT_LOOP_ENABLED")
        if env_enabled is not None and env_enabled.strip().lower() in {"0", "false", "off", "no"}:
            return False
        return self.config.enabled

    def resolve_mode(self, requested_mode: RunMode | None = None) -> RunMode:
        if not self.is_enabled():
            return "single"
        if requested_mode in {"auto", "single", "agent"}:
            return requested_mode
        env_mode = (os.environ.get("KB_AGENT_MODE") or "").strip().lower()
        if env_mode in {"auto", "single", "agent"}:
            return env_mode  # type: ignore[return-value]
        return self.config.default_mode

    def decide_after_round0(
        self,
        query: str,
        analysis: ContextAnalysis,
        round0_evidence: list[EvidenceItem],
        *,
        requested_mode: RunMode | None = None,
    ) -> RouteDecision:
        mode = self.resolve_mode(requested_mode)
        count = len(round0_evidence)
        top_score = max((e.score for e in round0_evidence), default=0.0)
        channels = {e.channel for e in round0_evidence}

        if mode == "single":
            return RouteDecision(
                enter_agent=False,
                mode="single",
                reason="当前为 single 模式（或总开关关闭），直接采用首轮四路召回结果",
                round0_count=count,
                round0_top_score=top_score,
            )

        if mode == "agent":
            return RouteDecision(
                enter_agent=True,
                mode="agent",
                reason="显式指定 agent 模式，进入多轮迭代检索",
                suggested_tools=["search_graph", "search_code_exact", "search_bm25", "search_vector"],
                round0_count=count,
                round0_top_score=top_score,
            )

        probe = f"{query} {analysis.standalone_query}"
        if analysis.topic_relation == "cross_turn" or len(analysis.sub_queries) > 1:
            return RouteDecision(
                enter_agent=True,
                mode="auto",
                reason="检测到跨轮关联/多子查询对比需求，升级进入多轮 Agent 检索",
                suggested_tools=["search_vector", "search_bm25", "search_code_exact", "search_graph"],
                round0_count=count,
                round0_top_score=top_score,
            )

        if COMPLEX_INTENT_RE.search(probe):
            return RouteDecision(
                enter_agent=True,
                mode="auto",
                reason="命中复杂分析意图（调用链/影响面/跨文件/对比/多跳），升级进入多轮 Agent 检索",
                suggested_tools=["search_graph", "search_code_exact", "search_bm25"],
                round0_count=count,
                round0_top_score=top_score,
            )

        if count == 0:
            return RouteDecision(
                enter_agent=True,
                mode="auto",
                reason="首轮四路召回结果为空，升级进入多轮 Agent 尝试换词与多路补查",
                suggested_tools=["search_bm25", "search_vector", "search_code_exact", "search_graph"],
                round0_count=0,
                round0_top_score=0.0,
            )

        has_nonzero_scores = any(e.score > 0 for e in round0_evidence)
        if has_nonzero_scores and top_score < self.config.min_sufficient_score:
            return RouteDecision(
                enter_agent=True,
                mode="auto",
                reason=f"首轮最高相关分 {top_score:.3f} 低于阈值 {self.config.min_sufficient_score}，升级补充检索",
                suggested_tools=["search_bm25", "search_code_exact", "search_vector"],
                round0_count=count,
                round0_top_score=top_score,
            )

        if CODE_GRAPH_NEED_RE.search(probe) and not (channels & {"code_exact", "graph", "code"}):
            return RouteDecision(
                enter_agent=True,
                mode="auto",
                reason="问题涉及代码/调用关系但首轮缺少代码与图谱证据，升级定向补查",
                suggested_tools=["search_code_exact", "search_graph"],
                round0_count=count,
                round0_top_score=top_score,
            )

        return RouteDecision(
            enter_agent=False,
            mode="auto",
            reason=f"常规问答且首轮已命中 {count} 条充分证据（top_score={top_score:.3f}），跳过多轮循环以保低延迟",
            round0_count=count,
            round0_top_score=top_score,
        )
