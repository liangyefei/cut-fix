"""Module 4: Bounded multi-round Agent retrieval & QA runner for OpenAI 6luna.

Supports two pluggable usage patterns:
  1. Pure retrieval plugin: retrieve_stream() / retrieve()
     Runs context topic-boundary analysis -> Round-0 4-way recall -> bounded multi-round
     tool calling -> returns deduplicated EvidencePool + raw_documents for existing generators.
  2. End-to-end verification: chat_stream() / chat() / compare_modes()
     Also synthesizes grounded answers with conversation history for side-by-side A/B validation.
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Any, AsyncIterator

from .context_manager import ContextManager, _extract_json_obj, _file_stem, _new_topic, extract_files, extract_symbols
from .llm_client import AsyncLLMAdapter, adapt_llm
from .strategy_router import StrategyRouter
from .tool_registry import EvidencePool, ToolRegistry
from .types import (
    AgentConfig,
    AgentEvent,
    AgentResult,
    ContextAnalysis,
    EvidenceItem,
    RunMode,
    ToolCallRequest,
    TraceStep,
)

PLANNER_SYSTEM_PROMPT = """你是企业知识库的多轮证据检索规划器（Agent Planner）。
你的唯一职责是：审视当轮独立检索问题、子查询和首轮四路召回证据，判断是否需要调用工具补齐缺失证据。

核心原则：
1. 已有证据足以回答问题时，立即停止调用工具并简短回复“证据已充分”，不要为了填满轮次而重复检索。
2. 遇到以下情况时，定向调用最合适的工具（支持单轮并发调用多个工具）：
   - 需要查业务规则/概念说明 -> search_vector
   - 需要查错误码/寄存器/精确字段名 -> search_bm25
   - 需要查具体函数/程序/文件/代码出处 -> search_code_exact
   - 需要查调用链/上游/下游/影响面/依赖关系 -> search_graph
   - 已定位文件行号但片段截断需要看上下文 -> read_source_context（若可用）
3. 严禁重复发起完全相同的工具查询；如换词后仍无新证据，直接停止。
4. 对比时检查每个对象是否有各自的证据。只有检索证据显示其他对象与当前问题相关时，才追查该对象。
5. 切勿编造任何不存在的代码、数值或文档事实。"""

JSON_PROTOCOL_ADDON = """
当前运行在 JSON 协议模式，请严格按以下 JSON 格式决策（不要输出其他内容）：
- 需要继续检索时：
  {"done": false, "reason": "缺什么证据", "tool_calls": [{"name": "工具名", "arguments": {...}}]}
- 证据已充分可以结束时：
  {"done": true, "reason": "证据已充分"}

可用工具清单：
"""

ANSWER_SYSTEM_PROMPT = """你是企业核心系统知识库问答助手。请基于提供的【检索证据】回答用户问题。
要求：
1. 只基于本次检索证据作答，事实陈述末尾用 [1]、[2] 标注对应证据编号；
2. 独立检索问题用于解析指代。对比时分别引用每个对象的证据，缺少某一侧时明确说明；
3. 如果检索证据不足以确认核心问题，必须明确说明“当前检索到的资料未覆盖该信息”，禁止编造；
4. 区分静态调用关系（如 CALL/图谱边）与运行时必然执行条件，不把猜测说成确定事实。"""


def _format_evidence_for_answer(items: list[EvidenceItem], max_chars: int = 8000) -> str:
    lines: list[str] = []
    used = 0
    for item in items:
        header = f"[{item.source_no}] ({item.channel}) {item.title or item.source}"
        if item.loc:
            header += f" {item.loc}"
        body = (item.content or "").strip()
        block = f"{header}\n{body}"
        if used + len(block) > max_chars and lines:
            remaining = max(0, max_chars - used - len(header) - 20)
            if remaining > 120:
                lines.append(f"{header}\n{body[:remaining]}...")
            break
        lines.append(block)
        used += len(block)
    return "\n\n".join(lines) if lines else "（未检索到相关证据）"


def _parse_json_protocol_calls(raw: str) -> tuple[bool, list[ToolCallRequest], str]:
    parsed = _extract_json_obj(raw)
    if not parsed:
        return True, [], "JSON 规划输出为空或无法解析，结束检索"
    if parsed.get("done") is True:
        return True, [], str(parsed.get("reason") or "证据已充分")
    raw_calls = parsed.get("tool_calls") or []
    calls: list[ToolCallRequest] = []
    for idx, item in enumerate(raw_calls, start=1):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        args = item.get("arguments")
        if name:
            calls.append(
                ToolCallRequest(
                    id=f"json_call_{idx}",
                    name=name,
                    arguments=args if isinstance(args, dict) else {},
                )
            )
    return (len(calls) == 0), calls, str(parsed.get("reason") or "")


class AgentRunner:
    """Mainstream Agent multi-round retrieval & QA orchestrator."""

    def __init__(
        self,
        registry: ToolRegistry,
        llm: Any = None,
        *,
        config: AgentConfig | None = None,
        context_manager: ContextManager | None = None,
        router: StrategyRouter | None = None,
        retrieve_semaphore: asyncio.Semaphore | None = None,
        llm_semaphore: asyncio.Semaphore | None = None,
    ) -> None:
        self.registry = registry
        self.config = config or AgentConfig()
        self.llm: AsyncLLMAdapter | None = adapt_llm(llm, model=self.config.model) if llm is not None else None
        self.context_manager = context_manager or ContextManager(
            max_history_turns=self.config.max_history_turns,
            max_history_chars=self.config.max_history_chars,
            max_sub_queries=self.config.max_sub_queries,
        )
        self.router = router or StrategyRouter(self.config)
        self.retrieve_semaphore = retrieve_semaphore
        self.llm_semaphore = llm_semaphore

    # ------------------------------------------------------------------
    # Mode 1: Pure retrieval plugin (zero-invasion handoff to intranet generator)
    # ------------------------------------------------------------------
    async def retrieve_stream(
        self,
        question: str,
        *,
        history: list[Any] | None = None,
        mode: RunMode | None = None,
        initial_evidence: list[Any] | None = None,
    ) -> AsyncIterator[AgentEvent]:
        """Run topic-boundary analysis + Round-0 4-way recall + optional multi-round Agent loop.

        Yields AgentEvent objects; the final event has type="done" and data["result"] = AgentResult.
        Supplied evidence must belong to the current question and request scope.
        """
        async for event in self._retrieve_stream(question, history, mode, initial_evidence):
            yield event

    async def _retrieve_stream(
        self,
        question: str,
        history: list[Any] | None,
        mode: RunMode | None,
        initial_evidence: list[Any] | None,
        *,
        baseline: AgentResult | None = None,
        call_cache: dict[str, dict[str, Any]] | None = None,
    ) -> AsyncIterator[AgentEvent]:
        started = time.monotonic()
        trace: list[TraceStep] = []
        pool = EvidencePool()
        if call_cache is None:
            call_cache = {}
        baseline_ms = baseline.elapsed_ms if baseline else 0
        degraded = False
        rounds_executed = 0

        # Stage 1: Conversation context & topic boundary analysis
        t_ctx = time.monotonic()
        if baseline is not None:
            assert baseline.context_analysis is not None
            analysis = baseline.context_analysis
        elif self.router.is_enabled():
            analysis = await self.context_manager.analyze(
                question,
                history,
                llm=self.llm,
                use_llm=self.config.use_llm_context_analysis and self.llm is not None,
                timeout=self.config.context_llm_timeout_sec,
            )
        else:
            analysis = _new_topic(question.strip(), "多轮功能关闭，按当轮问题检索")
        ctx_ms = round((time.monotonic() - t_ctx) * 1000)
        trace.append(
            TraceStep(
                round_no=0,
                stage="context",
                detail=f"relation={analysis.topic_relation}, standalone={analysis.standalone_query[:80]}",
                elapsed_ms=ctx_ms,
            )
        )
        yield AgentEvent(
            type="context",
            content=f"话题判定：{analysis.topic_relation}（{analysis.reason}）",
            data={
                "topic_relation": analysis.topic_relation,
                "standalone_query": analysis.standalone_query,
                "sub_queries": analysis.sub_queries,
                "carry_entities": analysis.carry_entities,
                "carry_files": analysis.carry_files,
            },
        )

        # Stage 2: Round-0 baseline 4-way retrieval (or accept caller-supplied Round-0 results)
        t_r0 = time.monotonic()
        if baseline is not None:
            pool.add_many(baseline.evidence, default_channel="vector")
            r0_detail = f"复用 A/B 首轮证据 {len(pool.items)} 条"
        elif (initial_evidence is not None and analysis.sub_queries == [question.strip()]
              and not analysis.inherited_code):
            added_r0 = pool.add_many(initial_evidence, default_channel="vector")
            r0_detail = f"复用外部首轮召回证据 {len(added_r0)} 条"
        else:
            yield AgentEvent(type="status", content="正在执行首轮四路融合检索（向量 / BM25 / 精确代码 / 图谱）...")
            added_r0_count = await self._run_round0(analysis, pool, call_cache)
            r0_detail = f"首轮四路召回新增 {added_r0_count} 条去重证据（queries={len(analysis.sub_queries)}）"
        r0_ms = round((time.monotonic() - t_r0) * 1000)
        trace.append(
            TraceStep(round_no=0, stage="round0", detail=r0_detail, added_count=len(pool.items), elapsed_ms=r0_ms)
        )

        # Stage 3: Adaptive strategy routing
        decision = self.router.decide_after_round0(
            question,
            analysis,
            pool.items,
            requested_mode=mode,
        )
        trace.append(
            TraceStep(
                round_no=0,
                stage="route",
                detail=f"enter_agent={decision.enter_agent} ({decision.reason})",
            )
        )

        # Stage 4: Bounded multi-round Agent tool-calling loop
        if decision.enter_agent and self.llm is not None and self.registry.tool_names():
            yield AgentEvent(
                type="status",
                content=f"已启动多轮深度检索（{decision.reason}）",
                data={"mode": decision.mode, "suggested_tools": decision.suggested_tools},
            )
            planner_messages = self._build_planner_messages(question, analysis, pool)

            empty_rounds = 0
            for round_no in range(1, max(1, self.config.max_rounds) + 1):
                elapsed_so_far = time.monotonic() - started + baseline_ms / 1000
                if elapsed_so_far >= self.config.total_timeout_sec:
                    trace.append(
                        TraceStep(
                            round_no=round_no,
                            stage="early_stop",
                            detail=f"达到总耗时预算 {self.config.total_timeout_sec}s，带现有 {len(pool.items)} 条证据收口",
                        )
                    )
                    yield AgentEvent(type="status", content="检索达到耗时上限，正在基于已收集证据整理结果...")
                    break

                remaining_budget = self.config.total_timeout_sec - elapsed_so_far
                llm_timeout = min(self.config.llm_timeout_sec, remaining_budget)
                t_plan = time.monotonic()

                try:
                    calls, assistant_msg, stop_reason = await self._plan_next_step(
                        planner_messages, timeout=llm_timeout
                    )
                except Exception as exc:
                    degraded = True
                    trace.append(
                        TraceStep(
                            round_no=round_no,
                            stage="error",
                            detail=f"规划调用异常（fail-open 收口）: {type(exc).__name__}: {exc}",
                            elapsed_ms=round((time.monotonic() - t_plan) * 1000),
                        )
                    )
                    yield AgentEvent(type="status", content="多轮规划降级，基于已检索证据继续回答...")
                    break

                if not calls:
                    trace.append(
                        TraceStep(
                            round_no=round_no,
                            stage="early_stop",
                            detail=stop_reason or "模型判断证据已充分，结束多轮检索",
                            elapsed_ms=round((time.monotonic() - t_plan) * 1000),
                        )
                    )
                    yield AgentEvent(type="status", content=f"第 {round_no} 轮未安排进一步补查")
                    break

                rounds_executed = round_no
                if assistant_msg is not None:
                    planner_messages.append(assistant_msg)

                tool_desc = "、".join(f"{c.name}({_short_args(c.arguments)})" for c in calls)
                yield AgentEvent(
                    type="tool_call",
                    content=f"第 {round_no} 轮补充检索：{tool_desc}",
                    data={
                        "round": round_no,
                        "calls": [{"id": c.id, "name": c.name, "arguments": c.arguments} for c in calls],
                    },
                )

                t_exec = time.monotonic()
                exec_results = await asyncio.gather(
                    *[
                        self.registry.invoke(
                            c.name,
                            c.arguments,
                            pool=pool,
                            call_cache=call_cache,
                            timeout=min(self.config.per_tool_timeout_sec, remaining_budget),
                            semaphore=self.retrieve_semaphore,
                            max_summary_chars=self.config.max_tool_summary_chars,
                        )
                        for c in calls
                    ]
                )
                exec_ms = round((time.monotonic() - t_exec) * 1000)

                round_added = 0
                tool_feedback_blocks: list[dict[str, Any]] = []
                for call, (payload, added_cnt) in zip(calls, exec_results):
                    round_added += added_cnt
                    trace.append(
                        TraceStep(
                            round_no=round_no,
                            stage="tool_call",
                            tool_name=call.name,
                            arguments=call.arguments,
                            detail=f"returned={payload.get('returned_count', 0)}, new={added_cnt}, ok={payload.get('ok')}",
                            added_count=added_cnt,
                            elapsed_ms=exec_ms,
                        )
                    )
                    tool_feedback_blocks.append({"call": call, "payload": payload})

                yield AgentEvent(
                    type="tool_result",
                    content=f"第 {round_no} 轮完成，新增 {round_added} 条去重证据（累计 {len(pool.items)} 条）",
                    data={"round": round_no, "added": round_added, "total": len(pool.items)},
                )

                # Feed tool results back into planner conversation
                if self.config.tool_protocol == "tool_calls":
                    for block in tool_feedback_blocks:
                        planner_messages.append(
                            {
                                "role": "tool",
                                "tool_call_id": block["call"].id,
                                "content": json.dumps(block["payload"], ensure_ascii=False),
                            }
                        )
                else:
                    summary_json = json.dumps(
                        [{"tool": b["call"].name, "result": b["payload"]} for b in tool_feedback_blocks],
                        ensure_ascii=False,
                    )
                    planner_messages.append(
                        {
                            "role": "user",
                            "content": f"第 {round_no} 轮工具返回结果：\n{summary_json}\n请决定是否还需继续检索，或输出 done=true。",
                        }
                    )

                if round_added == 0:
                    empty_rounds += 1
                    if empty_rounds >= max(1, self.config.max_empty_rounds):
                        trace.append(
                            TraceStep(
                                round_no=round_no,
                                stage="early_stop",
                                detail=f"连续 {empty_rounds} 轮无新增去重证据，提前终止循环",
                            )
                        )
                        yield AgentEvent(type="status", content="未发现更多增量资料，结束检索并整理回答...")
                        break
                else:
                    empty_rounds = 0
        elif decision.enter_agent and self.llm is None:
            trace.append(
                TraceStep(
                    round_no=0,
                    stage="early_stop",
                    detail="未配置规划 LLM，跳过多轮规划循环（仅保留 Round-0 四路召回）",
                )
            )

        result = AgentResult(
            query=question,
            evidence=list(pool.items),
            context_analysis=analysis,
            route_decision=decision,
            trace=trace,
            rounds_executed=rounds_executed,
            elapsed_ms=round((time.monotonic() - started) * 1000) + baseline_ms,
            mode_used=decision.mode,
            degraded=degraded,
        )
        yield AgentEvent(
            type="sources",
            content=f"检索完成，共汇集 {len(result.evidence)} 条去重证据",
            data={"sources": [e.compact_dict(max_chars=240) for e in result.evidence]},
        )
        yield AgentEvent(type="done", content="retrieve_done", data={"result": result})

    async def retrieve(
        self,
        question: str,
        *,
        history: list[Any] | None = None,
        mode: RunMode | None = None,
        initial_evidence: list[Any] | None = None,
    ) -> AgentResult:
        """Non-streaming convenience wrapper for pure retrieval plugin mode."""
        final: AgentResult | None = None
        async for ev in self.retrieve_stream(
            question, history=history, mode=mode, initial_evidence=initial_evidence
        ):
            if ev.type == "done":
                final = ev.data["result"]
        assert final is not None
        return final

    # ------------------------------------------------------------------
    # Mode 2: End-to-end QA & A/B verification
    # ------------------------------------------------------------------
    async def chat_stream(
        self,
        question: str,
        *,
        history: list[Any] | None = None,
        mode: RunMode | None = None,
        system_prompt: str | None = None,
    ) -> AsyncIterator[AgentEvent]:
        """Full end-to-end streaming QA (context -> multi-round retrieval -> grounded answer)."""
        started = time.monotonic()
        result: AgentResult | None = None
        async for ev in self.retrieve_stream(question, history=history, mode=mode):
            if ev.type == "done":
                result = ev.data["result"]
                continue
            yield ev

        assert result is not None
        async for event in self._answer_stream(result, system_prompt=system_prompt):
            yield event
        result.elapsed_ms = round((time.monotonic() - started) * 1000)
        yield AgentEvent(type="done", content="chat_done", data={"result": result})

    async def _answer_stream(
        self, result: AgentResult, *, system_prompt: str | None = None
    ) -> AsyncIterator[AgentEvent]:
        t_gen = time.monotonic()
        answer_messages = self._build_answer_messages(
            result.query,
            result.context_analysis,
            result.evidence,
            system_prompt=system_prompt,
        )

        chunks: list[str] = []
        if not result.evidence:
            fallback = "当前检索到的资料未覆盖该信息。"
            chunks.append(fallback)
            yield AgentEvent(type="answer_delta", content=fallback)
        elif self.llm is None:
            fallback = _offline_evidence_summary(result.query, result.evidence)
            chunks.append(fallback)
            yield AgentEvent(type="answer_delta", content=fallback)
        else:
            try:
                if self.llm_semaphore is not None:
                    async with self.llm_semaphore:
                        async for piece in self.llm.stream_text(
                            answer_messages,
                            temperature=self.config.answer_temperature,
                            timeout=max(30.0, self.config.llm_timeout_sec),
                        ):
                            chunks.append(piece)
                            yield AgentEvent(type="answer_delta", content=piece)
                else:
                    async for piece in self.llm.stream_text(
                        answer_messages,
                        temperature=self.config.answer_temperature,
                        timeout=max(30.0, self.config.llm_timeout_sec),
                    ):
                        chunks.append(piece)
                        yield AgentEvent(type="answer_delta", content=piece)
            except Exception as exc:
                result.degraded = True
                yield AgentEvent(type="error", content=f"回答生成失败：{type(exc).__name__}: {exc}")

        result.answer = "".join(chunks).strip()
        answer_ms = round((time.monotonic() - t_gen) * 1000)
        result.trace.append(
            TraceStep(
                round_no=result.rounds_executed,
                stage="answer",
                detail=f"生成答案 {len(result.answer)} 字",
                elapsed_ms=answer_ms,
            )
        )
        result.elapsed_ms += answer_ms

    async def chat(
        self,
        question: str,
        *,
        history: list[Any] | None = None,
        mode: RunMode | None = None,
        system_prompt: str | None = None,
    ) -> AgentResult:
        final: AgentResult | None = None
        async for ev in self.chat_stream(
            question, history=history, mode=mode, system_prompt=system_prompt
        ):
            if ev.type == "done":
                final = ev.data["result"]
        assert final is not None
        return final

    async def compare_modes(
        self,
        question: str,
        *,
        history: list[Any] | None = None,
        generate_answer: bool = False,
    ) -> dict[str, Any]:
        """Side-by-side A/B verification comparing single-pass 4-way vs. adaptive multi-round Agent."""
        results: list[AgentResult] = []
        call_cache: dict[str, dict[str, Any]] = {}
        for mode in ("single", "auto"):
            async for event in self._retrieve_stream(
                question, history, mode, None,
                baseline=results[0] if results else None, call_cache=call_cache,
            ):
                if event.type == "done":
                    results.append(event.data["result"])
        single_res, agent_res = results
        if generate_answer:
            for result in (single_res, agent_res):
                async for _ in self._answer_stream(result):
                    pass

        single_keys = {f"{e.channel}:{e.source}:{e.loc}" for e in single_res.evidence}
        agent_keys = {f"{e.channel}:{e.source}:{e.loc}" for e in agent_res.evidence}
        return {
            "question": question,
            "single": single_res.summary_report(),
            "agent": agent_res.summary_report(),
            "shared_round0": True,
            "delta": {
                "extra_evidence_count": len(agent_res.evidence) - len(single_res.evidence),
                "new_provenances": sorted(agent_keys - single_keys),
                "extra_rounds": agent_res.rounds_executed,
                "latency_diff_ms": agent_res.elapsed_ms - single_res.elapsed_ms,
            },
            "single_answer": single_res.answer,
            "agent_answer": agent_res.answer,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    async def _run_round0(
        self,
        analysis: ContextAnalysis,
        pool: EvidencePool,
        call_cache: dict[str, dict[str, Any]],
    ) -> int:
        tools = self.registry.round0_tools()
        if not tools:
            return 0

        tasks = []
        queries = analysis.sub_queries[: self.config.max_sub_queries]
        for sub_q in queries:
            effective_q = sub_q
            entities, files = analysis.carry_entities, analysis.carry_files
            if analysis.topic_relation == "cross_turn" or len(queries) > 1:
                entities, files = extract_symbols(sub_q), extract_files(sub_q)
            if files:
                stem = _file_stem(files[0])
                entities = list(dict.fromkeys([stem, *entities]))
            if analysis.inherited_code and sub_q == analysis.standalone_query:
                effective_q = f"{sub_q}\n{analysis.inherited_code}"
            for tool in tools:
                if tool.round0_arg_builder is not None:
                    args = tool.round0_arg_builder(
                        effective_q,
                        entities,
                        files,
                        self.config.round0_top_k,
                    )
                else:
                    args = {"query": effective_q, "top_k": self.config.round0_top_k}
                tasks.append(
                    self.registry.invoke(
                        tool.name,
                        args,
                        pool=pool,
                        call_cache=call_cache,
                        timeout=self.config.per_tool_timeout_sec,
                        semaphore=self.retrieve_semaphore,
                        max_summary_chars=self.config.max_tool_summary_chars,
                    )
                )

        results = await asyncio.gather(*tasks, return_exceptions=True)
        total_added = 0
        for res in results:
            if isinstance(res, tuple):
                total_added += res[1]
        return total_added

    def _build_planner_messages(
        self,
        question: str,
        analysis: ContextAnalysis,
        pool: EvidencePool,
    ) -> list[dict[str, Any]]:
        sys_prompt = PLANNER_SYSTEM_PROMPT
        if self.config.tool_protocol == "json":
            sys_prompt += "\n" + JSON_PROTOCOL_ADDON + self.registry.json_tool_catalog()

        messages: list[dict[str, Any]] = [{"role": "system", "content": sys_prompt}]
        seed_payload = {
            "user_question": question,
            "topic_relation": analysis.topic_relation,
            "standalone_query": analysis.standalone_query,
            "sub_queries": analysis.sub_queries,
            "carry_entities": analysis.carry_entities,
            "carry_files": analysis.carry_files,
            "round0_evidence_count": len(pool.items),
            "round0_evidence": pool.compact_summary(
                max_items=self.config.max_evidence_in_planner,
                max_chars_per_item=self.config.max_tool_summary_chars,
            ),
            "instruction": "请审视首轮证据是否足以完整回答用户问题；如缺少调用链、代码定义、错误码或对比对象，请调用对应工具补充，否则直接结束。",
        }
        messages.append({"role": "user", "content": json.dumps(seed_payload, ensure_ascii=False)})
        return messages

    async def _plan_next_step(
        self,
        planner_messages: list[dict[str, Any]],
        *,
        timeout: float,
    ) -> tuple[list[ToolCallRequest], dict[str, Any] | None, str]:
        assert self.llm is not None
        use_native_tools = self.config.tool_protocol == "tool_calls"

        async def _invoke_llm():
            return await self.llm.complete(
                planner_messages,
                tools=self.registry.openai_tools() if use_native_tools else None,
                temperature=self.config.planner_temperature,
                json_mode=not use_native_tools,
                timeout=timeout,
                parallel_tool_calls=self.config.parallel_tool_calls,
            )

        if self.llm_semaphore is not None:
            async with self.llm_semaphore:
                resp = await _invoke_llm()
        else:
            resp = await _invoke_llm()

        if use_native_tools:
            if not resp.tool_calls:
                return [], None, (resp.content or "模型未请求工具，证据已充分")[:160]
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": resp.content or None,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False),
                        },
                    }
                    for tc in resp.tool_calls
                ],
            }
            if resp.reasoning_content:
                assistant_msg["reasoning_content"] = resp.reasoning_content
            return resp.tool_calls, assistant_msg, ""

        done, calls, reason = _parse_json_protocol_calls(resp.content)
        if done or not calls:
            return [], None, reason or "模型返回 done=true"
        return calls, {"role": "assistant", "content": resp.content}, reason

    def _build_answer_messages(
        self,
        question: str,
        analysis: ContextAnalysis | None,
        evidence: list[EvidenceItem],
        *,
        system_prompt: str | None = None,
    ) -> list[dict[str, Any]]:
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt or ANSWER_SYSTEM_PROMPT}
        ]
        evidence_text = _format_evidence_for_answer(evidence)
        resolved = analysis.standalone_query if analysis else question
        messages.append(
            {
                "role": "user",
                "content": f"【检索证据】\n{evidence_text}\n\n【独立检索问题】\n{resolved}\n\n【当前问题】\n{question}",
            }
        )
        return messages


def _short_args(args: dict[str, Any]) -> str:
    parts = [f"{k}={str(v)[:28]}" for k, v in (args or {}).items() if v not in ("", None, [])]
    return ", ".join(parts[:3])


def _offline_evidence_summary(question: str, evidence: list[EvidenceItem]) -> str:
    if not evidence:
        return f"【离线验证模式】针对“{question}”未检索到相关证据。"
    lines = [f"【离线验证模式】共收集 {len(evidence)} 条去重证据（配置 6luna 后由模型综合生成）："]
    for item in evidence[:5]:
        preview = re.sub(r"\s+", " ", item.content.strip())[:140]
        lines.append(f"[{item.source_no}] ({item.channel}) {item.title or item.source} {item.loc}: {preview}")
    return "\n".join(lines)
