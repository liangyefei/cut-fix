"""OpenAI-compatible LLM adapter supporting AsyncOpenAI/OpenAI (e.g. 6luna), httpx, and Mock/custom LLMs."""
from __future__ import annotations

import asyncio
import inspect
import json
import urllib.request
from typing import Any, AsyncIterator, Protocol, runtime_checkable

from .types import LLMResponse, ToolCallRequest


@runtime_checkable
class AsyncLLMAdapter(Protocol):
    """Minimal async interface required by ContextManager and AgentRunner."""

    async def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.1,
        json_mode: bool = False,
        timeout: float = 20.0,
        parallel_tool_calls: bool = True,
    ) -> LLMResponse: ...

    async def stream_text(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
        timeout: float = 60.0,
    ) -> AsyncIterator[str]: ...


def _parse_tool_calls(raw_tool_calls: Any) -> list[ToolCallRequest]:
    out: list[ToolCallRequest] = []
    if not raw_tool_calls:
        return out
    for idx, tc in enumerate(raw_tool_calls, start=1):
        if isinstance(tc, dict):
            tc_id = str(tc.get("id") or f"call_{idx}")
            fn = tc.get("function") or {}
            name = str(fn.get("name") or tc.get("name") or "")
            raw_args = fn.get("arguments") if isinstance(fn, dict) else tc.get("arguments")
        else:
            tc_id = str(getattr(tc, "id", "") or f"call_{idx}")
            fn = getattr(tc, "function", None)
            name = str(getattr(fn, "name", "") or "")
            raw_args = getattr(fn, "arguments", "{}")
        if isinstance(raw_args, dict):
            args = raw_args
        elif isinstance(raw_args, str) and raw_args.strip():
            try:
                parsed = json.loads(raw_args)
                args = parsed if isinstance(parsed, dict) else {}
            except json.JSONDecodeError:
                args = {}
        else:
            args = {}
        if name:
            out.append(ToolCallRequest(id=tc_id, name=name, arguments=args))
    return out


class OpenAISDKAdapter:
    """Wrap an official openai.AsyncOpenAI or openai.OpenAI client (e.g. intranet 6luna)."""

    def __init__(self, client: Any, model: str = "6luna", extra_body: dict[str, Any] | None = None) -> None:
        self.client = client
        self.model = model
        self.extra_body = dict(extra_body or {})

    async def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.1,
        json_mode: bool = False,
        timeout: float = 20.0,
        parallel_tool_calls: bool = True,
    ) -> LLMResponse:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "timeout": timeout,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
            if parallel_tool_calls:
                kwargs["parallel_tool_calls"] = True
        elif json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        if self.extra_body:
            kwargs["extra_body"] = dict(self.extra_body)

        create_fn = self.client.chat.completions.create
        if inspect.iscoroutinefunction(create_fn):
            resp = await asyncio.wait_for(create_fn(**kwargs), timeout=timeout + 2.0)
        else:
            resp = await asyncio.wait_for(asyncio.to_thread(create_fn, **kwargs), timeout=timeout + 2.0)

        msg = resp.choices[0].message
        content = getattr(msg, "content", None) or ""
        reasoning = getattr(msg, "reasoning_content", None) or ""
        tool_calls = _parse_tool_calls(getattr(msg, "tool_calls", None))
        return LLMResponse(content=content, tool_calls=tool_calls, reasoning_content=reasoning, raw=resp)

    async def stream_text(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
        timeout: float = 60.0,
    ) -> AsyncIterator[str]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
            "timeout": timeout,
        }
        if self.extra_body:
            kwargs["extra_body"] = dict(self.extra_body)

        create_fn = self.client.chat.completions.create
        if inspect.iscoroutinefunction(create_fn):
            stream = await asyncio.wait_for(create_fn(**kwargs), timeout=timeout)
            try:
                async for chunk in stream:
                    if not chunk.choices:
                        continue
                    delta = chunk.choices[0].delta
                    text = getattr(delta, "content", None)
                    if text:
                        yield text
            finally:
                aclose = getattr(stream, "aclose", None)
                if callable(aclose):
                    await aclose()
        else:
            resp = await self.complete(messages, temperature=temperature, timeout=timeout)
            if resp.content:
                yield resp.content


class OpenAIHTTPAdapter:
    """Zero-openai-SDK adapter calling any OpenAI-compatible /chat/completions endpoint."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str = "6luna",
        extra_headers: dict[str, str] | None = None,
        extra_body: dict[str, Any] | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.extra_headers = dict(extra_headers or {})
        self.extra_body = dict(extra_body or {})

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json", **self.extra_headers}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _build_body(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.1,
        json_mode: bool = False,
        parallel_tool_calls: bool = True,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            **self.extra_body,
        }
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
            if parallel_tool_calls:
                body["parallel_tool_calls"] = True
        elif json_mode:
            body["response_format"] = {"type": "json_object"}
        return body

    async def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.1,
        json_mode: bool = False,
        timeout: float = 20.0,
        parallel_tool_calls: bool = True,
    ) -> LLMResponse:
        url = f"{self.base_url}/chat/completions"
        body = self._build_body(
            messages,
            tools=tools,
            temperature=temperature,
            json_mode=json_mode,
            parallel_tool_calls=parallel_tool_calls,
        )
        headers = self._headers()

        try:
            import httpx

            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(url, headers=headers, json=body)
                resp.raise_for_status()
                payload = resp.json()
        except ImportError:
            def _post_urllib() -> dict[str, Any]:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(body).encode("utf-8"),
                    headers=headers,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    return json.loads(r.read().decode("utf-8"))

            payload = await asyncio.wait_for(asyncio.to_thread(_post_urllib), timeout=timeout + 2.0)

        msg = payload["choices"][0]["message"]
        return LLMResponse(
            content=msg.get("content") or "",
            tool_calls=_parse_tool_calls(msg.get("tool_calls")),
            reasoning_content=msg.get("reasoning_content") or "",
            raw=payload,
        )

    async def stream_text(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
        timeout: float = 60.0,
    ) -> AsyncIterator[str]:
        resp = await self.complete(messages, temperature=temperature, timeout=timeout)
        if resp.content:
            yield resp.content


def adapt_llm(llm: Any, model: str = "6luna") -> AsyncLLMAdapter:
    """Auto-adapt an AsyncOpenAI/OpenAI client or custom AsyncLLMAdapter."""
    if isinstance(llm, AsyncLLMAdapter):
        return llm
    if hasattr(llm, "chat") and hasattr(llm.chat, "completions"):
        return OpenAISDKAdapter(llm, model=model)
    raise TypeError(
        "Unsupported llm object. Pass an AsyncOpenAI/OpenAI client, OpenAIHTTPAdapter, "
        "or an object implementing AsyncLLMAdapter(complete, stream_text)."
    )
