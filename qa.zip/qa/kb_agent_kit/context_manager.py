"""Module 1: Conversation context window & topic-boundary manager (mainstream Agent style).

Within one chat box, conversation history stays naturally active.
The manager's job for stateless 4-way retrievers is distinguishing:
  - continue:   same topic follow-up -> resolve references & preserve active focus
  - new_topic:  switched topic inside the same chat box -> isolate retrieval focus
  - cross_turn: compare / synthesize multiple prior turns -> fan out sub-queries
"""
from __future__ import annotations

import json
import re
from typing import Any

from .llm_client import AsyncLLMAdapter
from .types import ChatTurn, ContextAnalysis

CODE_FENCE_RE = re.compile(r"(?m)^\s*(`{3,}|~{3,})([\w+-]*)[^\n]*\n(.*?)(?:^\s*\1\s*$|\Z)", re.S | re.M)
FILE_TOKEN_RE = re.compile(
    r"(?<![A-Za-z0-9_./\\-])(?:[A-Za-z0-9_.-]+[/\\])*[A-Za-z0-9_.-]+\.(?:cbl|cob|cpy|jcl|aps|c|h|cpp|hpp|py|java|kt|ts|js|go|sql|md|docx|pdf|yaml|yml|json)(?![A-Za-z0-9_])",
    re.I,
)
SYMBOL_RE = re.compile(r"(?<![A-Za-z0-9_-])[A-Z][A-Z0-9_-]{3,}(?![A-Za-z0-9_-])")
FOLLOWUP_CUES_RE = re.compile(
    r"(?:它|该(?=程序|文件|模块|字段|接口|对象|规则|笔|行)|"
    r"(?:这个|那个)(?=程序|文件|模块|接口|对象|的|怎么|如何|是|呢)|这些|那些|上述|上面|前面|刚才|上一个|"
    r"^(?:那(?:么)?[，,\s]*(?=如果|要是|到期|失败|成功|遇到|还|又|接着)|"
    r"继续(?:讲|说)?[？?！!。\s]*$|还有哪些|详细说说|展开讲|为什么|怎么处理|怎么配)|"
    r"\b(?:it|its|this|that|they|them|above|previous|more detail)\b)",
    re.I,
)
REFERENCED_SUBJECT_RE = re.compile(r"(?:它的|该(?:程序|文件|模块|接口)的|这个(?:程序|文件|模块|接口)的)")
COMPARE_CUES_RE = re.compile(
    r"(?:对比|比较|区别|差异|不同点|各自|分别|两个|两者|上述.{0,4}(?:程序|文件|方案)|compare|difference|versus|\bvs\b)",
    re.I,
)
CODE_LINE_RE = re.compile(
    r"^\s*(?:\d{6})?\s*(?:(?:IDENTIFICATION|PROCEDURE|DATA|ENVIRONMENT)\s+DIVISION\b|PROGRAM-ID\.|"
    r"(?:MOVE\s+.+\s+TO|CALL\s+[\w\"']|PERFORM\s+[\w-]+|COMPUTE\s+|IF\s+[\w-]+\s*(?:[<>=]|IS\b)|"
    r"\d{2}\s+[\w-]+\s+PIC\b)|(?:def|class|function)\s+\w+|(?:SELECT\s+.+\s+FROM|UPDATE\s+\w+\s+SET)\b)",
    re.I,
)

TOPIC_ANALYSIS_SYSTEM_PROMPT = """你是主流企业知识库 Agent 的「上下文与话题边界分析器」。
同一聊天框内对话默认有上下文，但底层四路检索引擎（向量/BM25/精确代码/图谱）看不到历史。
请结合历史对话与最新用户提问，完成两件事：
1. 判断最新提问与前文的话题关系 topic_relation：
   - "continue"：延续上一轮话题（如追问细节、省略主语、使用指代词“它/该/这个/上面”）。
   - "new_topic"：在同一聊天框内切换到了全新的对象、程序、文件或业务主题。
   - "cross_turn"：要求对比、串联或汇总前文提到的多个主题/对象。
2. 构造供四路检索引擎使用的独立查询：
   - 若为 "continue"：补全省略的主语、文件名或程序名，生成自包含的 standalone_query，并在 carry_entities / carry_files 中列出需沿用的对象。
   - 若为 "new_topic"：严禁把上一轮旧主题的实体或文件名混入 standalone_query，carry_entities / carry_files 留空。
   - 若为 "cross_turn"：生成概括的 standalone_query，并在 sub_queries 中拆分为 2~3 条可独立检索的子查询。

严格输出 JSON（不要输出其他文本）：
{
  "topic_relation": "continue | new_topic | cross_turn",
  "standalone_query": "自包含检索问句",
  "sub_queries": ["子查询1"],
  "carry_entities": ["实体1"],
  "carry_files": ["文件名1"],
  "reason": "一句话判断依据"
}"""


def normalize_history(history: list[Any] | None) -> list[ChatTurn]:
    """Normalize ChatTurn, OpenAI dict, rag_hs History object, or (role, content) tuple."""
    turns: list[ChatTurn] = []
    for item in history or []:
        if isinstance(item, ChatTurn):
            turns.append(item)
            continue
        if isinstance(item, dict):
            if "question" in item and "content" not in item:
                turns.append(ChatTurn(
                    role="user", content=str(item.get("question") or ""),
                    entities=list(item.get("entities") or []), files=list(item.get("files") or []),
                ))
                answer = item.get("answer")
                if isinstance(answer, dict):
                    answer = answer.get("what") or answer.get("summary") or answer.get("answer")
                if answer:
                    turns.append(ChatTurn(role="assistant", content=str(answer)))
                continue
            role = str(item.get("role", "user")).lower()
            if role in {"human", "user"}:
                role = "user"
            elif role in {"ai", "assistant"}:
                role = "assistant"
            else:
                role = "system"
            content = item.get("content", "")
            if isinstance(content, dict):
                content = content.get("answer") or content.get("summary") or content.get("what") or json.dumps(content, ensure_ascii=False)
            turns.append(
                ChatTurn(
                    role=role,  # type: ignore[arg-type]
                    content=str(content or ""),
                    entities=list(item.get("entities") or []),
                    files=list(item.get("files") or []),
                )
            )
            continue
        if isinstance(item, (tuple, list)) and len(item) >= 2:
            role = "assistant" if str(item[0]).lower() in {"ai", "assistant"} else "user"
            turns.append(ChatTurn(role=role, content=str(item[1] or "")))
            continue
        if hasattr(item, "role") and hasattr(item, "content"):
            role = "assistant" if str(getattr(item, "role")).lower() in {"ai", "assistant"} else "user"
            content = getattr(item, "content")
            if isinstance(content, dict):
                content = content.get("answer") or content.get("summary") or str(content)
            turns.append(ChatTurn(role=role, content=str(content or "")))
    return [t for t in turns if t.content.strip()]


def extract_code_blocks(text: str) -> str:
    """Extract fenced code blocks or raw COBOL/SQL/Python code lines."""
    matches = [m.group(3).strip("\r\n") for m in CODE_FENCE_RE.finditer(text or "") if m.group(3).strip()]
    if matches:
        return "\n\n".join(matches)
    lines = (text or "").splitlines()
    code_indices = [i for i, line in enumerate(lines) if CODE_LINE_RE.search(line)]
    if not code_indices:
        return ""
    first = code_indices[0]
    code_lines = [
        line for i, line in enumerate(lines)
        if i >= first and (CODE_LINE_RE.search(line) or not re.search(r"[\u4e00-\u9fff]", line))
    ]
    return "\n".join(code_lines).strip()


def extract_files(text: str) -> list[str]:
    return list(dict.fromkeys(FILE_TOKEN_RE.findall(text or "")))


def _file_stem(path: str) -> str:
    return path.replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0]


def extract_symbols(text: str) -> list[str]:
    stop = {
        "JSON", "HTTP", "HTTPS", "UTF-8", "SELECT", "FROM", "WHERE", "UPDATE", "INSERT",
        "DELETE", "MOVE", "CALL", "PERFORM", "COMPUTE", "DIVISION", "SECTION", "PROGRAM-ID",
        "END-IF", "ELSE", "USING", "INTO", "VALUE", "COPY", "READ", "WRITE", "EXIT", "CONTINUE",
    }
    text = FILE_TOKEN_RE.sub(lambda match: _file_stem(match.group()), text or "")
    found = [s for s in SYMBOL_RE.findall(text) if s not in stop]
    return list(dict.fromkeys(found))[:10]


def _subjects(files: list[str], entities: list[str]) -> list[str]:
    file_stems = {_file_stem(name).casefold() for name in files}
    return files + [entity for entity in entities if entity.casefold() not in file_stems]


def _same_subject(left: str, right: str) -> bool:
    left, right = (name.replace("\\", "/").casefold() for name in (left, right))
    if left == right:
        return True
    return ("." not in left and left == _file_stem(right)) or ("." not in right and right == _file_stem(left))


def _topic_turn(turns: list[ChatTurn]) -> ChatTurn:
    for turn in reversed(turns):
        if extract_files(turn.content) or extract_symbols(turn.content):
            return turn
        if not FOLLOWUP_CUES_RE.search(turn.content):
            return turn
    return turns[0]


def _new_topic(question: str, reason: str, *, used_llm: bool = False) -> ContextAnalysis:
    return ContextAnalysis(
        original_query=question,
        carry_entities=extract_symbols(question),
        carry_files=extract_files(question),
        reason=reason,
        used_llm=used_llm,
    )


def compact_history(
    turns: list[ChatTurn],
    *,
    max_turns: int = 6,
    max_chars: int = 4000,
    assistant_clip: int = 600,
) -> list[dict[str, str]]:
    """Build OpenAI-ready sliding-window messages within budget without mutating caller input."""
    recent = turns[-(max_turns * 2):]
    selected: list[dict[str, str]] = []
    used = 0
    for turn in reversed(recent):
        if turn.role == "system":
            continue
        text = turn.content.strip()
        if turn.role == "assistant" and len(text) > assistant_clip:
            text = text[:assistant_clip] + "...（已精简）"
        remaining = max_chars - used
        if remaining <= 0 or (len(text) > remaining and selected):
            break
        text = text[:remaining]
        selected.insert(0, {"role": turn.role, "content": text})
        used += len(text)
    return selected


def _extract_json_obj(raw: str) -> dict[str, Any] | None:
    if not raw:
        return None
    m = re.search(r"<json>\s*(.*?)\s*</json>", raw, re.S)
    candidate = m.group(1) if m else raw
    start, end = candidate.find("{"), candidate.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        parsed = json.loads(candidate[start:end + 1])
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        return None


class ContextManager:
    """Mainstream Agent conversation context & topic-boundary manager."""

    def __init__(
        self,
        *,
        max_history_turns: int = 6,
        max_history_chars: int = 4000,
        max_sub_queries: int = 3,
    ) -> None:
        self.max_history_turns = max_history_turns
        self.max_history_chars = max_history_chars
        self.max_sub_queries = max_sub_queries

    def build_history_messages(self, history: list[Any] | None) -> list[dict[str, str]]:
        turns = normalize_history(history)
        return compact_history(
            turns,
            max_turns=self.max_history_turns,
            max_chars=self.max_history_chars,
        )

    async def analyze(
        self,
        question: str,
        history: list[Any] | None = None,
        *,
        llm: AsyncLLMAdapter | None = None,
        use_llm: bool = True,
        timeout: float = 10.0,
    ) -> ContextAnalysis:
        """Determine topic continuity vs. topic shift and prepare standalone retrieval queries."""
        q = (question or "").strip()
        turns = [t for t in normalize_history(history) if t.role == "user"]
        turns = turns[-self.max_history_turns:] if self.max_history_turns > 0 else []
        analysis = self._analyze_heuristic(q, turns)
        if not turns or analysis.topic_relation == "new_topic":
            return analysis

        # Named objects can be resolved deterministically. Only use the model for
        # outcome-neutral rewriting of references to natural-language topics.
        if llm is not None and use_llm and not (analysis.carry_entities or analysis.carry_files):
            model_turns = turns if analysis.topic_relation == "cross_turn" else [_topic_turn(turns)]
            try:
                resolved = await self._analyze_with_llm(q, model_turns, llm, timeout=timeout)
                if resolved is not None and resolved.topic_relation in {"new_topic", analysis.topic_relation}:
                    return resolved
            except Exception:
                pass  # Fail-open to deterministic heuristic below.

        return analysis

    async def _analyze_with_llm(
        self,
        question: str,
        turns: list[ChatTurn],
        llm: AsyncLLMAdapter,
        *,
        timeout: float,
    ) -> ContextAnalysis | None:
        recent = compact_history(turns, max_turns=4, max_chars=2400, assistant_clip=320)
        hist_text = "\n".join(
            f"{'用户' if m['role'] == 'user' else '助手'}: {m['content']}" for m in recent
        )
        user_content = f"【聊天框历史】\n{hist_text}\n\n【最新提问】\n{question}"
        resp = await llm.complete(
            [
                {"role": "system", "content": TOPIC_ANALYSIS_SYSTEM_PROMPT},
                {"role": "user", "content": user_content},
            ],
            temperature=0.0,
            json_mode=True,
            timeout=timeout,
        )
        parsed = _extract_json_obj(resp.content)
        if not parsed:
            return None

        relation = str(parsed.get("topic_relation") or "new_topic").strip().lower()
        if relation not in {"continue", "new_topic", "cross_turn"}:
            return None
        if relation == "new_topic":
            return _new_topic(question, "模型判断为独立话题，使用当轮问题检索", used_llm=True)

        standalone = str(parsed.get("standalone_query") or "").strip() or question
        raw_subs = parsed.get("sub_queries")
        sub_queries = [
            str(s).strip() for s in (raw_subs if isinstance(raw_subs, list) else []) if str(s).strip()
        ][: self.max_sub_queries]
        if not sub_queries:
            sub_queries = [standalone]

        return ContextAnalysis(
            original_query=question,
            topic_relation=relation,  # type: ignore[arg-type]
            standalone_query=standalone,
            sub_queries=sub_queries,
            carry_entities=extract_symbols(standalone),
            carry_files=extract_files(standalone),
            reason=str(parsed.get("reason") or "LLM 话题边界判定"),
            used_llm=True,
        )

    def _analyze_heuristic(self, question: str, turns: list[ChatTurn]) -> ContextAnalysis:
        """Zero-LLM fallback distinguishing continue / new_topic / cross_turn."""
        cur_files = extract_files(question)
        cur_symbols = extract_symbols(question)
        cur_code = extract_code_blocks(question)

        subjects = _subjects(cur_files, cur_symbols)
        is_compare = bool(COMPARE_CUES_RE.search(question))
        has_followup_cue = bool(FOLLOWUP_CUES_RE.search(question))
        if is_compare and len(subjects) < 2 and has_followup_cue:
            for turn in reversed(turns):
                for subject in _subjects(extract_files(turn.content), extract_symbols(turn.content)):
                    if not any(_same_subject(subject, known) for known in subjects):
                        subjects.append(subject)
                if len(subjects) >= 2:
                    break

        if is_compare and (len(subjects) >= 2 or (turns and not subjects and has_followup_cue)):
            subjects = subjects[:self.max_sub_queries]
            focus = question
            for subject in _subjects(cur_files, cur_symbols):
                focus = re.sub(rf"(?<![A-Za-z0-9_.-]){re.escape(subject)}(?![A-Za-z0-9_.-])", "", focus, flags=re.I)
            named = "、".join(subjects)
            return ContextAnalysis(
                original_query=question,
                topic_relation="cross_turn",
                standalone_query=f"{named}：{question}" if named else question,
                sub_queries=[f"{subject} {focus}" for subject in subjects],
                carry_entities=extract_symbols(named),
                carry_files=extract_files(named),
                reason="按对比对象分别构造检索子查询" if named else "检测到跨轮对比，需要补全对象",
            )

        if cur_files or cur_code or (cur_symbols and not REFERENCED_SUBJECT_RE.search(question)):
            return _new_topic(question, "本轮已显式指定检索对象")
        if not turns or not has_followup_cue:
            return _new_topic(question, "使用当轮独立问题检索")

        prev = _topic_turn(turns)
        files = extract_files(prev.content)
        entities = extract_symbols(prev.content)
        anchors = " ".join(_subjects(files, entities)[:4]) or prev.content[:120]
        return ContextAnalysis(
            original_query=question,
            topic_relation="continue",
            standalone_query=f"{anchors} {question}",
            carry_entities=list(dict.fromkeys(entities + cur_symbols))[:8],
            carry_files=files[:6],
            inherited_code=extract_code_blocks(prev.content),
            reason="沿用最近一个已明确的话题对象",
        )
