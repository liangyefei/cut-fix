"""Core data contracts for the pluggable KB Agent toolkit."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

TopicRelation = Literal["continue", "new_topic", "cross_turn"]
RunMode = Literal["auto", "single", "agent"]
ToolProtocol = Literal["tool_calls", "json"]


@dataclass
class ChatTurn:
    """Single message in a conversation thread."""
    role: Literal["user", "assistant", "system"]
    content: str
    entities: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvidenceItem:
    """Normalized evidence unit shared across all 4 retrieval channels."""
    channel: str  # vector | bm25 | code_exact | graph | source | other
    content: str
    source: str = ""
    title: str = ""
    loc: str = ""
    score: float = 0.0
    source_no: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    raw_obj: Any = None  # Preserves original LangChain Document / dict for zero-loss handoff

    def compact_dict(self, max_chars: int = 420) -> dict[str, Any]:
        snippet = (self.content or "").strip()
        if len(snippet) > max_chars:
            snippet = snippet[:max_chars] + "..."
        return {
            "source_no": self.source_no,
            "channel": self.channel,
            "title": self.title,
            "source": self.source,
            "loc": self.loc,
            "score": round(float(self.score or 0.0), 4),
            "snippet": snippet,
        }


@dataclass
class ContextAnalysis:
    """Result of conversation topic boundary & retrieval contextualization."""
    original_query: str
    topic_relation: TopicRelation = "new_topic"
    standalone_query: str = ""
    sub_queries: list[str] = field(default_factory=list)
    carry_entities: list[str] = field(default_factory=list)
    carry_files: list[str] = field(default_factory=list)
    inherited_code: str = ""
    reason: str = ""
    used_llm: bool = False

    def __post_init__(self) -> None:
        if not self.standalone_query:
            self.standalone_query = self.original_query
        if not self.sub_queries:
            self.sub_queries = [self.standalone_query]


@dataclass
class RouteDecision:
    """Decision on whether to escalate from Round-0 retrieval into Agent loop."""
    enter_agent: bool
    mode: RunMode
    reason: str
    suggested_tools: list[str] = field(default_factory=list)
    round0_count: int = 0
    round0_top_score: float = 0.0


@dataclass
class ToolCallRequest:
    """Unified representation of an LLM tool invocation."""
    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """Unified response returned by any adapted LLM client."""
    content: str = ""
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    reasoning_content: str = ""
    raw: Any = None


@dataclass
class TraceStep:
    """Observability record for every stage / round."""
    round_no: int
    stage: str  # context | round0 | route | tool_call | early_stop | answer | error
    detail: str
    tool_name: str = ""
    arguments: dict[str, Any] = field(default_factory=dict)
    added_count: int = 0
    elapsed_ms: int = 0


@dataclass
class AgentEvent:
    """Streaming event emitted during retrieval and/or answer generation."""
    type: Literal["status", "context", "tool_call", "tool_result", "answer_delta", "sources", "done", "error"]
    content: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "content": self.content, "data": self.data}

    def to_rag_hs_event(self, message_id: str = "") -> dict[str, Any] | None:
        """Map to rag_hs-master SSE event format for zero-change frontend compatibility."""
        if self.type in {"status", "tool_call"} and self.content:
            return {
                "type": "route_reasoning",
                "stream": False,
                "content": self.content,
                "message_id": message_id,
            }
        if self.type == "answer_delta" and self.content:
            return {
                "type": "answer",
                "answer": self.content,
                "message_id": message_id,
            }
        if self.type == "error":
            return {
                "error": self.content,
                "message_id": message_id,
            }
        return None


@dataclass
class AgentConfig:
    """Runtime knobs and kill-switches for the pluggable Agent kit."""
    enabled: bool = True
    default_mode: RunMode = "auto"
    model: str = "6luna"
    tool_protocol: ToolProtocol = "tool_calls"
    max_rounds: int = 4
    max_empty_rounds: int = 1
    max_sub_queries: int = 3
    total_timeout_sec: float = 35.0
    per_tool_timeout_sec: float = 8.0
    llm_timeout_sec: float = 20.0
    context_llm_timeout_sec: float = 10.0
    use_llm_context_analysis: bool = True
    min_sufficient_score: float = 0.45
    max_history_turns: int = 6
    max_history_chars: int = 4000
    max_tool_summary_chars: int = 420
    max_evidence_in_planner: int = 16
    round0_top_k: int = 6
    planner_temperature: float = 0.0
    answer_temperature: float = 0.2
    parallel_tool_calls: bool = True
    language: str = "zh"


@dataclass
class AgentResult:
    """Final structured result from retrieve() or chat()."""
    query: str
    answer: str = ""
    evidence: list[EvidenceItem] = field(default_factory=list)
    context_analysis: ContextAnalysis | None = None
    route_decision: RouteDecision | None = None
    trace: list[TraceStep] = field(default_factory=list)
    rounds_executed: int = 0
    elapsed_ms: int = 0
    mode_used: RunMode = "auto"
    degraded: bool = False

    @property
    def raw_documents(self) -> list[Any]:
        """Original objects (e.g. LangChain Documents) returned by intranet retrievers."""
        return [item.raw_obj for item in self.evidence if item.raw_obj is not None]

    def summary_report(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "mode_used": self.mode_used,
            "topic_relation": self.context_analysis.topic_relation if self.context_analysis else "new_topic",
            "standalone_query": self.context_analysis.standalone_query if self.context_analysis else self.query,
            "sub_queries": self.context_analysis.sub_queries if self.context_analysis else [self.query],
            "entered_agent_loop": self.route_decision.enter_agent if self.route_decision else False,
            "route_reason": self.route_decision.reason if self.route_decision else "",
            "rounds_executed": self.rounds_executed,
            "evidence_count": len(self.evidence),
            "channels": sorted({e.channel for e in self.evidence}),
            "elapsed_ms": self.elapsed_ms,
            "degraded": self.degraded,
            "trace": [
                {
                    "round": s.round_no,
                    "stage": s.stage,
                    "tool": s.tool_name,
                    "detail": s.detail,
                    "added": s.added_count,
                    "ms": s.elapsed_ms,
                }
                for s in self.trace
            ],
        }
