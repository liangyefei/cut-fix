# 内网知识库问答检索插件

把 `kb_agent_kit/` 拷到内网 Python 服务，就能给现有知识库问答补上同一聊天框里的多轮对话和复杂问题的自动补查。

## 功能

1. **同一聊天框里接着聊。** 先问程序 A，再问「它的错误码呢」，就接着查 A。接下来明确问 B，就按 B 查。说「对比刚才那两个」，就分别查 A 和 B。默认参考当前会话最近 6 次用户提问。
2. **复杂问题可以多查几轮。** 首轮走向量、BM25、精确代码和图谱。遇到「改 B 会影响哪些下游」这类问题，可以根据缺少的信息继续查，默认最多补查 4 轮。第一句就问复杂问题也能用。

插件接在现有问答的检索阶段，把查到的原始资料交回内网问答流程。重排、生成答案和引用校验继续由现有流程完成。

## 如何测试

### 1. 验证交付目录可独立导入

在本目录使用 Python 3.10 或更高版本执行。导入检查仅使用标准库。

```powershell
python -B -c "from kb_agent_kit import AgentRunner; from kb_agent_kit.intranet_adapter import create_intranet_agent_runner, intranet_rag_hs_plugin_retrieve; print('qa import ok')"
```

### 2. 用内网现有业务题集验证检索

接上内网检索回调后，调用 `await runner.retrieve(question, history=history, mode="single")`。用 `result.context_analysis` 查看实际查的是什么，用 `result.raw_documents` 查看查到了哪些资料。可以先把 `openai_6luna_client` 设为 `None`，验证规则和首轮检索。

- 在同一个聊天框检查追问有没有接对、换题后有没有混进旧资料、对比时两边有没有各自的资料。
- 接上模型后，用 `mode="agent"` 检查网关能否执行工具调用。再用 `mode="auto"` 检查简单问题可以直接返回，复杂问题需要时能继续查。

### 3. 验证最终答案和回滚

把 `result.raw_documents` 交回现有问答流程，用业务题集核对答案是否正确、引用是否对得上、缺资料时有没有说明。关闭入口功能开关，确认请求能直接进入原问答链路。接了 SSE 时，检查进度、答案和结束事件。

## 如何对接内网代码

### 1. 注入检索回调和模型客户端

把 `kb_agent_kit/` 放到内网 Python 服务的导入路径。回调可以是同步函数或异步函数，返回已按本次请求权限过滤的证据列表。表中的参数名对应插件传入的关键字参数。

| 回调 | 参数 | 对接内容 |
|---|---|---|
| `intranet_vector_search` | `query`, `top_k` | 现有语义向量检索 |
| `intranet_bm25_search` | `query`, `keywords`, `top_k` | 现有关键词检索，`keywords` 为可选补充关键词 |
| `intranet_code_exact_search` | `query`, `file_hint`, `top_k` | 现有精确代码检索，`file_hint` 为文件或程序提示 |
| `intranet_graph_search` | `entity`, `mode`, `depth` | 现有图谱查询，`mode` 可为 `neighbors`、`impact`、`three_layer` |
| `intranet_read_source` | `file_path`, `start_line`, `end_line` | 可选原文读取，按授权范围和行号返回片段 |

证据可以使用原有 LangChain `Document`，或使用含 `content`（也支持 `text`）、`source`、`loc`、`score` 的字典。尽量保留稳定的来源标识、定位和重排需要的元数据。模型可注入内网已有的 OpenAI 兼容 SDK 客户端、`OpenAIHTTPAdapter` 或自定义 `AsyncLLMAdapter`。使用标准四路插件时，将回调产物统一成现有重排器可处理的对象格式。

### 2. 挂到问答入口

入口先根据功能开关选择执行原链路或插件，再按当前用户、会话和知识库范围绑定回调。下面的 `retrievers`、`model_client` 和 `existing_generate` 代表内网已有实现。

```python
from kb_agent_kit.intranet_adapter import create_intranet_agent_runner


async def retrieve_and_answer(question, history, retrievers, model_client, existing_generate):
    runner = create_intranet_agent_runner(
        openai_6luna_client=model_client,
        intranet_vector_search=retrievers.vector,
        intranet_bm25_search=retrievers.bm25,
        intranet_code_exact_search=retrievers.code_exact,
        intranet_graph_search=retrievers.graph,
    )
    result = await runner.retrieve(question, history=history)
    return await existing_generate(question=question, documents=result.raw_documents)
```

`history` 传同一会话中早于本轮的消息，支持 `{"role": "user", "content": "..."}` 消息或 `{"question": "...", "answer": ...}` 记录。入口检查会话归属后，再将历史传给插件。

如果入口使用 SSE，可直接消费 `runner.retrieve_stream()`。读取 `done` 事件中的 `event.data["result"]` 交接证据。`intranet_rag_hs_plugin_retrieve()` 可将支持的进度事件转成 `route_reasoning` JSON，入口负责 SSE 封帧，并按现有协议发送答案及结束事件。

### 3. 配置和调优

| 配置 | 行为 |
|---|---|
| `mode="single"` | 保留话题分析和首轮召回，关闭多轮补查。 |
| `mode="auto"` | 根据问题和首轮证据决定是否补查。 |
| `mode="agent"` | 有规划模型和工具时直接进入补查规划。 |
| `KB_AGENT_MODE` | 调用时省略 `mode`，即可用该环境变量切换默认策略。 |
| `HAISI_AGENT_LOOP_ENABLED=false` | 插件跳过话题改写和多轮补查，按当轮原问题召回。入口开关负责完整切回内网原链路。 |
| `model_name="6luna"` | 默认模型名。内网网关使用不同模型别名时，传实际别名。 |
| `tool_protocol="tool_calls"` | 默认使用模型原生工具调用。网关不支持原生工具调用时，可切换为 `"json"`，并验证网关接受 JSON 输出格式参数。 |

维护人员可调用 `await runner.compare_modes(question, history=history)`。单轮和多轮共用同一次首轮检索，可以直接看多查到了哪些资料，以及这些资料是否补齐了问题。根据业务题集的结果，用 `AgentConfig` 调整补查轮数 `max_rounds`、连续无新增时的停止条件 `max_empty_rounds` 和相关分阈值 `min_sufficient_score`。

## 接入注意事项

- **权限在检索回调里生效。** 回调返回的证据可能进入规划模型，按请求用户和知识库范围过滤后再返回。原文读取回调应校验资料标识、可读权限和读取范围。
- **首轮证据和查询保持一致。** 如果内网已完成首轮召回，可用 `initial_evidence` 传入当轮原问题、同一权限范围内的证据。插件改写问题、拆分子查询或继承代码时会重新召回。内网有自己的重排环节时，从未重排的证据阶段接入，最终沿用内网的引用编号和校验。
- **服务入口保留统一超时和回退。** `total_timeout_sec` 是补查轮次启动前检查的预算，服务端沿用现有请求截止时间。插件开关和真实请求的错误处理放在问答入口。
- **确认网关和模型的数据范围。** 当轮问题、解析指代所需的上下文和证据片段可能发给模型。接入时使用内网认可的模型端点，进度与日志按现有规则处理工具参数。
- **看业务题集里的实际答案。** 很短或指代不清的问题依赖会话信息和模型判断。补查新增条数可以帮助排查召回，最终效果看答案和引用。
