"""Resolve source-backed graph links from records supplied by the host."""

from collections import defaultdict
from pathlib import PurePosixPath
import re


def enrich(nodes, edges, *, current_snapshots, references, sources, documents=()):
    """Return a graph with static CALL, COPY, and explicit document mentions."""
    current = set(current_snapshots)
    source_map = {(row['snapshot_id'], row['path']): row for row in sources}
    known_copies = {
        (snapshot, PurePosixPath(path).stem.upper())
        for snapshot, path in source_map if PurePosixPath(path).suffix.lower() == '.cpy'
    }
    nodes = [
        {**node, 'props': {**node['props'], 'doc_id': source['doc_id']}}
        if (source := source_map.get((node['props'].get('snapshot_id'), node['props'].get('path'))))
        and source.get('doc_id') else node
        for node in nodes
    ]
    by_id = {node['id']: node for node in nodes}
    files, programs, copies = defaultdict(list), defaultdict(list), defaultdict(list)
    for node in nodes:
        props = node['props']
        snapshot, path = props.get('snapshot_id'), props.get('path', '')
        if snapshot not in current:
            continue
        files[snapshot, path].append(node)
        suffix = PurePosixPath(path).suffix.lower()
        if props.get('kind') == 'module' and suffix in {'.cbl', '.cob', '.cobol'}:
            programs[(node.get('name') or props.get('name', '')).upper()].append(node)
        if node['label'] == 'CodeFile' and suffix == '.cpy':
            copies[PurePosixPath(path).stem.upper()].append(node)

    derived = []
    seen = {(edge['src'], edge['rel'], edge['dst'], edge.get('props', {}).get('line')) for edge in edges}
    source_lines = {}
    for ref in references:
        snapshot, path = ref['snapshot_id'], ref['path']
        kind = ref['kind'].lower()
        if snapshot not in current or kind not in {'calls', 'imports'}:
            continue
        key = (snapshot, path)
        source_record = source_map.get(key)
        source = next((node for node in files[key] if node['props'].get('kind') == 'module'), None)
        source = source or next((node for node in files[key] if node['label'] == 'CodeFile'), None)
        if not source or not source_record:
            continue

        symbol = PurePosixPath(ref['name'].strip('"\'')).stem.upper()
        candidates = (programs if kind == 'calls' else copies).get(symbol, [])
        local = [node for node in candidates if node['props'].get('snapshot_id') == snapshot]
        if kind == 'calls' and local:
            continue
        if kind == 'imports' and not local and (snapshot, symbol) in known_copies:
            continue
        candidates = local or candidates
        library = source['props'].get('library')
        preferred = [node for node in candidates if node['props'].get('library') == library]
        candidates = preferred or candidates
        if len(candidates) != 1:
            continue

        if key not in source_lines:
            source_lines[key] = source_record['text'].splitlines()
        line = max(1, ref.get('line') or 1)
        snippet = '\n'.join(text for text in source_lines[key][max(0, line - 2):line + 2]
                            if len(text) < 7 or text[6] not in '*/' or text[:6].strip(' 0123456789'))
        literal = (r"\bCALL\s+(['\"])" + re.escape(symbol) + r'\1' if kind == 'calls'
                   else r"\bCOPY\s+['\"]?" + re.escape(symbol) + r'(?![\w-])')
        if not re.search(literal, snippet, re.I):
            continue
        target = candidates[0]
        rel = 'CALLS' if kind == 'calls' else 'IMPORTS'
        identity = source['id'], rel, target['id'], line
        if identity in seen:
            continue
        seen.add(identity)
        target_props = target['props']
        derived.append(dict(src=source['id'], rel=rel, dst=target['id'], props=dict(
            line=line, symbol=symbol, evidence=snippet.strip()[:600], method='literal_unique_symbol',
            cross_project=snapshot != target_props.get('snapshot_id'),
            cross_system=library != target_props.get('library'),
            source_snapshot=snapshot, target_snapshot=target_props.get('snapshot_id'),
        )))

    symbols = programs.keys() | copies.keys()
    for row in documents:
        source = by_id.get(row['node_id'])
        if not source or source['label'] != 'Document':
            continue
        text, props = row['text'], source['props']
        words = {word.upper() for word in re.findall(r'[A-Za-z0-9][A-Za-z0-9_-]*', text)}
        for symbol in sorted(words & symbols):
            candidates = programs.get(symbol, []) + copies.get(symbol, [])
            for field in ('library', 'project'):
                preferred = [node for node in candidates if node['props'].get(field) == props.get(field)]
                candidates = preferred or candidates
            if len(candidates) != 1:
                continue
            match = re.search(r'(?<![\w-])' + re.escape(symbol) + r'(?![\w-])', text, re.I)
            if not match:
                continue
            line = text.count('\n', 0, match.start()) + 1
            target = candidates[0]
            identity = source['id'], 'MENTIONS', target['id'], line
            if identity in seen:
                continue
            seen.add(identity)
            target_props = target['props']
            derived.append(dict(src=source['id'], rel='MENTIONS', dst=target['id'], props=dict(
                line=line, symbol=symbol, evidence=text.splitlines()[line - 1][:600],
                method='explicit_unique_mention',
                cross_project=props.get('project') != target_props.get('project'),
                cross_system=props.get('library') != target_props.get('library'),
            )))
    return nodes, [*edges, *derived]
