# 图谱逻辑移植说明

这份代码供前后端架构不同的知识库复用。内网先用现有接口、数据和渲染库确定问题在哪一层，再接入对应逻辑。目录里的 Python 代码仅使用标准库，前端代码是标准 JavaScript 模块。内网也可以用现有语言按下面的字段和规则实现。

## 交付范围

完整链路是「解析源码生成基础图 → 读取和筛选图数据 → 补引用、生成视图 → 布局和绘制 → 交互与源码跳转」。`image` 中的五个源码文件覆盖中间可复用的算法。部署到内网时需要把它们接到现有的数据来源和页面。

| 环节 | 可复用的代码 | 接入时由内网提供 |
| --- | --- | --- |
| 源码 → 基础节点和边 | 同级 `cut` 包含 ZIP、COBOL/Copybook、APS、JCL 的解析和基础图生成。`image/backend/graph.py` 可将其输出映射到下文的数据契约。 | 如果已有可用解析器，直接映射现有结果。 |
| 读取、鉴权、发布和版本管理 | 按下文的字段约定接数据。 | 从现有图存储或解析结果读取授权数据，选择有效版本，使用现有 API、索引和发布流程。 |
| 引用匹配、文件聚合、结构视图与分页 | `associations.py` 和 `graph.py`。 | 要补跨工程关系时，提供静态引用和对应版本的原文。 |
| 搜索、连线归并、标签与坐标计算 | `view-model.mjs`、`layout.mjs` 和可选的 `layout.worker.mjs`。 | 传入节点、边和筛选项。 |
| 画布绘制、事件和源码跳转 | 下文给出对接步骤。 | 使用现有图谱组件渲染坐标，绑定缩放、拖动、点击和跳转。 |

## 按问题选择接入范围

| 内网现象 | 从哪里检查 | 接入什么 |
| --- | --- | --- |
| 节点挤、边重叠、缩放时文字遮挡 | 比较接口里的节点和边与实际画面。如果数据已经正确，优先处理展示。 | 用 [布局](frontend/layout.mjs) 计算坐标，用 [展示模型](frontend/view-model.mjs) 归并同向连线、显示标签和引用依据。 |
| 文件图太杂，或看不到文件内的 APS/JCL 层级 | 检查是文件视图还是结构视图。文件视图会折叠同文件内部的边。结构数据须包含段落、作业、步骤等节点及 `CONTAINS`。 | 用 [图谱视图](backend/graph.py) 区分文件聚合和结构明细。 |
| 跨工程调用、Copybook 或文档引用缺失 | 检查是否有静态引用、可见的候选工程和原文依据。 | 用 [关系补全](backend/associations.py) 增加有证据且目标唯一的边。 |
| 解析结果本身缺少节点或边 | 对照解析产物和源码，查明文件类型及缺少的结构。 | 在解析阶段补齐基础图数据。若同时移植 COBOL、APS、JCL 的 ZIP 切分，可另外参考同级 `cut`。 |

## 前后端数据契约

字段名是本包的输入约定。内网可以在适配层转换字段、关系类型和源码链接，沿用现有接口、鉴权和存储。所有节点 ID 使用唯一、稳定的字符串，边的起终点使用同一批节点 ID。

| 数据 | 最小字段 | 需要时携带 |
| --- | --- | --- |
| 节点 | `id`、`label`、`props`（可为空对象）。可读名称用 `name`。 | `props.snapshot_id` 标识一次有效的工程快照。 `library`、`project`、`version`、`tags` 用于筛选。 |
| 边 | `src`、`dst`、`rel`。例如 `CONTAINS`、`CALLS`、`IMPORTS`、`MENTIONS`。 | `props.line`、`evidence` 和 `method` 表示依据。跨工程、跨系统可分别标记 `cross_project`、`cross_system`。 |
| 文件归属 | 文件节点标为 `CodeFile`，文档标为 `Document`。子节点优先用 `props.owner_id` 指向所属文件或文档。 | 代码节点也可按 `snapshot_id + path` 匹配文件。 `doc_id` 或宿主自己的源码定位键用于跳转，行号从 1 开始。 |
| 结构类型 | 将程序与过程映射为 `CodeUnit`，并分别给 `props.kind` 赋 `module` 或 `function`。字段、文档章节用 `Field`、`DocumentSection`。 | 宿主的其他标签和关系可以原样带入。页面可根据内网术语显示对应名称。 |
| 引用与原文 | 引用记录包括 `snapshot_id`、`path`、`kind`（`calls` / `imports`）、`name`、`line`。原文记录包括 `snapshot_id`、`path`、`text`。 | `sources` 可附 `doc_id`。参与匹配的已发布文档提供 `node_id` 和 `text`。 |

## 后端怎么接

1. 从内网已有的解析结果或图存储取得**当前用户可见**的节点、边和工程快照。跨工程匹配还需要可见范围内的引用记录、对应版本的源码和文档正文。权限筛选在派生关系前完成，候选节点、原文证据和邻居沿用同一可见范围。
2. 需要补边时调用 `enrich`。按当前有效快照匹配 COBOL 静态 `CALL` 和 `COPY`。先看同一工程快照的定义，再优先同一知识库。候选不唯一或原文附近没有字面引用时跳过。文档中明确提到唯一程序或 Copybook 时补 `MENTIONS`。该逻辑基于输入的引用记录，APS/JCL 结构和 JCL 外部依赖仍由内网解析器提供。
3. 在查询或展示适配处调用 `build_graph`。`view="files"` 归并到文件，保留每组关系的次数与最多 20 条依据。 `view="structure", detail=True` 显示段落和字段。 `anchor_ids` 用于指定单文件或节点范围，`neighbors` 决定是否带出一跳邻居，`cross_system` 决定是否显示已标记的跨系统边。文档入库如需要基础包含关系，可使用 `document_graph` 由宿主分配 ID 并保存。
4. 继续使用内网接口格式和分页。如果使用 `paginate_graph`，同一次筛选的各页应来自相同的 `generation`。节点和边分别分页，一条边的端点可能在后续页出现。客户端合并数据后只绘制端点已加载的边。内网若已有基于游标或子图的分页，可以保留。

## 前端怎么接

1. 把接口结果转换成上面的节点和边，用 `buildView(nodes, edges, { labels, keyword })` 取得展示节点、聚合连线和原关系三元组。点击连线时展示 `relations`、`occurrences` 和 `evidence`。点击节点时使用内网已有的源码跳转方式。
2. 用 `layoutGraph(nodes, triples)` 计算 `{ id: { x, y } }`。布局按连通分量分组，从连接较多的节点开始逐层摆放。将坐标喂给内网渲染库。大图可在模块 Worker 运行 [layout.worker.mjs](frontend/layout.worker.mjs)，通过请求序号丢弃过期的结果。内网构建链应按自己的 Worker 加载方式引用该模块。
3. 现有页面可以按 `labelVisibility(节点数, 缩放比例)` 控制标签密度。同向多种关系画一条线，在明细里保留各类型和出处。双向边可以用曲线区分。筛选或离开页面时清理旧渲染实例、事件和 Worker，拖动后保存节点坐标。

## 试跑与验收

[example.json](example.json) 是合成样本，包含一次跨工程调用、一条文档引用和一段 JCL 层级。在 `image` 的上一级目录可用 Python 运行以下片段，先校验字段映射，再接内网数据。

```python
import json
from pathlib import Path

from image.backend.associations import enrich
from image.backend.graph import build_graph

sample = json.loads(Path("image/example.json").read_text(encoding="utf-8"))
nodes, edges = enrich(**sample)
files = build_graph(nodes, edges, current_snapshots=sample["current_snapshots"])
assert {edge["rel"] for edge in files["edges"]} == {"CALLS", "MENTIONS"}
```

同时采用同级 `cut` 时，可用下面的适配函数把实际 ZIP 输出接入视图。内网保留自己的解析器时，按数据契约组装等价数据即可。

```python
from pathlib import Path

from cut import cut_zip
from image.backend.associations import enrich
from image.backend.graph import build_graph, project_graph_input

payload = cut_zip(Path("test-jcl.zip").read_bytes(), project="test-jcl")
current = {payload["job_id"]}
nodes, edges = enrich(**project_graph_input(payload), current_snapshots=current)
structure = build_graph(nodes, edges, current_snapshots=current, view="structure", detail=True)
assert any(edge["rel"] == "CONTAINS" for edge in structure["edges"])
```

示例仅处理一次上传。实际跨工程查询时，由内网选择用户可见的当前快照，汇集这些快照的图、引用和原文后统一匹配。

| 验收项 | 预期 |
| --- | --- |
| 同一数据的两种视图 | 文件视图能看到文件间引用。结构视图能看到 JCL 步骤与父级的包含关系。 |
| 新增一个同名候选 | 原来唯一匹配的静态引用变成歧义时不补边，已有经内网确认的基础关系继续使用。 |
| 过滤、分页、缩放与源码跳转 | 过滤范围和权限一致。分页后端点完整，关系依据和节点定位能回到对应版本的原文。 |

### 可直接交给内网 AI

```text
阅读 image/README.md。先确认内网实际的数据模型、查询入口、页面和渲染库，
用同一个工程对比接口返回和画面，定位问题在基础解析、图谱查询还是前端显示。
仅移植所需算法，通过字段适配复用现有鉴权、存储、API、路由和源码跳转。
内网已验证的关系规则优先保留。若有冲突，用同一批样本对比连线和原文依据。
验证文件与结构视图、跨工程引用、同名歧义和大图交互，记录改动和结果。
```
