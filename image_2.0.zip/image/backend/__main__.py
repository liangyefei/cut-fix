"""Build frontend-ready graph projections from exported cutter results."""

import argparse
import json
from pathlib import Path

from .associations import enrich
from .graph import build_graph, project_graph_input
from .inputs import _copybook_records


def main():
    parser = argparse.ArgumentParser(description='从 cut 和 cut_cpy 的 JSON 构建文件和结构图')
    parser.add_argument('--cut', action='append', type=Path, default=[], help='可重复传入 cut 导出的 JSON')
    parser.add_argument('--cpy', action='append', type=Path, default=[], help='可重复传入 cut_cpy 导出的 JSON')
    parser.add_argument('--snapshot-id', help='同一系统、工程和版本的快照 ID')
    parser.add_argument('--library')
    parser.add_argument('--project')
    parser.add_argument('--version')
    parser.add_argument('-o', '--output', type=Path, required=True)
    args = parser.parse_args()
    if not (args.cut or args.cpy):
        parser.error('至少提供一份 --cut 或 --cpy 输入')
    try:
        inputs = [*args.cut, *args.cpy]
        if any(path.resolve() == args.output.resolve() or
               (args.output.exists() and path.samefile(args.output)) for path in inputs):
            raise ValueError('输出路径需与切割产物分开')
        cuts = [json.loads(path.read_text('utf-8-sig')) for path in args.cut]
        copies = [book for path in args.cpy for book in _copybook_records(json.loads(path.read_text('utf-8-sig')))]
        snapshot_id = args.snapshot_id or (cuts[0]['job_id'] if len(cuts) == 1 else None)
        graph_input = project_graph_input(cuts, copybooks=copies, snapshot_id=snapshot_id,
                                          library=args.library, project=args.project, version=args.version)
        nodes, edges = enrich(**graph_input, current_snapshots={snapshot_id})
        output = {view: build_graph(nodes, edges, current_snapshots={snapshot_id}, view=view, detail=True)
                  for view in ('files', 'structure')}
        args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f'构建图谱失败：{error}\n')


if __name__ == '__main__':
    main()
