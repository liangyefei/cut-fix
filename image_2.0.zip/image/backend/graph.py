"""Graph projection for a normalized node and edge collection."""

from collections import Counter

from .inputs import project_graph_input


def _file_owners(nodes):
    files = [node for node in nodes if node['label'] in {'CodeFile', 'Document'}]
    file_ids = {node['id'] for node in files}
    code_owners = {
        (node['props'].get('snapshot_id'), node['props']['path']): node['id']
        for node in files if node['label'] == 'CodeFile' and node['props'].get('path')
    }
    owners = {}
    for node in nodes:
        props = node['props']
        owners[node['id']] = (
            node['id'] if node['id'] in file_ids else
            props.get('owner_id') or code_owners.get((props.get('snapshot_id'), props.get('path')))
        )
    return files, owners


def file_graph(nodes, edges):
    """Collapse structure to owning files and retain relation counts and evidence."""
    files, owners = _file_owners(nodes)
    file_ids = {node['id'] for node in files}
    grouped = {}
    for edge in edges:
        src, dst = owners.get(edge['src']), owners.get(edge['dst'])
        if src not in file_ids or dst not in file_ids or src == dst:
            continue
        rel = edge['rel']
        props = edge.get('props', {})
        group = grouped.setdefault((src, dst, rel), dict(
            src=src, dst=dst, rel=rel, props={**props, 'occurrences': 0, 'evidence_items': []},
        ))['props']
        group['occurrences'] += props.get('occurrences', 1)
        group['cross_project'] = bool(group.get('cross_project') or props.get('cross_project'))
        group['cross_system'] = bool(group.get('cross_system') or props.get('cross_system'))
        remaining = 20 - len(group['evidence_items'])
        group['evidence_items'].extend(props.get('evidence_items', [props])[:remaining])
    return files, list(grouped.values())


def build_graph(nodes, edges, *, current_snapshots=None, anchor_ids=None, library='',
                project='', version='', tag='', history=False, detail=False,
                neighbors=True, view='files', cross_system=False):
    """Project one authorized graph snapshot into a file or structure view."""
    if view not in {'files', 'structure'}:
        raise ValueError('view must be files or structure')
    current = set(current_snapshots) if current_snapshots is not None else None
    anchors = set(anchor_ids) if anchor_ids is not None else None
    edges = [edge for edge in edges if cross_system or not edge.get('props', {}).get('cross_system')]
    pinned = {node['props'].get('snapshot_id') for node in nodes
              if anchors is not None and node['id'] in anchors}
    if view == 'files':
        if anchors is not None:
            _, owners = _file_owners(nodes)
            anchors = {owners.get(node_id) for node_id in anchors} - {None}
        nodes, edges = file_graph(nodes, edges)

    available = {}
    for node in nodes:
        props = node['props']
        snapshot = props.get('snapshot_id')
        if (current is None or not snapshot or snapshot in current or snapshot in pinned
                or history or (version and anchors is None)):
            available[node['id']] = node

    def matches(node):
        props = node['props']
        node_library = props.get('library', '')
        return ((not library or node_library == library or node_library.startswith(library + '/'))
                and (not project or props.get('project') == project)
                and (not version or props.get('version') == version)
                and (not tag or tag in props.get('tags', [])))

    if anchors is None:
        owned = {node_id for node_id, node in available.items() if matches(node)}
    else:
        owned = anchors & available.keys()
    selected = set(owned)
    if neighbors and (anchors is not None or project or (cross_system and library)):
        for edge in edges:
            if edge['src'] in owned or edge['dst'] in owned:
                for node_id in (edge['src'], edge['dst']):
                    node = available.get(node_id)
                    if node and (cross_system or not library or node['props'].get('library') == library):
                        selected.add(node_id)

    visible = []
    for node_id, node in available.items():
        if node_id not in selected:
            continue
        props, label = node['props'], node['label']
        if view == 'structure' and not detail and (label in {'Field', 'DocumentSection'} or props.get('kind') == 'function'):
            continue
        if label == 'CodeUnit':
            label = 'Procedure' if props.get('kind') == 'function' else 'Program'
        visible.append({**node, 'label': label, 'name': node.get('name') or props.get('name') or node_id,
                        'external': node_id not in owned})
    visible.sort(key=lambda node: (node['label'] in {'Field', 'DocumentSection'},
                                   node['external'], node['label'], node['id']))
    ids = {node['id'] for node in visible}
    edges = [edge for edge in edges if edge['src'] in ids and edge['dst'] in ids]
    return dict(
        nodes=visible, edges=edges,
        stats=dict(nodes=len(visible), edges=len(edges),
                   by_label=dict(Counter(node['label'] for node in visible)),
                   cross_project=sum(bool(edge.get('props', {}).get('cross_project')) for edge in edges)),
    )


def paginate_graph(graph, *, offset=0, limit=1000, generation):
    """Slice an already projected graph. The caller supplies a stable generation."""
    if offset < 0 or not 1 <= limit <= 2000:
        raise ValueError('invalid graph pagination')
    end = offset + limit
    more = end < len(graph['nodes']) or end * 3 < len(graph['edges'])
    return {
        **graph, 'nodes': graph['nodes'][offset:end], 'edges': graph['edges'][offset * 3:end * 3],
        'generation': generation, 'truncated': more,
        'pagination': dict(offset=offset, limit=limit, next_offset=end if more else None),
    }


def document_graph(library, document, sections):
    """Build document containment from host-supplied node IDs and attributes."""
    sections = list(sections)
    owned = [{**node, 'props': {**node['props'], 'owner_id': document['id']}} for node in sections]
    edges = [dict(src=library['id'], dst=document['id'], rel='CONTAINS')]
    edges.extend(dict(src=document['id'], dst=node['id'], rel='CONTAINS') for node in owned)
    return dict(nodes=[library, document, *owned], edges=edges)
