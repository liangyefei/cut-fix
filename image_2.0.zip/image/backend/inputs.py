"""Combine existing cutter results for one host-selected source snapshot."""

from collections import defaultdict
from collections.abc import Mapping
from hashlib import sha256
from pathlib import PurePosixPath


CODE_SUFFIXES = {'.aps', '.cbl', '.cob', '.cobol'}


def _path(value):
    path = PurePosixPath(value.replace('\\', '/'))
    if not path.parts or path.is_absolute() or '..' in path.parts or ':' in path.parts[0]:
        raise ValueError(f'Expected a project-relative source path: {value!r}')
    return path.as_posix()


def _copybook_graph(book, path, common):
    prefix = 'copybook/' + sha256(f'{common["snapshot_id"]}\0{path}'.encode()).hexdigest()
    file_id = prefix + '/file'
    props = {**common, 'path': path, 'engine': 'cut_cpy'}
    nodes = [dict(id=file_id, label='CodeFile', props={
        **props, 'name': PurePosixPath(path).name, 'kind': 'file', 'start_line': 1,
        'end_line': len(book['source'].splitlines()), 'source_format': book.get('source_format'),
        'diagnostics': book.get('diagnostics', []),
    })]
    ids = {symbol['id']: prefix + '/symbol/' + symbol['id'] for symbol in book['symbols']}
    edges = []
    for symbol in book['symbols']:
        symbol_id = ids[symbol['id']]
        procedure = symbol['kind'] in {'function', 'section', 'fragment'}
        node_props = {key: value for key, value in symbol.items() if key not in {'id', 'parent_id'}}
        nodes.append(dict(id=symbol_id, label='CodeUnit' if procedure else 'Field', props={
            **props, **node_props, 'owner_id': file_id, 'symbol_kind': symbol['kind'],
            'kind': 'function' if procedure else symbol['kind'],
        }))
        parent = ids.get(symbol['parent_id'], file_id)
        edges.append(dict(src=parent, dst=symbol_id, rel='CONTAINS', props={'line': symbol['statement_line']}))
    return nodes, edges


def _copybook_records(copybooks):
    if isinstance(copybooks, Mapping):
        return copybooks['files'] if 'files' in copybooks else (copybooks,)
    return copybooks or ()


def project_graph_input(payload=None, *, copybooks=None, snapshot_id=None, library=None,
                        project=None, version=None, doc_ids=None):
    """Adapt one or more cut payloads and cut_cpy records for one source snapshot.

    Supplying copybooks makes cut_cpy the source of all Copybook nodes and their
    outgoing relations. With copybooks=None the existing cut-only API is retained.
    """
    payloads = [payload] if isinstance(payload, Mapping) else list(payload or ())
    if snapshot_id is None and len(payloads) == 1:
        snapshot_id = payloads[0]['job_id']
    if not isinstance(snapshot_id, str) or not snapshot_id.strip():
        raise ValueError('Provide snapshot_id when combining cutter runs or importing only Copybooks')
    options = payloads[0].get('options', {}) if payloads else {}
    common = dict(snapshot_id=snapshot_id, library=options.get('library', '') if library is None else library,
                  project=options.get('project', '') if project is None else project,
                  version=options.get('version', '') if version is None else version,
                  tags=options.get('tags', []))
    doc_ids = {_path(path): value for path, value in (doc_ids or {}).items()}
    nodes, edges, references, sources = [], [], [], {}
    cut_nodes, cut_edges = [], []
    legacy_cpy = {}
    mixed = copybooks is not None

    def add_source(path, text):
        if path.casefold() in sources:
            raise ValueError(f'Duplicate source path in snapshot {snapshot_id}: {path}')
        row = dict(snapshot_id=snapshot_id, path=path, text=text)
        if path in doc_ids:
            row['doc_id'] = doc_ids[path]
        sources[path.casefold()] = row

    for item in payloads:
        result = item['result']
        paths = set()
        for name, text in item['sources'].items():
            path = _path(name)
            suffix = PurePosixPath(path).suffix.casefold()
            if mixed and suffix == '.cpy':
                legacy_cpy[path.casefold()] = text
            if not mixed or suffix in CODE_SUFFIXES:
                add_source(path, text)
                paths.add(path)
        for node in result['nodes']:
            path = _path(node['props']['path'])
            props = {**common, **node['props'], 'path': path, 'snapshot_id': snapshot_id}
            for key, value in (('library', library), ('project', project), ('version', version)):
                if value is not None:
                    props[key] = value
            if path in doc_ids:
                props['doc_id'] = doc_ids[path]
            cut_nodes.append(({**node, 'props': props}, path in paths))
        cut_edges.extend(result['edges'])
        for ref in result.get('unresolved', ()):
            if ref['path'] and ref['kind'] in {'calls', 'imports'} and _path(ref['path']) in paths:
                references.append({**ref, 'path': _path(ref['path']), 'snapshot_id': snapshot_id})

    copy_files, copy_symbols = {}, defaultdict(set)
    for book in _copybook_records(copybooks):
        path = _path(book['path'])
        if PurePosixPath(path).suffix.casefold() != '.cpy':
            raise ValueError(f'Expected a .cpy parse result: {path}')
        original = legacy_cpy.get(path.casefold())
        if original is not None and original.removeprefix('\ufeff').replace('\r\n', '\n').replace('\r', '\n') != book['source']:
            raise ValueError(f'cut and cut_cpy refer to different source versions: {path}')
        add_source(path, book['source'])
        sources[path.casefold()]['source_format'] = book.get('source_format')
        book_common = {**common, 'doc_id': doc_ids[path]} if path in doc_ids else common
        book_nodes, book_edges = _copybook_graph(book, path, book_common)
        nodes.extend(book_nodes)
        edges.extend(book_edges)
        copy_files[path.casefold()] = book_nodes[0]['id']
        for node in book_nodes[1:]:
            props = node['props']
            key = (path.casefold(), props['name'].casefold())
            for line in (props['start_line'], props['statement_line']):
                copy_symbols[key + (line,)].add(node['id'])
        for ref in book['imports']:
            if ref.get('terminated', True):
                references.append({**ref, 'snapshot_id': snapshot_id, 'path': path, 'kind': 'imports',
                                   'line': ref['start_line']})

    kept, replaced = {}, {}
    paths_by_id = {node['id']: node['props']['path'] for node, _ in cut_nodes}
    for node, keep in cut_nodes:
        props = node['props']
        path = props['path'].casefold()
        if keep:
            nodes.append(node)
            kept[node['id']] = props
            if props.get('kind') == 'import':
                references.append(dict(snapshot_id=snapshot_id, kind='imports', name=props['name'],
                                       path=props['path'], line=props['start_line']))
        elif path in copy_files:
            if node['label'] == 'CodeFile':
                replaced[node['id']] = copy_files[path]
            else:
                key = (path, props['name'].casefold(), props.get('statement_line', props.get('start_line')))
                matches = copy_symbols.get(key, ())
                if len(matches) == 1:
                    replaced[node['id']] = next(iter(matches))
    for edge in cut_edges:
        if edge['src'] in kept and (edge['dst'] in kept or edge['dst'] in replaced):
            # Re-resolve imports to authoritative CPYs using the COPY operand and library.
            if edge['rel'] == 'IMPORTS' and edge['dst'] in replaced:
                references.append(dict(snapshot_id=snapshot_id, kind='imports',
                    name=PurePosixPath(paths_by_id[edge['dst']]).stem, path=kept[edge['src']]['path'],
                    line=edge.get('props', {}).get('line'), source_id=edge['src']))
                continue
            edges.append({**edge, 'dst': replaced.get(edge['dst'], edge['dst'])})
    return dict(nodes=nodes, edges=edges, references=references, sources=list(sources.values()))
