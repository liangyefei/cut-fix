"""Resolve source-backed graph links from records supplied by the host."""

from collections import defaultdict
from pathlib import PurePosixPath
import re


QUOTED = r'"(?:""|[^"\n])*"' r"|'(?:''|[^'\n])*'"
OPERAND = rf'(?:{QUOTED}|[\w@$#-]+)'
DIRECTIVE = re.compile(
    rf'{QUOTED}|(?<![\w-])(?P<verb>COPY|CALL)\s+(?P<name>{OPERAND})'
    rf'(?:\s+(?:OF|IN)\s+(?P<library>{OPERAND}))?', re.I)
COMMENT = re.compile(rf'{QUOTED}|(?P<comment>\*>.*)')
FIXED_PREFIX = re.compile(r'[ A-Z0-9]{6}[ */Dd-]', re.I)
FREE_REFERENCE = re.compile(r'^\s{0,6}(?:COPY|CALL|OF|IN)\b', re.I)
SOURCE_FORMAT = re.compile(r'^\s*>>\s*SOURCE\s+(?:FORMAT\s+)?(?:IS\s+)?(FIXED|FREE)\b', re.I)


def _operand(value):
    if value.startswith(('"', "'")):
        quote = value[0]
        return value[1:-1].replace(quote * 2, quote)
    return value


def _relative(value):
    return PurePosixPath(value.replace('\\', '/'))


def _symbol(value):
    path = _relative(value)
    return (path.stem if path.suffix.lower() == '.cpy' else path.name).upper()


def _code(line, source_format):
    row = line.expandtabs(8)
    if source_format != 'free' and FIXED_PREFIX.match(row) and (source_format == 'fixed' or not FREE_REFERENCE.match(row)):
        if row[6] in '*/':
            return ''
        row = row[7:72]
    for match in COMMENT.finditer(row):
        if match['comment']:
            return row[:match.start()]
    return row


def _source_lines(text, source_format):
    lines = []
    for row in text.splitlines():
        code = _code(row, source_format)
        if mode := SOURCE_FORMAT.match(code):
            source_format = mode[1].lower()
            code = ''
        lines.append(code)
    return lines


def _reference_on_line(lines, line, ref):
    if not isinstance(line, int) or not 1 <= line <= len(lines):
        return None
    end = max(line, ref.get('end_line') or line + 7)
    code = lines[line - 1:end]
    verb = 'CALL' if ref['kind'].lower() == 'calls' else 'COPY'
    for match in DIRECTIVE.finditer('\n'.join(code)):
        if match.start() >= len(code[0]):
            break
        if (match['verb'] or '').upper() != verb:
            continue
        operand = _operand(match['name'])
        if _symbol(operand) != _symbol(_operand(ref['name'])):
            continue
        if verb == 'CALL' and not match['name'].startswith(('"', "'")):
            continue
        qualifier = _operand(match['library']) if match['library'] else ref.get('library')
        return operand, qualifier, match.group().strip()[:600]
    return None


def _import_candidates(candidates, ref, operand, qualifier):
    path = _relative(operand)
    if ref.get('status') == 'ambiguous':
        return []
    if qualifier:
        name = qualifier.casefold()
        candidates = [node for node in candidates if name == (node['props'].get('copy_library') or '').casefold()
                      or name in {part.casefold() for part in _relative(node['props']['path']).parts[:-1]}]
    if len(path.parts) > 1 or path.suffix.lower() == '.cpy':
        key = path.as_posix().casefold()
        names = {key} if path.suffix.lower() == '.cpy' else {key, key + '.cpy'}
        candidates = [node for node in candidates if any(
            node['props']['path'].casefold() == name or node['props']['path'].casefold().endswith('/' + name)
            for name in names)]
    if ref.get('status') == 'resolved' and ref.get('target'):
        resolved = _relative(ref['target']).as_posix().casefold()
        return [node for node in candidates if node['props']['snapshot_id'] == ref['snapshot_id']
                and node['props']['path'].casefold() == resolved]
    return candidates


def enrich(nodes, edges, *, current_snapshots, references, sources, documents=()):
    """Return a graph with static CALL, COPY, and explicit document mentions."""
    current = set(current_snapshots)
    source_map = {(row['snapshot_id'], row['path']): row for row in sources}
    known_copies = {
        (snapshot, PurePosixPath(path).stem.upper())
        for snapshot, path in source_map if PurePosixPath(path).suffix.lower() == '.cpy'
    }
    nodes = [
        {**node, 'props': {**node['props'], 'doc_id': source['doc_id']}}
        if (source := source_map.get((node['props'].get('snapshot_id'), node['props'].get('path'))))
        and source.get('doc_id') else node
        for node in nodes
    ]
    by_id = {node['id']: node for node in nodes}
    files, programs, copies = defaultdict(list), defaultdict(list), defaultdict(list)
    for node in nodes:
        props = node['props']
        snapshot, path = props.get('snapshot_id'), props.get('path', '')
        if snapshot not in current:
            continue
        files[snapshot, path].append(node)
        suffix = PurePosixPath(path).suffix.lower()
        if props.get('kind') == 'module' and suffix in {'.cbl', '.cob', '.cobol'}:
            programs[(node.get('name') or props.get('name', '')).upper()].append(node)
        if node['label'] == 'CodeFile' and suffix == '.cpy':
            copies[PurePosixPath(path).stem.upper()].append(node)

    derived = []
    seen = {(edge['src'], edge['rel'], edge['dst'], edge.get('props', {}).get('line')) for edge in edges}
    seen_references = set()
    for edge in edges:
        if edge['rel'] in {'CALLS', 'IMPORTS'} and edge['src'] in by_id:
            props = by_id[edge['src']]['props']
            seen_references.add((props.get('snapshot_id'), props.get('path'), edge['rel'],
                                 edge['dst'], edge.get('props', {}).get('line')))
    source_lines = {}
    for ref in references:
        snapshot, path = ref['snapshot_id'], ref['path']
        kind = ref['kind'].lower()
        if snapshot not in current or kind not in {'calls', 'imports'}:
            continue
        key = (snapshot, path)
        source_record = source_map.get(key)
        source = by_id.get(ref.get('source_id'))
        props = source['props'] if source else {}
        if (props.get('snapshot_id'), props.get('path')) != key:
            source = next((node for node in files[key] if node['props'].get('kind') == 'module'), None)
        source = source or next((node for node in files[key] if node['label'] == 'CodeFile'), None)
        if not source or not source_record:
            continue

        if key not in source_lines:
            source_lines[key] = _source_lines(source_record['text'], source_record.get('source_format'))
        line = ref.get('line')
        evidence = _reference_on_line(source_lines[key], line, ref)
        if evidence is None:
            continue
        operand, qualifier, snippet = evidence
        symbol = _symbol(operand)
        candidates = (programs if kind == 'calls' else copies).get(symbol, [])
        if kind == 'imports':
            candidates = _import_candidates(candidates, ref, operand, qualifier)
        local = [node for node in candidates if node['props'].get('snapshot_id') == snapshot]
        if kind == 'imports' and not local and not qualifier and (snapshot, symbol) in known_copies:
            continue
        candidates = local or candidates
        if kind == 'imports' and local and not qualifier:
            same_directory = [node for node in local if _relative(node['props']['path']).parent == _relative(path).parent]
            candidates = same_directory or candidates
        library = source['props'].get('library')
        preferred = [node for node in candidates if node['props'].get('library') == library]
        candidates = preferred or candidates
        if len(candidates) != 1:
            continue

        target = candidates[0]
        rel = 'CALLS' if kind == 'calls' else 'IMPORTS'
        identity = snapshot, path, rel, target['id'], line
        if identity in seen_references:
            continue
        seen_references.add(identity)
        target_props = target['props']
        derived.append(dict(src=source['id'], rel=rel, dst=target['id'], props=dict(
            line=line, symbol=symbol, evidence=snippet, method='literal_unique_symbol',
            cross_project=snapshot != target_props.get('snapshot_id'),
            cross_system=library != target_props.get('library'),
            source_snapshot=snapshot, target_snapshot=target_props.get('snapshot_id'),
        )))

    symbols = programs.keys() | copies.keys()
    for row in documents:
        source = by_id.get(row['node_id'])
        if not source or source['label'] != 'Document':
            continue
        text, props = row['text'], source['props']
        words = {word.upper() for word in re.findall(r'[A-Za-z0-9][A-Za-z0-9_-]*', text)}
        for symbol in sorted(words & symbols):
            candidates = programs.get(symbol, []) + copies.get(symbol, [])
            for field in ('library', 'project'):
                preferred = [node for node in candidates if node['props'].get(field) == props.get(field)]
                candidates = preferred or candidates
            if len(candidates) != 1:
                continue
            match = re.search(r'(?<![\w-])' + re.escape(symbol) + r'(?![\w-])', text, re.I)
            if not match:
                continue
            line = text.count('\n', 0, match.start()) + 1
            target = candidates[0]
            identity = source['id'], 'MENTIONS', target['id'], line
            if identity in seen:
                continue
            seen.add(identity)
            target_props = target['props']
            derived.append(dict(src=source['id'], rel='MENTIONS', dst=target['id'], props=dict(
                line=line, symbol=symbol, evidence=text.splitlines()[line - 1][:600],
                method='explicit_unique_mention',
                cross_project=props.get('project') != target_props.get('project'),
                cross_system=props.get('library') != target_props.get('library'),
            )))
    return nodes, [*edges, *derived]
