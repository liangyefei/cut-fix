// Fetch a consistent projection before drawing edges whose endpoints span pages.
export async function loadGraphPages(fetchPage, params = {}, { signal } = {}) {
  const first = await fetchPage({ ...params, offset: 0 }, { signal });
  const nodes = [...first.nodes];
  const edges = [...first.edges];
  let offset = 0;
  let next = first.pagination?.next_offset;
  let last = first;
  while (next != null) {
    if (!Number.isSafeInteger(next) || next <= offset || first.generation == null) {
      throw new Error('图谱分页缺少有效的偏移量或快照版本');
    }
    offset = next;
    const page = await fetchPage({ ...params, offset }, { signal });
    if (page.generation !== first.generation) throw new Error('加载期间图谱发生更新，请重新加载');
    nodes.push(...page.nodes);
    edges.push(...page.edges);
    last = page;
    next = page.pagination?.next_offset;
  }
  return { ...first, nodes, edges, truncated: !!last.truncated, pagination: null };
}
