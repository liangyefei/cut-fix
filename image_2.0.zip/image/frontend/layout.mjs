// Coordinates for any renderer that accepts positioned nodes.
export function layoutGraph(nodes, edges) {
  const adjacency = new Map(nodes.map(({ id }) => [id, new Set()]));
  for (const { src, dst } of edges) {
    if (adjacency.has(src) && adjacency.has(dst)) {
      adjacency.get(src).add(dst);
      adjacency.get(dst).add(src);
    }
  }
  const ordered = [...adjacency.keys()].sort(
    (a, b) => adjacency.get(b).size - adjacency.get(a).size || a.localeCompare(b),
  );
  const visited = new Set();
  const positions = Object.create(null);
  let groupX = 0;
  let groupY = 0;
  let rowHeight = 0;
  const rowsFor = (level) => Math.min(64, Math.max(1, Math.ceil(Math.sqrt(level.length * 0.75))));

  for (const root of ordered) {
    if (visited.has(root)) continue;
    const queue = [root];
    const depths = new Map([[root, 0]]);
    const levels = new Map();
    visited.add(root);
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const id = queue[cursor];
      const depth = depths.get(id);
      if (!levels.has(depth)) levels.set(depth, []);
      levels.get(depth).push(id);
      for (const next of adjacency.get(id)) {
        if (visited.has(next)) continue;
        visited.add(next);
        depths.set(next, depth + 1);
        queue.push(next);
      }
    }

    let width = 0;
    let height = 0;
    for (const level of levels.values()) {
      height = Math.max(height, (rowsFor(level) - 1) * 90 + 120);
    }
    let levelX = 0;
    for (const level of levels.values()) {
      const rows = rowsFor(level);
      const top = (height - ((rows - 1) * 90 + 120)) / 2;
      level.forEach((id, row) => {
        const x = levelX + Math.floor(row / rows) * 180;
        const y = top + (row % rows) * 90;
        positions[id] = { x: groupX + x, y: groupY + y };
        width = Math.max(width, x + 240);
      });
      levelX += Math.ceil(level.length / rows) * 180 + 120;
    }
    groupX += width + 120;
    rowHeight = Math.max(rowHeight, height);
    if (groupX > 2400) {
      groupX = 0;
      groupY += rowHeight + 160;
      rowHeight = 0;
    }
  }
  return positions;
}
