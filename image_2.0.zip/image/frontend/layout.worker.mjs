import { layoutGraph } from './layout.mjs';

self.onmessage = ({ data: { request, nodes, edges } }) => {
  self.postMessage({ request, positions: layoutGraph(nodes, edges) });
};
