// Presentation data shared by graph canvases and relation detail panels.
export function buildView(nodes, edges, { labels, keyword = '' } = {}) {
  const types = labels == null ? null : new Set(labels);
  const candidates = nodes.filter((node) => types == null || types.has(node.label));
  const candidateIds = new Set(candidates.map((node) => node.id));
  const available = edges.filter(({ src, dst }) => candidateIds.has(src) && candidateIds.has(dst));
  const query = keyword.trim().toLowerCase();
  const hits = new Set(candidates.filter((node) =>
    !query || [node.name || node.props?.name || '', node.id].some((value) => value.toLowerCase().includes(query)),
  ).map((node) => node.id));
  const selected = new Set(hits);
  if (query) {
    for (const { src, dst } of available) {
      if (hits.has(src)) selected.add(dst);
      if (hits.has(dst)) selected.add(src);
    }
  }

  const visible = candidates.filter((node) => selected.has(node.id));
  const triples = available.filter(({ src, dst }) => selected.has(src) && selected.has(dst));
  const grouped = new Map();
  for (const { src, dst, rel, props = {} } of triples) {
    const id = JSON.stringify([src, dst]);
    if (!grouped.has(id)) {
      grouped.set(id, { id, src, dst, relations: [], occurrences: 0, evidence: [], cross_project: false });
    }
    const group = grouped.get(id);
    if (!group.relations.includes(rel)) group.relations.push(rel);
    group.occurrences += props.occurrences ?? 1;
    group.cross_project ||= !!props.cross_project;
    const remaining = 20 - group.evidence.length;
    for (const item of (props.evidence_items ?? [props]).slice(0, remaining)) {
      group.evidence.push({ ...item, src, dst, rel });
    }
  }

  const displayEdges = [...grouped.values()].map((edge) => ({
    ...edge,
    shape: edge.src === edge.dst ? 'loop' :
      grouped.has(JSON.stringify([edge.dst, edge.src])) ? 'curve' : 'line',
  }));
  return { nodes: visible, triples, displayEdges };
}

export function labelVisibility(nodeCount, zoom, showRelations = true) {
  return {
    relations: showRelations && (nodeCount < 250 || zoom >= 0.35),
    nodes: nodeCount < 600 || zoom >= 0.25,
  };
}
