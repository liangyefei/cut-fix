import { layoutGraph } from './layout.mjs';
import { buildView, labelVisibility } from './view-model.mjs';

const colors = ['#5b8ff9', '#61d9a3', '#f6bd16', '#7262fd', '#78d3f8', '#f6903d', '#e868a2', '#65789b'];
const nodeColors = {
  CodeFile: '#b8c8e6', Program: '#5b8ff9', Procedure: '#78d3f8', Field: '#61d9a3',
  CopyBook: '#7262fd', Document: '#f6bd16', DocumentSection: '#f6903d', System: '#65789b',
};
const names = { CALLS: '调用', CONTAINS: '包含', IMPORTS: '引入', MENTIONS: '提及',
  REFERENCES: '引用', READS: '读取', WRITES: '写入' };

function projectColors(nodes) {
  const keys = [...new Set(nodes.map(projectKey))].sort();
  return new Map(keys.map((key, index) => [key, colors[index % colors.length]]));
}

function projectKey(node) {
  return JSON.stringify([node.props?.library, node.props?.project]);
}

/** Mount the G6 4.x renderer in a container managed by the host page. */
export function mountGraph(container, { G6, onNodeClick, onEdgeClick, useWorker = true } = {}) {
  const foreground = getComputedStyle(container).color;
  const graph = new G6.Graph({
    container, renderer: 'canvas', animate: false, pixelRatio: 1,
    width: container.clientWidth || 900, height: container.clientHeight || 480,
    modes: { default: [{ type: 'drag-canvas', enableOptimize: true }, { type: 'zoom-canvas', enableOptimize: true }, 'drag-node'] },
    defaultNode: { type: 'circle', size: 26, labelCfg: { position: 'bottom', style: { fontSize: 11, fill: foreground } } },
    defaultEdge: { style: { endArrow: true, stroke: '#c5cdd8' }, labelCfg: { autoRotate: true, style: { fontSize: 11, fill: foreground } } },
    nodeStateStyles: { hover: { stroke: '#1677ff', lineWidth: 3 }, selected: { stroke: '#f5222d', lineWidth: 2.5 } },
  });
  graph.get('canvas').set('localRefresh', false);
  let sequence = 0;
  let worker;
  let pending;
  let destroyed = false;
  let rendered = false;
  let data;
  let previousView;
  let showRelations = true;
  let visible = {};
  let nodeCount = 0;
  const dragged = new Map();

  function finishLayout(positions) {
    if (!pending) return;
    const { resolve, timer } = pending;
    pending = undefined;
    clearTimeout(timer);
    resolve(positions);
  }

  async function positionsFor(nodes, edges, request) {
    if (!useWorker || typeof Worker === 'undefined') return layoutGraph(nodes, edges);
    try {
      if (!worker) {
        worker = new Worker(new URL('./layout.worker.mjs', import.meta.url), { type: 'module' });
        worker.onmessage = ({ data: result }) => {
          if (result.request === pending?.request) finishLayout(result.positions);
        };
        worker.onerror = () => {
          worker?.terminate();
          worker = undefined;
          finishLayout();
        };
      }
      const positions = await new Promise((resolve) => {
        pending = { request, resolve, timer: setTimeout(() => finishLayout(), 8000) };
        worker.postMessage({ request, nodes: nodes.map(({ id }) => ({ id })),
          edges: edges.map(({ src, dst }) => ({ src, dst })) });
      });
      if (request !== sequence || destroyed) return {};
      return positions || layoutGraph(nodes, edges);
    } catch {
      finishLayout();
      return layoutGraph(nodes, edges);
    }
  }

  function updateLabels() {
    if (!rendered || destroyed) return;
    const next = labelVisibility(nodeCount, graph.getZoom(), showRelations);
    if (next.nodes === visible.nodes && next.relations === visible.relations) return;
    graph.setAutoPaint(false);
    if (next.relations !== visible.relations) {
      for (const item of graph.getEdges()) graph.updateItem(item, { label: next.relations ? item.getModel().relationText : '' });
    }
    if (next.nodes !== visible.nodes) {
      for (const item of graph.getNodes()) graph.updateItem(item, { label: next.nodes ? item.getModel().nodeText : '' });
    }
    visible = next;
    graph.setAutoPaint(true);
    graph.paint();
  }

  graph.on('viewportchange', updateLabels);
  graph.on('node:mouseenter', ({ item }) => {
    if (!item) return;
    container.style.cursor = 'pointer';
    graph.setItemState(item, 'hover', true);
  });
  graph.on('node:mouseleave', ({ item }) => {
    container.style.cursor = '';
    if (item) graph.setItemState(item, 'hover', false);
  });
  graph.on('node:dragend', ({ item }) => {
    const node = item?.getModel();
    if (node) dragged.set(node.id, { x: node.x, y: node.y });
  });
  graph.on('node:click', ({ item }) => {
    if (!item) return;
    for (const selected of graph.findAllByState('node', 'selected')) graph.setItemState(selected, 'selected', false);
    graph.setItemState(item, 'selected', true);
    onNodeClick?.(item.getModel().record);
  });
  graph.on('edge:click', ({ item }) => {
    if (item) onEdgeClick?.(item.getModel().record);
  });

  function resize() {
    if (!destroyed && container.clientWidth && container.clientHeight) {
      graph.changeSize(container.clientWidth, container.clientHeight);
    }
  }
  const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : undefined;
  observer?.observe(container);

  async function render(payload, { view = 'files', labels, keyword = '', fit = true } = {}) {
    if (destroyed) return;
    const request = ++sequence;
    finishLayout();
    const display = buildView(payload.nodes, payload.edges, { labels, keyword });
    const positions = await positionsFor(display.nodes, display.triples, request);
    if (request !== sequence || destroyed) return;
    if (payload !== data || view !== previousView) dragged.clear();
    data = payload;
    previousView = view;
    const palette = projectColors(payload.nodes);
    nodeCount = display.nodes.length;
    visible = labelVisibility(nodeCount, graph.getZoom(), showRelations);
    const models = {
      nodes: display.nodes.map((node) => {
        const name = node.name || node.props?.name || node.id;
        const nodeText = view === 'files'
          ? [name.split('/').pop(), node.props?.project].filter(Boolean).join('\n')
          : name.length > 18 ? `${name.slice(0, 17)}…` : name;
        const fill = view === 'files' ? palette.get(projectKey(node)) : nodeColors[node.label] || '#9099a6';
        return { id: node.id, ...(dragged.get(node.id) || positions[node.id]), nodeText, record: node,
          label: visible.nodes ? nodeText : '', style: { fill,
            ...(node.external ? { lineDash: [4, 3], stroke: foreground, lineWidth: 1.5 } : {}) } };
      }),
      edges: display.displayEdges.map((edge) => {
        const relationText = edge.relations.map((rel) => names[rel] || rel).join(' / ')
          + (edge.cross_project ? '（跨工程）' : '');
        return { id: `edge:${edge.id}`, source: edge.src, target: edge.dst, curveOffset: 30,
          type: edge.shape === 'curve' ? 'quadratic' : edge.shape,
          label: visible.relations ? relationText : '', relationText, record: edge,
          style: edge.cross_project ? { stroke: '#8b5cf6', lineWidth: 2, lineDash: [6, 3], endArrow: true } : undefined };
      }),
    };
    if (rendered) graph.changeData(models);
    else {
      graph.data(models);
      graph.render();
      rendered = true;
    }
    if (fit && nodeCount) {
      graph.fitView(40);
      if (graph.getZoom() > 1) { graph.zoomTo(1); graph.fitCenter(); }
    }
    updateLabels();
  }

  return {
    render, resize,
    showRelationLabels(value) { showRelations = !!value; updateLabels(); },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      finishLayout();
      worker?.terminate();
      observer?.disconnect();
      graph.destroy();
      container.style.cursor = '';
    },
  };
}
