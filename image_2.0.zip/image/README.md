# 内网代码图谱接入

APS、CBL 继续走 `cut`，CPY 继续走 `cut_cpy`。`backend/` 把解析产物组装成图谱，`frontend/` 用图谱 JSON 布局和绘制。两端可以独立接入和验收。

```text
APS、CBL ── cut ───── 节点、边、静态引用、原文 ─┐
CPY ────── cut_cpy ── 符号层级、COPY 引用、原文 ─┤
                                                ↓
                    backend 构图 → 文件视图 / 结构视图 JSON
                                                ↓
                    frontend 过滤 / 布局 → G6 画布和交互
```

## 后端构建

### 用现有切割 JSON 验证

在 `image` 上一级执行，输入是内网现有两个切割入口导出的 JSON。

```powershell
python -B -m image.backend --cut aps.json --cut cbl.json --cpy cpy.json --snapshot-id core-v1 --library core --project clearing --version v1 -o graph.json
```

如果 APS、CBL 同在一个 `cut` 导出里，传一份 `--cut` 即可。`--cpy` 可以重复传入，每份可以是 CPY CLI 的 `files` 包装或单文件解析结果。两套结果应使用同一个工程根目录下的相对路径，例如 `cbl/ENTRY.cbl` 和 `copy/COMMON.cpy`。`snapshot-id` 由宿主提供，每一版源码使用独立 ID。

输出的 `files` 和 `structure` 各有 `nodes`、`edges` 和 `stats`，可以直接交给前端。文件视图聚合文件间关系，隐藏文件内的包含边。结构视图保留 APS 结构、COBOL 段落和 CPY 字段。

### 接到内网 API

```python
from image.backend.associations import enrich
from image.backend.graph import build_graph, paginate_graph, project_graph_input

inputs = project_graph_input(
    [aps_result, cbl_result], copybooks=cpy_result,
    snapshot_id=snapshot_id, library=library, project=project, version=version,
    doc_ids=source_document_ids,  # 可选，{相对路径: 内网原文 ID}
)

# 跨工程时先汇集当前用户可见的各快照输入，再统一补边。
current = {snapshot_id}
nodes, edges = enrich(**inputs, current_snapshots=current)
graph = build_graph(nodes, edges, current_snapshots=current, view='structure', detail=True)
page = paginate_graph(graph, offset=0, limit=1000, generation=published_graph_revision)
```

`project_graph_input` 返回 `nodes`、`edges`、`references`、`sources`。可以在发布时保存基础图，也可以在已有解析结果上即时构图。保存引用关系时，应保留同一对节点之间不同源码行的依据。权限在宿主取数阶段处理，候选节点、原文、引用和文档须来自同一授权范围。

| 接口字段 | 约定 |
| --- | --- |
| 节点 | `id`、`label`、`props`。`props.path`、`snapshot_id`、`doc_id`、`statement_line` / `start_line` 用于定位同版本原文。 |
| 边 | `src`、`dst`、`rel`、`props`。端点使用返回的节点 ID。`line` 是源码行号，聚合后用 `occurrences` 和 `evidence_items` 表示引用次数和依据。 |
| 分页 | 同一次筛选用相同 `generation`。`pagination.next_offset` 表示下一页。节点和边独立分页，合并后校验端点。 |

- 传入 `copybooks` 时，CPY 节点和父子关系以 `cut_cpy.symbols` 为准。若 `cut` 输入也带 CPY，会核对同路径原文。旧的入边只有在文件匹配，或字段名和声明行唯一匹配时才重连。
- CBL 的 `COPY` 结合解析引用和原文匹配 CPY。`COPY X OF LIB` 或 `COPY X IN LIB` 的库名按 CPY 路径中的目录名或宿主设置的节点 `props.copy_library` 验证。逻辑库映射由宿主在 `enrich` 前配置。歧义、缺少原文依据和动态 `CALL` 的引用不会生成派生边。
- 如需 CBL → CPY 的字段级 `REFERENCES`，让 `cut` 在解析 CBL 时同时看到 CPY 原文，例如将两类原文放进同一个工程 ZIP。`image` 会用 `cut_cpy` 的符号替换 CPY 节点，并按路径、名称和声明行迁移能核实的入边。仅用 CBL 单独解析产物时，可以补文件级 `COPY`，字段级关系以已有静态解析证据为准。
- `build_graph` 处理系统、工程、版本、文件和邻居筛选。`cross_system=True` 时显示跨系统边。

## 前端显示

本地页面使用 G6 4.x。已有这个版本的页面可挂载 `g6-graph.mjs`。其他渲染器可以使用 `view-model.mjs` 的聚合结果及 `layout.mjs` 的坐标。宿主提供接口、原文跳转和依据面板。

```javascript
import G6 from '@antv/g6';
import { mountGraph } from './image/frontend/g6-graph.mjs';
import { loadGraphPages } from './image/frontend/pages.mjs';

const canvas = mountGraph(document.querySelector('#code-graph'), {
  G6,
  onNodeClick(node) {
    const p = node.props;
    openSource(p.doc_id, p.path, p.statement_line ?? p.start_line);
  },
  onEdgeClick(edge) {
    showReferences(edge.relations, edge.occurrences, edge.evidence);
  },
});

// fetchGraphPage(params, { signal }) 由宿主实现，返回解包后的图谱对象。
const view = 'files';
const data = await loadGraphPages(fetchGraphPage, { view });
await canvas.render(data, { view });
// 使用命令行导出的 graph.json 时，可直接 canvas.render(bundle[view], { view })。
// 页面卸载时调用 canvas.destroy()。
```

给容器设置明确高度，例如 `height: 560px`。静态模块由内网 HTTP 服务或前端构建工具提供。布局 Worker 从同目录加载，创建失败时使用主线程布局。画布支持缩放、拖拽、项目颜色、双向曲线、跨工程虚线和按缩放调整标签。可传 `labels`、`keyword` 重新渲染，或调用 `canvas.showRelationLabels(false)` 隐藏关系文字。

## 内网验收

1. 用一个包含 APS、CBL 和 CPY 的快照跑后端构图，先核对 `graph.json`。CBL 的 `COPY` 应连接到对应 CPY。父组、字段、88 条件应出现在结构图并能定位原文。
2. 加入另一个同名 CPY，核对带库限定的引用仍指向正确库。无法确认目标的引用应留待核查。
3. 在内网页面分别加载两个视图，核对关系、层级、分页完整性和源码跳转。
