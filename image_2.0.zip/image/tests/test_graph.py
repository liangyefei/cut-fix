import unittest

from image.backend.associations import enrich
from image.backend.graph import build_graph, project_graph_input


def node(node_id, path, name, kind, line=1):
    label = {'file': 'CodeFile', 'module': 'CodeUnit', 'field': 'Field'}[kind]
    return dict(id=node_id, label=label, props=dict(path=path, name=name, kind=kind, start_line=line))


def cut_job(sources, nodes, edges=(), unresolved=(), job_id='cut-run'):
    return dict(job_id=job_id, sources=sources, result=dict(nodes=nodes, edges=edges, unresolved=unresolved))


def copybook(path):
    parent = dict(id='root', name='RECORD-A', kind='variable', start_line=1, statement_line=1,
                  end_line=2, parent_id=None)
    child = dict(id='field', name='FLAG-A', kind='field', start_line=2, statement_line=2,
                 end_line=2, parent_id='root')
    return dict(path=path, source='01 RECORD-A.\n05 FLAG-A PIC X.\n', symbols=[parent, child], imports=[],
                source_format='free')


class MixedGraphTests(unittest.TestCase):
    def test_cut_and_copybook_outputs_share_one_snapshot(self):
        cbl = 'src/MAIN.cbl'
        aps = 'src/SCREEN.aps'
        path = 'LIBB/COMMON.cpy'
        book = copybook(path)
        cbl_cut = cut_job({cbl: 'COPY COMMON\n    OF LIBB.\nCOPY COMMON OF LIBB.\n', path: book['source']}, [
            node('main-file', cbl, 'MAIN.cbl', 'file'), node('main', cbl, 'MAIN', 'module'),
            node('old-copy', path, 'COMMON.cpy', 'file'), node('old-field', path, 'FLAG-A', 'field', 2),
        ], [dict(src='main', dst='old-copy', rel='IMPORTS', props={'line': 1}),
            dict(src='main', dst='old-field', rel='REFERENCES', props={'line': 5})],
            [dict(path=cbl, kind='imports', name='COMMON', line=3)])
        aps_cut = cut_job({aps: 'RECORD SCREEN-A\n'}, [node('screen', aps, 'SCREEN.aps', 'file')], job_id='aps-run')
        inputs = project_graph_input([cbl_cut, aps_cut], copybooks={'files': [book, copybook('LIBA/COMMON.cpy')]},
                                     snapshot_id='core-v1', library='core', version='v1', doc_ids={path: 'doc-copy'})
        nodes, edges = enrich(**inputs, current_snapshots={'core-v1'})
        by_id = {entry['id']: entry for entry in nodes}
        self.assertNotIn('old-copy', by_id)
        self.assertNotIn('old-field', by_id)
        self.assertEqual({entry['props']['snapshot_id'] for entry in nodes}, {'core-v1'})
        imported = [edge for edge in edges if edge['rel'] == 'IMPORTS']
        self.assertEqual({edge['props']['line'] for edge in imported}, {1, 3})
        self.assertEqual(len(imported), 2)
        self.assertTrue(all(by_id[edge['dst']]['props']['path'] == path for edge in imported))
        field = by_id[next(edge['dst'] for edge in edges if edge['rel'] == 'REFERENCES')]
        self.assertEqual(field['props']['doc_id'], 'doc-copy')
        parent = next(edge['src'] for edge in edges if edge['rel'] == 'CONTAINS' and edge['dst'] == field['id'])
        self.assertEqual(by_id[parent]['props']['name'], 'RECORD-A')
        file_view = build_graph(nodes, edges, view='files')
        edge = next(edge for edge in file_view['edges'] if edge['rel'] == 'IMPORTS')
        self.assertEqual(edge['props']['occurrences'], 2)

    def test_wrong_library_and_comment_do_not_create_imports(self):
        path = 'src/MAIN.cbl'
        cbl = cut_job({path: "COPY COMMON OF LIBB.\n*> COPY COMMON.\nDISPLAY 'COPY COMMON'.\n"},
                      [node('main', path, 'MAIN.cbl', 'file')], unresolved=[
                          dict(path=path, kind='imports', name='COMMON', line=line) for line in (1, 2, 3)])
        inputs = project_graph_input(cbl, copybooks=[copybook('LIBA/COMMON.cpy')])
        _, edges = enrich(**inputs, current_snapshots={'cut-run'})
        self.assertNotIn('IMPORTS', {edge['rel'] for edge in edges})

    def test_source_path_and_snapshot_stable_for_copybook_only(self):
        book = copybook('copy\\COMMON.CPY')
        first = project_graph_input(copybooks=book, snapshot_id='v1')
        second = project_graph_input(copybooks={**book, 'path': 'copy/COMMON.CPY'}, snapshot_id='v1')
        self.assertEqual(first, second)
        third = project_graph_input(copybooks=book, snapshot_id='v2')
        self.assertFalse({node['id'] for node in first['nodes']} & {node['id'] for node in third['nodes']})


if __name__ == '__main__':
    unittest.main()
